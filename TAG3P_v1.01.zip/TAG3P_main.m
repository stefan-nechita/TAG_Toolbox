% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
clear all
close all
clc
%% Initialising the path for TAG_toolbox
oldpath = path;
path(oldpath,".\TAG_Toolbox");
oldpath = path;
path(oldpath,".\TAG_main_files");


%% Initialising Program paragemeters
Parameters.Program.UseMultiCore = 1; % 0 / 1 use of parrallel computing
Parameters.Program.Figures = 1;      % 0 / 1 compile identification figures
Parameters.Program.Recording = 0;    % 0 / 1 record identification evolution
Parameters.Program.hideFigure = 0;     % 0 / 1 Hides all the figures while runs the genetic programme
Parameters.Program.DisplayMessages = 1; % 0 / 1 Display identification messages.

clear CounterFitnessCriterion

if Parameters.Program.UseMultiCore ==1
    if isempty(gcp('nocreate')')
        parpool;
        poolobj = gcp;
        pctRunOnAll warning off
%         addAttachedFiles(poolobj, myFiles);
    else
        poolobj = gcp;
        pctRunOnAll warning off
%         addAttachedFiles(poolobj, myFiles);
    end
end
% Figure recording the evolution in the Error space



if (Parameters.Program.Recording == 1)
    WriterOBJPopEvolution = VideoWriter(strcat('TAG_population_evolution_',date,'_',num2str(floor(cputime)),'.avi'));
    WriterOBJPopEvolution.FrameRate=3;
    open(WriterOBJPopEvolution);
end
%% This file is the main file of the Tree adjoining grammar, genetic programming ARX/NARX/NARMAX model approximation

% -> Step1 Generate Random Population of TAGs |--> Step2 Estimate the
% parameters of each TAG (CMA-ES) | -> Step3 Compute the multi-objective
% fitness of each TAG Simulation Error % | and Prediction Error | -> Step4
% Perform non-dominated sorting of population and propose new population
% (NSGA-II) | -> Step5 Repeat from Step 2; --|
% |--------------------------------|


%% Load Input and Output Data
TAG_LoadInputOutputData

Parameters.EquationSolution.nu = Data.nu; % number of inputs channels
Parameters.EquationSolution.ny = Data.ny; % number of outputs channels
Parameters.EquationSolution.nE = Data.nE; % number of process noise channels


%% Initialising GeneticProgramming paragemeters
TAG_GeneticProgrammingParameters

%% Mandatory Definition for TAG
TAG_MandatoryDefinition

%% Initialise the random Population
TAG_InitialiseRandomPop



%% The GP procedure
% Resume Identification Here
% Load the paused workspace
% Run TAG3P_LoadGeneration
% Click -> Run Section
if Parameters.Program.UseMultiCore ==1
    if isempty(gcp('nocreate')')
        parpool;
        poolobj = gcp;
        pctRunOnAll warning off
    else
        pctRunOnAll warning off
        poolobj = gcp;
    end
    
end

while ((CounterNumberGeneration<=Parameters.GeneticProgramming.MAX_GEN))
    
    PauseIdentificationHere=0; % Don't forget to save the workspace! and close the video
    %     if (recording == 1)
    %     close (writerObj)
    % end
    GenerationTimer = tic;
    %R Each ParamFittingCriterionUpdate generations the stopping criterion
    % for parameter fitting get finner and finner therefore in the first
    % generations, a better structure is looked upon, not a better fitting
    if (mod(CounterNumberGeneration,Parameters.GeneticProgramming.CMAESParam.ParamFittingCriterionUpdate)==0)
        
        if Parameters.GeneticProgramming.CMAESParam.CMAES_GivenStopFitness>1e-10
            Parameters.GeneticProgramming.CMAESParam.CMAES_GivenStopFitness=Parameters.GeneticProgramming.CMAESParam.CMAES_GivenStopFitness/10; % CMA-ES fitness  limit
         end
        if Parameters.GeneticProgramming.CMAESParam.CMAES_GivenStopCriterion>1e-14
            Parameters.GeneticProgramming.CMAESParam.CMAES_GivenStopCriterion=Parameters.GeneticProgramming.CMAESParam.CMAES_GivenStopCriterion/10; % CMA-ES fitness gradient limit
        end
        
        if Parameters.GeneticProgramming.CMAESParam.CMAES_Iterations<Parameters.GeneticProgramming.CMAESParam.MAX_CMAES_Iterations
            Parameters.GeneticProgramming.CMAESParam.CMAES_Iterations=Parameters.GeneticProgramming.CMAESParam.CMAES_Iterations+20;
        end
        
        if Parameters.GeneticProgramming.CMAESParam.CMAES_watchdog<Parameters.GeneticProgramming.CMAESParam.MAX_CMAES_watchdog
            Parameters.GeneticProgramming.CMAESParam.CMAES_watchdog=Parameters.GeneticProgramming.CMAESParam.CMAES_watchdog+10;
        end
        
        if  Parameters.GeneticProgramming.FminuncParam.Max_iterations<500
            Parameters.GeneticProgramming.FminuncParam.Max_iterations=  Parameters.GeneticProgramming.FminuncParam.Max_iterations+  floor(Parameters.GeneticProgramming.FminuncParam.Max_iterations/20);
            Parameters.GeneticProgramming.FminuncParam.Max_function_evaluation=  Parameters.GeneticProgramming.FminuncParam.Max_function_evaluation+  floor(Parameters.GeneticProgramming.FminuncParam.Max_function_evaluation/20);
        end
        
        if Parameters.GeneticProgramming.Max_Complexity<Parameters.GeneticProgramming.Max_Complexity_UpperBound
            Parameters.GeneticProgramming.Max_Complexity=Parameters.GeneticProgramming.Max_Complexity+10;
        end
        if Parameters.Program.DisplayMessages == 1
            disp(strcat("Generation: ",num2str(CounterNumberGeneration)," change CMAES watchdog= ",num2str( Parameters.GeneticProgramming.CMAESParam.CMAES_watchdog),"and Max Complexity = ",num2str(Parameters.GeneticProgramming.Max_Complexity)))
        end
    end
    
    if CounterNumberGeneration==9000 % after a certain generation you can switch the parameter estimation function 
        Parameters.GeneticProgramming.ParemeterEstimationSwitch = 1; % 1=CMAES(), 2 =Fminunc(), 3 LeastSquares() with PredictionError only
        if Parameters.Program.DisplayMessages == 1
            disp("The parametrisation method switched to Fminunc()");
        end
    end
    
    
    %% ->Step1 Generate Offsprings by Crossover and Mutation Q(t)
    if Parameters.Program.DisplayMessages == 1
        disp("--- TAG3GP Step 1 ----")
    end
    TAG_GP_Step1
    
    
    %% -> Step2 Estimate the parameters of each TAG (CMA-ES) only on the
    % second half of R(t), because the first half was aleardy fitted with
    % the best parameters last iteration or right after the initialisation
    if Parameters.Program.DisplayMessages == 1
        disp("--- TAG3GP Step 2----")
    end
    TAG_GP_Step2
    
    %% -> Step3 Compute the multi-objective fitness of each TAG Simulation
    %Error and Prediction Error only for the second half of the R(t) set,
    %the first half was evaluated last iteration or at the initialisation
    % Propose a different set of data in order to validate the models
    if Parameters.Program.DisplayMessages == 1
        disp("--- TAG3GP Step 3 ----")
    end
    TAG_GP_Step3
    
    
    %% -> Step4 Perform a sorting based on prediction fitness
    if Parameters.Program.DisplayMessages == 1
        disp("--- TAG3GP Step 4 ----")
    end
    TAG_GP_Step4
    
    %% Collect the best Simulation Error Individual
    GeneticEvolutionData.MinSimulationError=inf;
    GeneticEvolutionData.BestSimulationCandidate=1;
    for CounterModel=1:Parameters.GeneticProgramming.MAX_POP
        if GeneticEvolutionData.MinSimulationError>Generation{CounterNumberGeneration}(CounterModel).performance.SimulationError
            GeneticEvolutionData.BestSimulationCandidate = CounterModel;
            GeneticEvolutionData.MinSimulationError = Generation{CounterNumberGeneration}(CounterModel).performance.SimulationError;
        end
    end
    GeneticEvolutionData.PerformanceBestFitnessCriterionSolution{1,1}(1,CounterNumberGeneration) = Generation{CounterNumberGeneration}(GeneticEvolutionData.BestSimulationCandidate).performance.SimulationError;
    GeneticEvolutionData.PerformanceBestFitnessCriterionSolution{1,2}(1,CounterNumberGeneration) = Generation{CounterNumberGeneration}(GeneticEvolutionData.BestSimulationCandidate).performance.PredictionError;
    GeneticEvolutionData.PerformanceBestSimulationErrorCandidate(1,CounterNumberGeneration) = GeneticEvolutionData.BestSimulationCandidate;
    GeneticEvolutionData.PerformanceBestFitnessCriterionSolution_dB{1,1}(1,CounterNumberGeneration) = mag2db(GeneticEvolutionData.PerformanceBestFitnessCriterionSolution{1,1}(1,CounterNumberGeneration));
    GeneticEvolutionData.PerformanceBestFitnessCriterionSolution_dB{1,2}(1,CounterNumberGeneration) = mag2db(GeneticEvolutionData.PerformanceBestFitnessCriterionSolution{1,2}(1,CounterNumberGeneration));
    
    %%
    
    
    %% Next Generation
    
    GeneticEvolutionData.GenerationTimerArray(CounterNumberGeneration) = toc(GenerationTimer);
    if Parameters.Program.DisplayMessages ==1
        disp(strcat("--- Generation time ",num2str(GeneticEvolutionData.GenerationTimerArray(CounterNumberGeneration))," ----"));
    end
    CounterNumberGeneration=CounterNumberGeneration+1;
    
    %% Clear the memory from the last 2 generations
    if Parameters.Program.DisplayMessages ==1
        disp("--- TAG3GP Step 5 ----")
    end
    TAG_GP_Step5
    
    
    %% Save the evolution of population in the error space
    if Parameters.Program.DisplayMessages ==1
        disp("--- TAG3GP Plot Generation ----")
    end
    close all
    
    FiguresArray(1) = figure("Name", "Generation Evolution");
    maxSimError=0;
    maxPredError=0;
    for CounterModel=1:length(Generation{CounterNumberGeneration})
        if Generation{CounterNumberGeneration}(CounterModel).performance.SimulationError>maxSimError && Generation{CounterNumberGeneration}(CounterModel).performance.SimulationError< 10
            maxSimError=mag2db(Generation{CounterNumberGeneration}(CounterModel).performance.SimulationError);
        end
        if Generation{CounterNumberGeneration}(CounterModel).performance.PredictionError>maxSimError && Generation{CounterNumberGeneration}(CounterModel).performance.PredictionError< 10
            maxPredError=mag2db(Generation{CounterNumberGeneration}(CounterModel).performance.PredictionError);
        end
        plot(mag2db(Generation{CounterNumberGeneration}(CounterModel).performance.SimulationError),mag2db(Generation{CounterNumberGeneration}(CounterModel).performance.PredictionError),"-*");
        hold on
        text(mag2db(Generation{CounterNumberGeneration}(CounterModel).performance.SimulationError),mag2db(Generation{CounterNumberGeneration}(CounterModel).performance.PredictionError),strcat(num2str(Generation{CounterNumberGeneration}(CounterModel).CreationGeneration),".f",int2str(Generation{CounterNumberGeneration}(CounterModel).front),".",int2str(CounterModel)));
        
    end
    grid on
    xlabel("Simulation Error [dB]");
    ylabel("Prediction Error [dB]");
    title(strcat("Generation: ",int2str(CounterNumberGeneration)));
    %     axis([0 max(maxSimError,maxPredError) 0
    %     max(maxSimError,maxPredError)]);
    %Compute front lines
    NoFront=1;
    FrontLines=cell(1,1);
    FrontLines{1,1}.SimulationError_dB=[];
    FrontLines{1,1}.PredictionError_dB=[];
    FrontCollour=["-g","-b","-r","-c","-m","-y","-k"];

    for CounterModel=1:length(Generation{CounterNumberGeneration})
        if Generation{CounterNumberGeneration}(CounterModel).front==NoFront
            FrontLines{NoFront}.SimulationError_dB = [FrontLines{NoFront}.SimulationError_dB mag2db(Generation{CounterNumberGeneration}(CounterModel).performance.SimulationError)];
            FrontLines{NoFront}.PredictionError_dB = [FrontLines{NoFront}.PredictionError_dB mag2db(Generation{CounterNumberGeneration}(CounterModel).performance.PredictionError)];
        else
            if Generation{CounterNumberGeneration}(CounterModel).front>NoFront
                NoFront=NoFront+1;
                FrontLines{1,NoFront}.SimulationError_dB=[];
                FrontLines{1,NoFront}.PredictionError_dB=[];
                if Generation{CounterNumberGeneration}(CounterModel).front==NoFront
                    FrontLines{NoFront}.SimulationError_dB = [FrontLines{NoFront}.SimulationError_dB mag2db(Generation{CounterNumberGeneration}(CounterModel).performance.SimulationError)];
                    FrontLines{NoFront}.PredictionError_dB = [FrontLines{NoFront}.PredictionError_dB mag2db(Generation{CounterNumberGeneration}(CounterModel).performance.PredictionError)];
                end
            end
        end
    end
  for counterFronts=1:NoFront
   plot(FrontLines{1,counterFronts}.SimulationError_dB,FrontLines{counterFronts}.PredictionError_dB,FrontCollour(1+mod(counterFronts,length(FrontCollour))));
  end
    drawnow
    clear maxSimError maxPredError FrontCollour FrontLines counterFronts NoFront
    drawnow
    if Parameters.Program.hideFigure==1
        close all
    end
end

if (Parameters.Program.Recording == 1)
    close (WriterOBJPopEvolution)
end
%% Final plots
CounterNumberGeneration=CounterNumberGeneration-1;


FiguresArray(2) = figure("Name", "Best Solution Evolution");

plot(1:CounterNumberGeneration,mag2db(GeneticEvolutionData.PerformanceFitnessParetoSolution{1, 1}(1:CounterNumberGeneration)),'r*');

hold on
plot(1:CounterNumberGeneration,mag2db(GeneticEvolutionData.PerformanceFitnessParetoSolution{1, 2}(1:CounterNumberGeneration)),'b*');
xlabel('Generation')
ylabel('Pareto solution Prediction and Simulation error error dB')
legend("Simulation error", "Prediction error")
title("First pareto front average Error")
grid on



CounterNumberGeneration=CounterNumberGeneration+1;
clear GenerationTimer
