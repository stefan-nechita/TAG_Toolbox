% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
classdef HandleNode < handle
    properties
        Object=[];
        type=[];
        label=[];
        offspring=[];
        parent=[];
        parent_offspring_link=[];
        initialLabelList=[];
        relativeIndex=[];
        substitutionAvailable=[]; % 1= Yes, 0=No
        adjunctionAvailable=[]; % 1= Yes, 0=No
        ownElementaryTree=[];% The adress to the elementary tree that this node is from
        
    end
    
    methods
        function obj=HandleNode(receivedObject)
            obj.Object=receivedObject;
            obj.type=[];
            obj.label=[];
            obj.offspring{1,1}=[];
            obj.offspring{1,2}=[];
            obj.offspring{1,3}=[];
            obj.parent=[];
            obj.parent_offspring_link=[];
            obj.initialLabelList=[];
            obj.relativeIndex=[];
            obj.substitutionAvailable=[]; % 1= Yes, 0=No
            obj.adjunctionAvailable=[]; % 1= Yes, 0=No
            obj.ownElementaryTree=[];% The adress to the elementary tree that this node is from
        end
        
        
    end
    
end