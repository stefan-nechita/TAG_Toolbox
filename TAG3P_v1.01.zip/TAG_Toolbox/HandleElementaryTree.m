% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
classdef HandleElementaryTree < handle
    properties
        Object=[];
        name=[]; % the tree type of this tree
        root=[];% root node of this tree
        foot=[];% to be used only for Auxiliary Trees
        DerivationTree=[];
        intermediate={}; % internal nodes are here
        initialBranchesList={}; % the list of branches that are withing this el. tree
        parent = {}; % address of the parent of this tree in the Derivation Tree
        parentBranchIndex = []; % At what branch (usefull node) of it's parent did this tree got Adjunct
        ElementaryArrayIndex =[]; % At what index one can find this Elementary tree withing the DerivationTree.ElementaryArray
        parentElementaryArrayIndex=[]; % At what index one can find it's parent of this tree within the DerivationTree.ElementaryArray
        ConnectionOperator=[]; %the TAG operator that was used to connect this el. Tree to the complex tree
        LinkInfo=[];
    end
    
    methods
        function obj=HandleElementaryTree(receivedObject,LinkInfo)
            obj.Object=receivedObject;
            obj.LinkInfo=LinkInfo;
            obj.name=[];
            obj.root=[];
            obj.DerivationTree=[];
            obj.intermediate={};
            obj.initialBranchesList={};
            obj.parent={};
            obj.parentBranchIndex=[];
            obj.ElementaryArrayIndex=[];
            obj.parentElementaryArrayIndex=[];
            obj.ConnectionOperator=[];
        end
        
        
    end
    
end
