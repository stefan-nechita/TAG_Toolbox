% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
function Answear = IsDominating(individual_1,individual_2)
%% (( z1(x1)<=z1(x2) && z2(x1)<=z2(x2) ) && (z1(x1)<z1(x2)||(z2(x1)<z2(x2)))
% x1, x2 individuals
% z1(), z2() objective functions
Answear=0;
And_dominance= (individual_1.fitness(:,1)<=individual_2.fitness(:,1));
Or_dominance= (individual_1.fitness(:,1)<individual_2.fitness(:,1));

isAndDominant =1;
for i=1:length(individual_1.fitness(:,1))
    if And_dominance(i)==0
        isAndDominant=0;
    end
end

isOrDominant =0;
for i=1:length(individual_1.fitness(:,1))
    if Or_dominance(i)==1
        isOrDominant=1;
    end
end

Answear = isAndDominant & isOrDominant;

end

