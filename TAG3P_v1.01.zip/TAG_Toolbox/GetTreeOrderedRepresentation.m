% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

function TreeOrderedRepresentation=GetTreeOrderedRepresentation(DerivedTree)
%% this function creates 2 ordered lists: 
% TreeOrderedRepresentation{1,1} is a Ordered Label list -> used to compute
% the Function represented by this tree
% TreeOrderedRepresentation{1,2} is a Ordered node list -> unused yet, used
% only for debug (to verify if each node has the corect label)
Label_list={};
Node_array={};
Label_list=GetLabel(DerivedTree.root,Label_list);
Node_array=GetNode(DerivedTree.root,Node_array);
TreeOrderedRepresentation={Label_list,Node_array};
end