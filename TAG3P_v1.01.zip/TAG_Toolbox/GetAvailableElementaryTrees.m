% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
function [AvailableElementaryTrees] = GetAvailableElementaryTrees(Tree)
%% this function provides an ordered list (w.r.t ElementaryArray) that shows what elementary trees are available for Substitution/Adjunction
% and what branches are available for each elementary Trees
noElemTrees=length(Tree.DerivationTree.ElementaryArray);
AvailableElementaryTrees.Adjunction=cell(noElemTrees,3);
% Handle to elem tree | initialBranches indexes of available nodes | labels of the available nodes
AvailableElementaryTrees.Substitution=cell(noElemTrees,3);
AvailableElementaryTrees.adjunctionFlag=0;
AvailableElementaryTrees.substitutionFlag=0;


for i=1:noElemTrees
    noBranches=length(Tree.DerivationTree.ElementaryArray(i,1).initialBranchesList);
    substitutionAvailableFlag=0;
    adjunctionAvailableFlag=0;
    substitutionAvailableBranches=[];
    adjunctionAvailableBranches=[];
    for j=1:noBranches
        if (Tree.DerivationTree.ElementaryArray(i, 1).initialBranchesList{j}.substitutionAvailable==1)
            substitutionAvailableFlag=1;
            AvailableElementaryTrees.substitutionFlag=1;
            substitutionAvailableBranches=[substitutionAvailableBranches,j];
            AvailableElementaryTrees.Substitution{i,3}=[AvailableElementaryTrees.Substitution{i,3}, Tree.DerivationTree.ElementaryArray(i, 1).initialBranchesList{1,j}.label];
        end
        
        if (Tree.DerivationTree.ElementaryArray(i, 1).initialBranchesList{j}.adjunctionAvailable==1)
            adjunctionAvailableFlag=1;
            AvailableElementaryTrees.adjunctionFlag=1;
            adjunctionAvailableBranches=[adjunctionAvailableBranches,j];
            AvailableElementaryTrees.Adjunction{i,3}=[AvailableElementaryTrees.Adjunction{i,3}, Tree.DerivationTree.ElementaryArray(i, 1).initialBranchesList{1,j}.label];      
        end    
    end
    if substitutionAvailableFlag==1
        AvailableElementaryTrees.Substitution{i,1}=Tree.DerivationTree.ElementaryArray(i, 1);
        AvailableElementaryTrees.Substitution{i,2}=substitutionAvailableBranches;  
    else
        AvailableElementaryTrees.Substitution{i,1}=[];
        AvailableElementaryTrees.Substitution{i,2}=[];
        AvailableElementaryTrees.Substitution{i,3}=[];
    end 
    if adjunctionAvailableFlag==1
        AvailableElementaryTrees.Adjunction{i,1}=Tree.DerivationTree.ElementaryArray(i, 1);
        AvailableElementaryTrees.Adjunction{i,2}=adjunctionAvailableBranches;     
    else
        AvailableElementaryTrees.Adjunction{i,1}=[];
        AvailableElementaryTrees.Adjunction{i,2}=[];
        AvailableElementaryTrees.Adjunction{i,3}=[];
    end
    
    
end

