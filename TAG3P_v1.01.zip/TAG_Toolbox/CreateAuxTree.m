% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
function [AuxTree] = CreateAuxTree(type,LinkInfo,ny,nu,nE,MaskLink)
%% Create an auxiliary Tree for NARMAX as in Data-driven Modelling of Dynamical Systems Using Tree Adjoining Grammar and Genetic Programming
% The basic idea:
% Create a function that when called creates a certain auxiliary tree
% Beta1..100 that have a different HandleNode for each separate auxiliary
% tree. Only in this way one can connect an auxiliary's foot node to anoter
% tree and not affet the other entities of the same type. At the end we
% will have a set of Beta1 auxiliary trees, a set of Beta2 auxiliary trees,
% a set of Beta3 auxiliary trees, etc... Otherwise whenever we will connect
% a foot node to another tree, the entire population of Beta1 aux trees
% will do the same, ruining any complex tree construction.
% LinkInfo is a matrix Ly/Lu of dimanesions 1 x ny or 1 x nu that is stored
% inside the elementary tree class as information in order to be easily
% ACCESSED and moved around during crossover and mutation
% ny= dimension of output;
% nu= dimension of input;

%----------Taken from MIMOARXAuxAndInitTrees.m file------------------
%%-------init leafs--------
plus=HandleNode("+");
plus.type=("leaf");
plus.label=("plus");

time_shift=HandleNode("q^-1");
time_shift.type=("leaf");
time_shift.label=("time-shift");

multiplication=HandleNode("*");
multiplication.type=("leaf");
multiplication.label=("multiplication");

input=HandleNode("u(k)");
input.type=("leaf");
input.label=("input");

output=HandleNode("y(k)");
output.type=("leaf");
output.label=("output");

parameter=HandleNode("C");
parameter.type=("leaf");
parameter.label=("parameter");

noise=HandleNode("E(k)");
noise.type=("leaf");
noise.label=("noise");





%%-----------end of leafs init-----------
%% Type: Beta1 Adding Input term to expression
switch type
    case "Beta1" %% MIMO NARMAX Beta1
        %-----basic-----
        linkflagOK=0;
        LinkInfo = LinkInfo(1:nu).*MaskLink.Lu;
        while linkflagOK==0
            if ~isempty(find(LinkInfo(1:nu)==1)) % Check if there is at least one spot filled with one from index 1 to min of (ny,nu) to avoid linking vectors full of zeros!
                linkflagOK=1;
            end
            if linkflagOK==0
                LinkInfo=randi([0,1],1,nu).*MaskLink.Lu;
            end
        end
        
        
        AuxTree = HandleElementaryTree("ElementaryTree",LinkInfo(1:nu)); % take only the first nu intems from the link info vector
        AuxTree.root=HandleNode("node");
        AuxTree.foot=HandleNode("node");
        AuxTree.root.type=("root");
        AuxTree.root.ownElementaryTree=AuxTree;
        AuxTree.name="Beta1";
        
        link=HandleNode("L");
        link.type=("leaf");
        link.label=("link");
        link.ownElementaryTree=AuxTree;
        
        
        
        %-----end of basic-----
        
        
        %-----particularities----
        %-----initialising internal nodes
        AuxTree.intermediate{1}=HandleNode("node");
        AuxTree.intermediate{2}=HandleNode("node");
        AuxTree.intermediate{3}=HandleNode("node");
        AuxTree.intermediate{1}.ownElementaryTree=AuxTree;
        AuxTree.intermediate{2}.ownElementaryTree=AuxTree;
        AuxTree.intermediate{3}.ownElementaryTree=AuxTree;
        AuxTree.foot.ownElementaryTree=AuxTree;
        AuxTree.intermediate{1}.type=("intermediate");
        AuxTree.intermediate{2}.type=("intermediate");
        AuxTree.intermediate{3}.type=("intermediate");
        AuxTree.foot.type=("foot");
        % The most lower layer of intermediate nodes has to be populated first
        %build the foot node!
        AuxTree.foot.label=("expr0");
        AuxTree.foot.parent=AuxTree.root;
        AuxTree.foot.parent_offspring_link=3;
        AuxTree.foot.substitutionAvailable=0;
        AuxTree.foot.adjunctionAvailable=0;
        
        % build the last towards first intermediate nodes
        AuxTree.intermediate{3}.label=("expr2");
        
        AuxTree.intermediate{3}.offspring{1}=link;
        AuxTree.intermediate{3}.offspring{2}=multiplication;
        AuxTree.intermediate{3}.offspring{3}=input;
        
        AuxTree.intermediate{3}.parent=AuxTree.intermediate{2};
        AuxTree.intermediate{3}.parent_offspring_link=1;
        AuxTree.intermediate{3}.substitutionAvailable=0;
        AuxTree.intermediate{3}.adjunctionAvailable=1;
        
        AuxTree.intermediate{2}.label=("expr3");
        
        AuxTree.intermediate{2}.offspring{1}=AuxTree.intermediate{3};
        
        AuxTree.intermediate{2}.parent=AuxTree.intermediate{1};
        AuxTree.intermediate{2}.parent_offspring_link=3;
        AuxTree.intermediate{2}.substitutionAvailable=0;
        AuxTree.intermediate{2}.adjunctionAvailable=1;
        
        AuxTree.intermediate{1}.label=("expr1");
        
        AuxTree.intermediate{1}.offspring{1,1}=parameter;
        AuxTree.intermediate{1}.offspring{1,2}=multiplication;
        AuxTree.intermediate{1}.offspring{1,3}=AuxTree.intermediate{2};
        
        AuxTree.intermediate{1}.parent=AuxTree.root;
        AuxTree.intermediate{1}.parent_offspring_link=1;
        AuxTree.intermediate{1}.substitutionAvailable=0;
        AuxTree.intermediate{1}.adjunctionAvailable=1;
        
        
        AuxTree.root.label=("expr0");
        AuxTree.root.offspring{1,1}=AuxTree.intermediate{1};
        AuxTree.root.offspring{1,2}=plus;
        AuxTree.root.offspring{1,3}=AuxTree.foot;
        AuxTree.root.substitutionAvailable=0;
        AuxTree.root.adjunctionAvailable=1;
        
        %         AuxTree.foot=AuxTree.root.offspring{1,3};% double direction poining
        AuxTree.initialBranchesList={AuxTree.root,AuxTree.intermediate{1:end}};% Create the list of the Aux Tree with all the nodes that can be used for TAG operators
        AuxTree.root.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.root.relativeIndex = 1;
        AuxTree.intermediate{1}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{1}.relativeIndex = 2;
        AuxTree.intermediate{2}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{2}.relativeIndex = 3;
        AuxTree.intermediate{3}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{3}.relativeIndex = 4;
        
        AuxTree.foot.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.foot.relativeIndex = 0;
        % order of the previous 2 lines matters!
        
        %-----end of particularities----
        
        % Fill up the Derivation tree
        AuxTree.DerivationTree.ElementaryArray(1)=AuxTree; %  All the elementary trees in this tree
        AuxTree.DerivationTree.ElementaryArrayRootLabels=AuxTree.root.label;
        AuxTree.DerivationTree.ElementaryArrayTypes=AuxTree.name;
        %
        
        
        
        
        
        
        %% Type Beta2 Adding Output term to expression
    case "Beta2" %% MIMO NARMAX Beta2
        %-----basic-----
        LinkInfo = LinkInfo(1:ny).*MaskLink.Ly;
        linkflagOK=0;
        while linkflagOK==0
            if ~isempty(find(LinkInfo(1:ny)==1)) % Check if there is at least one spot filled with one from index 1 to min of (ny,nu) to avoid linking vectors full of zeros!
                linkflagOK=1;
            end
            if linkflagOK==0
                LinkInfo=randi([0,1],1,ny).*MaskLink.Ly;
            end
        end
        AuxTree = HandleElementaryTree("ElementaryTree",LinkInfo(1:ny));% take only the first nu intems from the link info vector
        AuxTree.root=HandleNode("node");
        AuxTree.foot=HandleNode("node");
        AuxTree.root.type=("root");
        AuxTree.root.ownElementaryTree=AuxTree;
        AuxTree.name="Beta2";
        
        link=HandleNode("L");
        link.type=("leaf");
        link.label=("link");
        link.ownElementaryTree=AuxTree;
        
        
        %-----end of basic-----
        
        
        %-----particularities----
        %-----initialising internal nodes
        AuxTree.intermediate{1}=HandleNode("node");
        AuxTree.intermediate{2}=HandleNode("node");
        AuxTree.intermediate{3}=HandleNode("node");
        AuxTree.intermediate{4}=HandleNode("node");
        
        AuxTree.intermediate{1}.ownElementaryTree=AuxTree;
        AuxTree.intermediate{2}.ownElementaryTree=AuxTree;
        AuxTree.intermediate{3}.ownElementaryTree=AuxTree;
        AuxTree.intermediate{4}.ownElementaryTree=AuxTree;
        AuxTree.foot.ownElementaryTree=AuxTree;
        
        
        
        
        AuxTree.intermediate{1}.type=("intermediate");
        AuxTree.intermediate{2}.type=("intermediate");
        AuxTree.intermediate{3}.type=("intermediate");
        AuxTree.intermediate{4}.type=("intermediate");
        AuxTree.foot.type=("foot");
        % The most lower layer of intermediate nodes has to be populated first
        %build the foot node!
        AuxTree.foot.label=("expr0");
        AuxTree.foot.parent=AuxTree.root;
        AuxTree.foot.parent_offspring_link=3;
        AuxTree.foot.substitutionAvailable=0;
        AuxTree.foot.adjunctionAvailable=0;
        
        % build the last towards first intermediate nodes
        
        AuxTree.intermediate{4}.label=("expr2");
        AuxTree.intermediate{4}.offspring{1}=link;
        AuxTree.intermediate{4}.offspring{2}=multiplication;
        AuxTree.intermediate{4}.offspring{3}=output;
        
        AuxTree.intermediate{4}.parent=AuxTree.intermediate{3};
        AuxTree.intermediate{4}.parent_offspring_link=3;
        AuxTree.intermediate{4}.substitutionAvailable=0;
        AuxTree.intermediate{4}.adjunctionAvailable=0;% this one is zero, so there is only one place to add multiple time-shift operators
        
        AuxTree.intermediate{3}.label=("expr2");
        AuxTree.intermediate{3}.offspring{1}=time_shift;
        AuxTree.intermediate{3}.offspring{2}=multiplication;
        AuxTree.intermediate{3}.offspring{3}=AuxTree.intermediate{4};
        
        AuxTree.intermediate{3}.parent=AuxTree.intermediate{2};
        AuxTree.intermediate{3}.parent_offspring_link=1;
        AuxTree.intermediate{3}.substitutionAvailable=0;
        AuxTree.intermediate{3}.adjunctionAvailable=1;
        
        AuxTree.intermediate{2}.label=("expr3");
        
        AuxTree.intermediate{2}.offspring{1}=AuxTree.intermediate{3};
        
        AuxTree.intermediate{2}.parent=AuxTree.intermediate{1};
        AuxTree.intermediate{2}.parent_offspring_link=3;
        AuxTree.intermediate{2}.substitutionAvailable=0;
        AuxTree.intermediate{2}.adjunctionAvailable=1;
        
        AuxTree.intermediate{1}.label=("expr1");
        AuxTree.intermediate{1}.offspring{1,1}=parameter;
        AuxTree.intermediate{1}.offspring{1,2}=multiplication;
        AuxTree.intermediate{1}.offspring{1,3}=AuxTree.intermediate{2};
        AuxTree.intermediate{1}.parent=AuxTree.root;
        AuxTree.intermediate{1}.parent_offspring_link=1;
        AuxTree.intermediate{1}.substitutionAvailable=0;
        AuxTree.intermediate{1}.adjunctionAvailable=1;
        
        
        AuxTree.root.label=("expr0");
        AuxTree.root.offspring{1,1}=AuxTree.intermediate{1};
        AuxTree.root.offspring{1,2}=plus;
        AuxTree.root.offspring{1,3}=AuxTree.foot;
        AuxTree.root.substitutionAvailable=0;
        AuxTree.root.adjunctionAvailable=1;
        
        
        
        AuxTree.initialBranchesList={AuxTree.root,AuxTree.intermediate{1:end}};% Create the list of the Aux Tree with all the nodes that can be used for TAG operators
        
        AuxTree.root.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.root.relativeIndex = 1;
        AuxTree.intermediate{1}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{1}.relativeIndex = 2;
        AuxTree.intermediate{2}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{2}.relativeIndex = 3;
        AuxTree.intermediate{3}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{3}.relativeIndex = 4;
        AuxTree.intermediate{4}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{4}.relativeIndex = 5;
        
        AuxTree.foot.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.foot.relativeIndex = 0;
        
        %         AuxTree.foot=AuxTree.root.offspring{1,3};% double direction poining
        %-----end of particularities----
        
        
        % Populate the derivation tree of the elementary tree
        AuxTree.DerivationTree.ElementaryArray(1)=AuxTree; %  All the elementary trees in this tree
        AuxTree.DerivationTree.ElementaryArrayRootLabels=AuxTree.root.label;
        AuxTree.DerivationTree.ElementaryArrayTypes=AuxTree.name;
        %
        
        
        %% Type Beta3 Adding Noise term to expression
    case "Beta3" %% MIMO NARMARX Beta3
        %-----basic-----
        LinkInfo = LinkInfo(1:nE).*MaskLink.LE;
        linkflagOK=0;
        while linkflagOK==0
            if ~isempty(find(LinkInfo(1:nE)==1)) % Check if there is at least one spot filled with one from index 1 to min of (ny,nu) to avoid linking vectors full of zeros!
                linkflagOK=1;
            end
            if linkflagOK==0
                LinkInfo=randi([0,1],1,nE).*MaskLink.LE;
            end
        end
        AuxTree = HandleElementaryTree("ElementaryTree",LinkInfo(1:nE));% take only the first nE intems from the link info vector
        AuxTree.root=HandleNode("node");
        AuxTree.foot=HandleNode("node");
        AuxTree.root.type=("root");
        AuxTree.root.ownElementaryTree=AuxTree;
        AuxTree.name="Beta3";
        
        link=HandleNode("L");
        link.type=("leaf");
        link.label=("link");
        link.ownElementaryTree=AuxTree;
        
        
        %-----end of basic-----
        
        
        %-----particularities----
        %-----initialising internal nodes
        AuxTree.intermediate{1}=HandleNode("node");
        AuxTree.intermediate{2}=HandleNode("node");
        AuxTree.intermediate{3}=HandleNode("node");
        AuxTree.intermediate{4}=HandleNode("node");
        
        AuxTree.intermediate{1}.ownElementaryTree=AuxTree;
        AuxTree.intermediate{2}.ownElementaryTree=AuxTree;
        AuxTree.intermediate{3}.ownElementaryTree=AuxTree;
        AuxTree.intermediate{4}.ownElementaryTree=AuxTree;
        AuxTree.foot.ownElementaryTree=AuxTree;
        
        AuxTree.intermediate{1}.type=("intermediate");
        AuxTree.intermediate{2}.type=("intermediate");
        AuxTree.intermediate{3}.type=("intermediate");
        AuxTree.intermediate{4}.type=("intermediate");
        AuxTree.foot.type=("foot");
        % The most lower layer of intermediate nodes has to be populated first
        %build the foot node!
        AuxTree.foot.label=("expr0");
        AuxTree.foot.parent=AuxTree.root;
        AuxTree.foot.parent_offspring_link=3;
        AuxTree.foot.substitutionAvailable=0;
        AuxTree.foot.adjunctionAvailable=0;
        
        % build the last towards first intermediate nodes
        
        AuxTree.intermediate{4}.label=("expr2");
        AuxTree.intermediate{4}.offspring{1}=link;
        AuxTree.intermediate{4}.offspring{2}=multiplication;
        AuxTree.intermediate{4}.offspring{3}=noise;
        
        AuxTree.intermediate{4}.parent=AuxTree.intermediate{3};
        AuxTree.intermediate{4}.parent_offspring_link=3;
        AuxTree.intermediate{4}.substitutionAvailable=0;
        AuxTree.intermediate{4}.adjunctionAvailable=0;% this one is zero, so there is only one place to add multiple time-shift operators
        
        AuxTree.intermediate{3}.label=("expr2");
        AuxTree.intermediate{3}.offspring{1}=time_shift;
        AuxTree.intermediate{3}.offspring{2}=multiplication;
        AuxTree.intermediate{3}.offspring{3}=AuxTree.intermediate{4};
        
        AuxTree.intermediate{3}.parent=AuxTree.intermediate{2};
        AuxTree.intermediate{3}.parent_offspring_link=1;
        AuxTree.intermediate{3}.substitutionAvailable=0;
        AuxTree.intermediate{3}.adjunctionAvailable=1;
        
        AuxTree.intermediate{2}.label=("expr3");
        
        AuxTree.intermediate{2}.offspring{1}=AuxTree.intermediate{3};
        
        AuxTree.intermediate{2}.parent=AuxTree.intermediate{1};
        AuxTree.intermediate{2}.parent_offspring_link=3;
        AuxTree.intermediate{2}.substitutionAvailable=0;
        AuxTree.intermediate{2}.adjunctionAvailable=1;
        
        AuxTree.intermediate{1}.label=("expr1");
        AuxTree.intermediate{1}.offspring{1,1}=parameter;
        AuxTree.intermediate{1}.offspring{1,2}=multiplication;
        AuxTree.intermediate{1}.offspring{1,3}=AuxTree.intermediate{2};
        AuxTree.intermediate{1}.parent=AuxTree.root;
        AuxTree.intermediate{1}.parent_offspring_link=1;
        AuxTree.intermediate{1}.substitutionAvailable=0;
        AuxTree.intermediate{1}.adjunctionAvailable=1;
        
        
        AuxTree.root.label=("expr0");
        AuxTree.root.offspring{1,1}=AuxTree.intermediate{1};
        AuxTree.root.offspring{1,2}=plus;
        AuxTree.root.offspring{1,3}=AuxTree.foot;
        AuxTree.root.substitutionAvailable=0;
        AuxTree.root.adjunctionAvailable=1;
        
        
        
        AuxTree.initialBranchesList={AuxTree.root,AuxTree.intermediate{1:end}};% Create the list of the Aux Tree with all the nodes that can be used for TAG operators
        
        AuxTree.root.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.root.relativeIndex = 1;
        AuxTree.intermediate{1}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{1}.relativeIndex = 2;
        AuxTree.intermediate{2}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{2}.relativeIndex = 3;
        AuxTree.intermediate{3}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{3}.relativeIndex = 4;
        AuxTree.intermediate{4}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{4}.relativeIndex = 5;
        
        AuxTree.foot.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.foot.relativeIndex = 0;
        
        %         AuxTree.foot=AuxTree.root.offspring{1,3};% double direction poining
        %-----end of particularities----
        
        
        % Populate the derivation tree of the elementary tree
        AuxTree.DerivationTree.ElementaryArray(1)=AuxTree; %  All the elementary trees in this tree
        AuxTree.DerivationTree.ElementaryArrayRootLabels=AuxTree.root.label;
        AuxTree.DerivationTree.ElementaryArrayTypes=AuxTree.name;
        %
        
        
        %% Type Beta4 multiplicative input term
    case "Beta4" %% MIMO NARMAX Beta4
        %-----basic-----
        %-----basic-----
        LinkInfo = LinkInfo(1:nu).*MaskLink.Lu;
        linkflagOK=0;
        while linkflagOK==0
            if ~isempty(find(LinkInfo(1:nu)==1)) % Check if there is at least one spot filled with one from index 1 to min of (ny,nu) to avoid linking vectors full of zeros!
                linkflagOK=1;
            end
            if linkflagOK==0
                LinkInfo=randi([0,1],1,nu).*MaskLink.Lu;
            end
        end
        AuxTree = HandleElementaryTree("ElementaryTree",LinkInfo(1:nu));% take only the first nu intems from the link info vector
        AuxTree.root=HandleNode("node");
        AuxTree.foot=HandleNode("node");
        AuxTree.root.type=("root");
        AuxTree.root.ownElementaryTree=AuxTree;
        AuxTree.name="Beta4";
        
        link=HandleNode("L");
        link.type=("leaf");
        link.label=("link");
        link.ownElementaryTree=AuxTree;
        
        
        %-----end of basic-----
        
        
        %-----particularities----
        %-----initialising internal nodes
        AuxTree.intermediate{1}=HandleNode("node");
        AuxTree.intermediate{2}=HandleNode("node");
        
        AuxTree.intermediate{1}.ownElementaryTree=AuxTree;
        AuxTree.intermediate{2}.ownElementaryTree=AuxTree;
        AuxTree.foot.ownElementaryTree=AuxTree;
        
        AuxTree.intermediate{1}.type=("intermediate");
        AuxTree.intermediate{2}.type=("intermediate");
        AuxTree.foot.type=("foot");
        % The most lower layer of intermediate nodes has to be populated first
        %build the foot node!
        AuxTree.foot.label=("expr1");
        AuxTree.foot.parent=AuxTree.root;
        AuxTree.foot.parent_offspring_link=1;
        AuxTree.foot.substitutionAvailable=0;
        AuxTree.foot.adjunctionAvailable=0;
        
        % build the last towards first intermediate nodes
        
        AuxTree.intermediate{2}.label=("expr2");
        AuxTree.intermediate{2}.offspring{1}=link;
        AuxTree.intermediate{2}.offspring{2}=multiplication;
        AuxTree.intermediate{2}.offspring{3}=input;
        
        AuxTree.intermediate{2}.parent=AuxTree.intermediate{1};
        AuxTree.intermediate{2}.parent_offspring_link=1;
        AuxTree.intermediate{2}.substitutionAvailable=0;
        AuxTree.intermediate{2}.adjunctionAvailable=1;%
        
        AuxTree.intermediate{1}.label=("expr3");
        AuxTree.intermediate{1}.offspring{1}=AuxTree.intermediate{2};
        
        AuxTree.intermediate{1}.parent=AuxTree.root;
        AuxTree.intermediate{1}.parent_offspring_link=3;
        AuxTree.intermediate{1}.substitutionAvailable=0;
        AuxTree.intermediate{1}.adjunctionAvailable=1;%
        
        
        AuxTree.root.label=("expr1");
        AuxTree.root.offspring{1,1}=AuxTree.foot;
        AuxTree.root.offspring{1,2}=multiplication;
        AuxTree.root.offspring{1,3}=AuxTree.intermediate{1};
        AuxTree.root.substitutionAvailable=0;
        AuxTree.root.adjunctionAvailable=1;
        
        AuxTree.initialBranchesList={AuxTree.root,AuxTree.intermediate{1:end}};% Create the list of the Aux Tree with all the nodes that can be used for TAG operators
        
        AuxTree.root.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.root.relativeIndex = 1;
        AuxTree.intermediate{1}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{1}.relativeIndex = 2;
        AuxTree.intermediate{2}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{2}.relativeIndex = 3;
        
        AuxTree.foot.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.foot.relativeIndex = 0;
        
        %         AuxTree.foot=AuxTree.root.offspring{1,3};% double direction poining
        %-----end of particularities----
        
        % Populate the derivation tree of the elementary tree
        AuxTree.DerivationTree.ElementaryArray(1)=AuxTree; %  All the elementary trees in this tree
        AuxTree.DerivationTree.ElementaryArrayRootLabels=AuxTree.root.label;
        AuxTree.DerivationTree.ElementaryArrayTypes=AuxTree.name;
        %
        
        %% Type Beta5 Multiplicative output (k-1) term
    case "Beta5" %% MIMO NARMARX Beta5
        %-----basic-----
        LinkInfo = LinkInfo(1:ny).*MaskLink.Ly;
        linkflagOK=0;
        while linkflagOK==0
            if ~isempty(find(LinkInfo(1:ny)==1)) % Check if there is at least one spot filled with one from index 1 to min of (ny,nu) to avoid linking vectors full of zeros!
                linkflagOK=1;
            end
            if linkflagOK==0
                LinkInfo=randi([0,1],1,ny).*MaskLink.Ly;
            end
        end
        AuxTree = HandleElementaryTree("ElementaryTree",LinkInfo(1:ny));% take only the first ny intems from the link info vector
        AuxTree.root=HandleNode("node");
        AuxTree.foot=HandleNode("node");
        AuxTree.root.type=("root");
        AuxTree.root.ownElementaryTree=AuxTree;
        AuxTree.name="Beta5";
        
        link=HandleNode("L");
        link.type=("leaf");
        link.label=("link");
        link.ownElementaryTree=AuxTree;
        
        
        %-----end of basic-----
        
        
        %-----particularities----
        %-----initialising internal nodes
        AuxTree.intermediate{1}=HandleNode("node");
        AuxTree.intermediate{2}=HandleNode("node");
        AuxTree.intermediate{3}=HandleNode("node");
        
        
        AuxTree.intermediate{1}.ownElementaryTree=AuxTree;
        AuxTree.intermediate{2}.ownElementaryTree=AuxTree;
        AuxTree.intermediate{3}.ownElementaryTree=AuxTree;
        
        AuxTree.foot.ownElementaryTree=AuxTree;
        
        
        
        
        AuxTree.intermediate{1}.type=("intermediate");
        AuxTree.intermediate{2}.type=("intermediate");
        AuxTree.intermediate{3}.type=("intermediate");
        AuxTree.foot.type=("foot");
        % The most lower layer of intermediate nodes has to be populated first
        %build the foot node!
        AuxTree.foot.label=("expr1");
        AuxTree.foot.parent=AuxTree.root;
        AuxTree.foot.parent_offspring_link=1;
        AuxTree.foot.substitutionAvailable=0;
        AuxTree.foot.adjunctionAvailable=0;
        
        % build the last towards first intermediate nodes
        
        AuxTree.intermediate{3}.label=("expr2");
        AuxTree.intermediate{3}.offspring{1}=link;
        AuxTree.intermediate{3}.offspring{2}=multiplication;
        AuxTree.intermediate{3}.offspring{3}=output;
        
        AuxTree.intermediate{3}.parent=AuxTree.intermediate{2};
        AuxTree.intermediate{3}.parent_offspring_link=3;
        AuxTree.intermediate{3}.substitutionAvailable=0;
        AuxTree.intermediate{3}.adjunctionAvailable=0;% this one is zero, so there is only one place to add multiple time-shift operators
        
        AuxTree.intermediate{2}.label=("expr2");
        AuxTree.intermediate{2}.offspring{1}=time_shift;
        AuxTree.intermediate{2}.offspring{2}=multiplication;
        AuxTree.intermediate{2}.offspring{3}=AuxTree.intermediate{3};
        
        AuxTree.intermediate{2}.parent=AuxTree.intermediate{1};
        AuxTree.intermediate{2}.parent_offspring_link=1;
        AuxTree.intermediate{2}.substitutionAvailable=0;
        AuxTree.intermediate{2}.adjunctionAvailable=1;
        
        AuxTree.intermediate{1}.label=("expr3");
        AuxTree.intermediate{1}.offspring{1}=AuxTree.intermediate{2};
        
        AuxTree.intermediate{1}.parent=AuxTree.root;
        AuxTree.intermediate{1}.parent_offspring_link=3;
        AuxTree.intermediate{1}.substitutionAvailable=0;
        AuxTree.intermediate{1}.adjunctionAvailable=1;
        
        AuxTree.root.label=("expr1");
        AuxTree.root.offspring{1,1}=AuxTree.foot;
        AuxTree.root.offspring{1,2}=multiplication;
        AuxTree.root.offspring{1,3}=AuxTree.intermediate{1};
        AuxTree.root.substitutionAvailable=0;
        AuxTree.root.adjunctionAvailable=1;
        
        
        
        AuxTree.initialBranchesList={AuxTree.root,AuxTree.intermediate{1:end}};% Create the list of the Aux Tree with all the nodes that can be used for TAG operators
        
        AuxTree.root.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.root.relativeIndex = 1;
        AuxTree.intermediate{1}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{1}.relativeIndex = 2;
        AuxTree.intermediate{2}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{2}.relativeIndex = 3;
        AuxTree.intermediate{3}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{3}.relativeIndex = 4;
        
        
        AuxTree.foot.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.foot.relativeIndex = 0;
        
        %         AuxTree.foot=AuxTree.root.offspring{1,3};% double direction poining
        %-----end of particularities----
        
        
        % Populate the derivation tree of the elementary tree
        AuxTree.DerivationTree.ElementaryArray(1)=AuxTree; %  All the elementary trees in this tree
        AuxTree.DerivationTree.ElementaryArrayRootLabels=AuxTree.root.label;
        AuxTree.DerivationTree.ElementaryArrayTypes=AuxTree.name;
        %
        
        %% Type Beta6 Multiplicative noise (k-1) term
    case "Beta6" %% MIMO NARMARX Beta6
        %-----basic-----
        LinkInfo = LinkInfo(1:nE).*MaskLink.LE;
        linkflagOK=0;
        while linkflagOK==0
            if ~isempty(find(LinkInfo(1:nE)==1)) % Check if there is at least one spot filled with one from index 1 to min of (ny,nu) to avoid linking vectors full of zeros!
                linkflagOK=1;
            end
            if linkflagOK==0
                LinkInfo=randi([0,1],1,nE).*MaskLink.LE;
            end
        end
        AuxTree = HandleElementaryTree("ElementaryTree",LinkInfo(1:nE));% take only the first nE intems from the link info vector
        AuxTree.root=HandleNode("node");
        AuxTree.foot=HandleNode("node");
        AuxTree.root.type=("root");
        AuxTree.root.ownElementaryTree=AuxTree;
        AuxTree.name="Beta6";
        
        link=HandleNode("L");
        link.type=("leaf");
        link.label=("link");
        link.ownElementaryTree=AuxTree;
        
        
        %-----end of basic-----
        
        
        %-----particularities----
        %-----initialising internal nodes
        AuxTree.intermediate{1}=HandleNode("node");
        AuxTree.intermediate{2}=HandleNode("node");
        AuxTree.intermediate{3}=HandleNode("node");
        
        AuxTree.intermediate{1}.ownElementaryTree=AuxTree;
        AuxTree.intermediate{2}.ownElementaryTree=AuxTree;
        AuxTree.intermediate{3}.ownElementaryTree=AuxTree;
        AuxTree.foot.ownElementaryTree=AuxTree;
        
        
        
        
        AuxTree.intermediate{1}.type=("intermediate");
        AuxTree.intermediate{2}.type=("intermediate");
        AuxTree.intermediate{3}.type=("intermediate");
        
        AuxTree.foot.type=("foot");
        % The most lower layer of intermediate nodes has to be populated first
        %build the foot node!
        AuxTree.foot.label=("expr1");
        AuxTree.foot.parent=AuxTree.root;
        AuxTree.foot.parent_offspring_link=1;
        AuxTree.foot.substitutionAvailable=0;
        AuxTree.foot.adjunctionAvailable=0;
        
        % build the last towards first intermediate nodes
        
        AuxTree.intermediate{3}.label=("expr2");
        AuxTree.intermediate{3}.offspring{1}=link;
        AuxTree.intermediate{3}.offspring{2}=multiplication;
        AuxTree.intermediate{3}.offspring{3}=noise;
        
        AuxTree.intermediate{3}.parent=AuxTree.intermediate{2};
        AuxTree.intermediate{3}.parent_offspring_link=3;
        AuxTree.intermediate{3}.substitutionAvailable=0;
        AuxTree.intermediate{3}.adjunctionAvailable=0;% this one is zero, so there is only one place to add multiple time-shift operators
        
        AuxTree.intermediate{2}.label=("expr2");
        AuxTree.intermediate{2}.offspring{1}=time_shift;
        AuxTree.intermediate{2}.offspring{2}=multiplication;
        AuxTree.intermediate{2}.offspring{3}=AuxTree.intermediate{3};
        
        AuxTree.intermediate{2}.parent=AuxTree.intermediate{1};
        AuxTree.intermediate{2}.parent_offspring_link=1;
        AuxTree.intermediate{2}.substitutionAvailable=0;
        AuxTree.intermediate{2}.adjunctionAvailable=1;
        
        AuxTree.intermediate{1}.label=("expr3");
        AuxTree.intermediate{1}.offspring{1}=AuxTree.intermediate{2};
        
        AuxTree.intermediate{1}.parent=AuxTree.root;
        AuxTree.intermediate{1}.parent_offspring_link=3;
        AuxTree.intermediate{1}.substitutionAvailable=0;
        AuxTree.intermediate{1}.adjunctionAvailable=1;
        
        AuxTree.root.label=("expr1");
        AuxTree.root.offspring{1,1}=AuxTree.foot;
        AuxTree.root.offspring{1,2}=multiplication;
        AuxTree.root.offspring{1,3}=AuxTree.intermediate{1};
        AuxTree.root.substitutionAvailable=0;
        AuxTree.root.adjunctionAvailable=1;
        
        
        
        AuxTree.initialBranchesList={AuxTree.root,AuxTree.intermediate{1:end}};% Create the list of the Aux Tree with all the nodes that can be used for TAG operators
        
        AuxTree.root.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.root.relativeIndex = 1;
        AuxTree.intermediate{1}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{1}.relativeIndex = 2;
        AuxTree.intermediate{2}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{2}.relativeIndex = 3;
        AuxTree.intermediate{3}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{3}.relativeIndex = 4;
        
        
        AuxTree.foot.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.foot.relativeIndex = 0;
        
        %         AuxTree.foot=AuxTree.root.offspring{1,3};% double direction poining
        %-----end of particularities----
        
        
        % Populate the derivation tree of the elementary tree
        AuxTree.DerivationTree.ElementaryArray(1)=AuxTree; %  All the elementary trees in this tree
        AuxTree.DerivationTree.ElementaryArrayRootLabels=AuxTree.root.label;
        AuxTree.DerivationTree.ElementaryArrayTypes=AuxTree.name;
        %
        
        
        %% Type Beta7
    case "Beta7"%% ARX Beta3
        %-----basic-----
        LinkInfo = "no Linking for time-shift only elementary tree"; % i put this here only to comply with the HandleElementaryTree class,
        % most of the elementary trees have a linking matrix
        AuxTree = HandleElementaryTree("ElementaryTree",LinkInfo);
        AuxTree.root=HandleNode("node");
        AuxTree.foot=HandleNode("node");
        AuxTree.root.type=("root");
        AuxTree.root.ownElementaryTree=AuxTree;
        AuxTree.name="Beta7";
        %-----end of basic-----
        
        
        
        %-----particularities----
        %-----initialising internal nodes
        AuxTree.foot.type=("foot");
        AuxTree.foot.ownElementaryTree=AuxTree;
        % The most lower layer of intermediate nodes has to be populated first
        %build the foot node!
        AuxTree.foot.label=("expr2");
        AuxTree.foot.parent=AuxTree.root;
        AuxTree.foot.parent_offspring_link=3;
        AuxTree.foot.substitutionAvailable=0;
        AuxTree.foot.adjunctionAvailable=0;
        
        % build the last towards first intermediate nodes
        
        
        AuxTree.root.label=("expr2");
        AuxTree.root.offspring{1,1}=time_shift;
        AuxTree.root.offspring{1,2}=multiplication;
        AuxTree.root.offspring{1,3}=AuxTree.foot;
        AuxTree.root.substitutionAvailable=0;
        AuxTree.root.adjunctionAvailable=1;
        
        
        
        AuxTree.initialBranchesList={AuxTree.root,AuxTree.intermediate{1:end}};% Create the list of the Aux Tree with all the nodes that can be used for TAG operators
        AuxTree.root.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.root.relativeIndex = 1;
        
        AuxTree.foot.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.foot.relativeIndex = 0;
        
        %         AuxTree.foot=AuxTree.root.offspring{1,3};% double direction pointing
        %-----end of particularities----
        
        % Populate the derivation tree of the elementary tree
        AuxTree.DerivationTree.ElementaryArray(1)=AuxTree; %  All the elementary trees in this tree
        AuxTree.DerivationTree.ElementaryArrayRootLabels=AuxTree.root.label;
        AuxTree.DerivationTree.ElementaryArrayTypes=AuxTree.name;
           %% Type Beta8
    case "Beta8"%% NARMAX Beta8 preop
        %-----basic-----
        LinkInfo = "no Linking for preoperational-only elementary tree"; % i put this here only to comply with the HandleElementaryTree class,
        % most of the elementary trees have a linking matrix
        AuxTree = HandleElementaryTree("ElementaryTree",LinkInfo);
        AuxTree.root=HandleNode("node");
        AuxTree.foot=HandleNode("node");
        AuxTree.root.type=("root");
        AuxTree.root.ownElementaryTree=AuxTree;
        AuxTree.name="Beta8";
        %-----end of basic-----
        
        
        
        %-----particularities----
        %-----initialising internal nodes
        AuxTree.foot.type=("foot");
        AuxTree.foot.ownElementaryTree=AuxTree;
        % The most lower layer of intermediate nodes has to be populated first
        %build the foot node!
        AuxTree.foot.label=("expr3");
        AuxTree.foot.parent=AuxTree.root;
        AuxTree.foot.parent_offspring_link=3;
        AuxTree.foot.substitutionAvailable=0;
        AuxTree.foot.adjunctionAvailable=0;
        
        
        AuxTree.intermediate{1}=HandleNode("node");
        AuxTree.intermediate{1}.ownElementaryTree=AuxTree;

        AuxTree.foot.ownElementaryTree=AuxTree;
        AuxTree.intermediate{1}.type=("leaf");

        % build the last towards first intermediate nodes
         AuxTree.intermediate{1}.label=("preop");
        AuxTree.intermediate{1}.offspring{1}=[];

        
        AuxTree.intermediate{1}.parent=AuxTree.root;
        AuxTree.intermediate{1}.parent_offspring_link=1;
        AuxTree.intermediate{1}.substitutionAvailable=1; % Starter for substitution
        AuxTree.intermediate{1}.adjunctionAvailable=0;
     
        
        AuxTree.root.label=("expr3");
        AuxTree.root.offspring{1,1}=AuxTree.intermediate{1};
        AuxTree.root.offspring{1,2}=multiplication;
        AuxTree.root.offspring{1,3}=AuxTree.foot;
        AuxTree.root.substitutionAvailable=0;
        AuxTree.root.adjunctionAvailable=0; %0: so we do not stack cos(cos(abs(sin(exp( (u(:,k))))))
        
        
        
        AuxTree.initialBranchesList={AuxTree.root,AuxTree.intermediate{1:end}};% Create the list of the Aux Tree with all the nodes that can be used for TAG operators
        AuxTree.root.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.root.relativeIndex = 1;
        AuxTree.intermediate{1}.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.intermediate{1}.relativeIndex = 2;
        
        AuxTree.foot.initialLabelList = AuxTree.initialBranchesList;
        AuxTree.foot.relativeIndex = 0;
        
        %         AuxTree.foot=AuxTree.root.offspring{1,3};% double direction pointing
        %-----end of particularities----
        
        % Populate the derivation tree of the elementary tree
        AuxTree.DerivationTree.ElementaryArray(1)=AuxTree; %  All the elementary trees in this tree
        AuxTree.DerivationTree.ElementaryArrayRootLabels=AuxTree.root.label;
        AuxTree.DerivationTree.ElementaryArrayTypes=AuxTree.name;
        
end
%----------Taken from MIMOARXAuxAndInitTrees.m file------------------
%% Common instructions for all types
% AuxTree.initialBranchesList={AuxTree.root,AuxTree.intermediate{1:end}};% Create the list of the Aux Tree with all the nodes that can be used for TAG operators
AuxTree.parent = {}; % address of the parent of this tree in the Derivation Tree
AuxTree.parentBranchIndex = []; % At what branch (usefull node) of it's parent did this tree got Adjunct
AuxTree.ElementaryArrayIndex =1; % At what index one can find this Elementary tree withing the DerivationTree.ElementaryArray
AuxTree.parentElementaryArrayIndex=[]; % At what index one can find it's parent of this tree within the DerivationTree.ElementaryArray
AuxTree.ConnectionOperator=[]; % what TAG operator was used to connect this tree to it's parent

% Copy the label list into each node for future relative indexing.
% To be uncommented when needed, for now we have a "global" Adiacent Matrix
% AuxTree.offspringElementaryArrayIndices=[]; %At what indices in the DerivaitonTree.ElementaryArray one can find this tree's offsprings branch-wise ex: [10,[],4,12]
% %                                                 branch 1 offspring is located at DerivationList.ElementaryArray{10}
% %                                                 branch 2 is still available
% %                                                 branch 3 offspring is located at DerivationList.ElementaryArray{4}
% %                                                 branch 4 offspring is located at DerivationList.ElementaryArray{12}
% %                    This vector to be updated after each Adjunction that happens to this tree
% %                       And after each Crossover or mutation
%
% for counter_nodes=1:length(AuxTree.initialBranchesList)
%     if ~isempty(AuxTree.initialBranchesList{counter_nodes})
%         AuxTree.initialBranchesList{counter_nodes}.initialLabelList = AuxTree.initialBranchesList;
%         AuxTree.initialBranchesList{counter_nodes}.relativeIndex = counter_nodes;
%     end
%
% end

AuxTree.DerivationTree.AdiacentMatrix=0;

end


