% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
function [ElemArrayLinkInfo,ElemArrayParentBranchIndex,ElemArrayConnectionOperation] = GetElemTreeLinkInfo(tree)

treeLength=length(tree.DerivationTree.ElementaryArrayTypes);
ElemArrayLinkInfo=cell(treeLength,1);
ElemArrayParentBranchIndex = cell(treeLength,1);
ElemArrayConnectionOperation= cell(treeLength,1);
for counter=1:treeLength
    ElemArrayLinkInfo{counter,1}=tree.DerivationTree.ElementaryArray(counter,1).LinkInfo;  
    ElemArrayParentBranchIndex{counter,1} = tree.DerivationTree.ElementaryArray(counter,1).parentBranchIndex;
    ElemArrayConnectionOperation{counter,1} = tree.DerivationTree.ElementaryArray(counter,1).ConnectionOperator;
end

end
