% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
classdef HandleTree < handle
    properties
        Object=[];
        root=[];% root node of this tree
        DerivationTree=[];
        
    end
    
    methods
        function obj=HandleTree(receivedObject)
            obj.Object=receivedObject;
            obj.root=HandleNode("node");
            obj.DerivationTree=[];
            
        end
        
        
    end
    
end