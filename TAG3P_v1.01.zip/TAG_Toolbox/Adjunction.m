% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

function [ErrorCode,FinalTree] = Adjunction(DerivedTree,AuxiliaryTree,ElementaryArrayIndex,BranchIndex,InitTreeTypes)
%% For a general TAG defined in this mechanism
% DerivedTree = The initial tree or an already Derived Tree that has
%                 previously done Adjunctions and Substitution operations.
% AuxiliaryTree = A separate entity of any Auxiliary Tree type.
% ElementaryArrayIndex = is the index in the DerivedTree DerivationTree.ElementaryArray where the adjunction will take place
%                       (it points out on what other elementary tree the adjunction will take place).
% BranchIndex = Which Branch within the selected elementary tree will the
% adjunction take place

%
% BE CAREFULL!, whenever adjuncting a new Auxiliary Tree to a Complex Tree,
% the passed Auxiliary Tree has to be a new instance of AuxiliaryTree (use CreateAuxTree function), otherwise if the same
% tree was previously used on the same Complex Tree one can create CIRCUITS
% which determine the given Tree to not be a TAG anymore.
%
% ErrorCode:
% 0 = All Ok,
% 1 = Adjunction node is not available for adjunction
% 2 = The adjunction operation cannot take place because either the label of
% the auxiliary tree is not present in the derived tree or the BranchIndex
% points to an non adjunction available node.
% 3 = There is no label for this adjunction operator to take place.



%%
% Saturating the OrderIndex to the maximum possible one!
InitTreeAdjunctionAvailable=1;
% Start Adjoining
ErrorCode=0;
type=AuxiliaryTree.name;
typeTraget = DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).root.ownElementaryTree.name;
% verify if the elementary tree that the auxiliary tree will connect to
% exists
FinalTree=HandleTree("MainTree");
if   ~isempty(DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex,1))
    
    %verify if the connection point label matches the Auxiliary root label
    if ElementaryArrayIndex > length(DerivedTree.DerivationTree.ElementaryArray)
        display ("BUG! Check CreateComplexTree")
        display ("ElementaryArrayIndex was given higher than possible index")
        FinalTree=DerivedTree;
        ErrorCode = 5;
        display("Shit ON FIRE! ElementaryArrayIndex > length(DerivedTree.DerivationTree.ElementaryArray)");
        dbstop in Adjunction.m at 44
        FinalTree=DerivedTree;
        return;
    end
    
    if BranchIndex > length(DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList)
        display ("BUG! Check CreateComplexTree")
        display ("BranchIndex was given higher than possible index")
        FinalTree=DerivedTree;
        ErrorCode = 5;
        display ("SHIT ON FIRE! Try to enter branchindex = 3 on a parent that doesn't have 3 initial connection nodes.BranchIndex > length(DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList))");
        dbstop in Adjunction.m at 55
        FinalTree=DerivedTree;
        return;
    end
    
    
    if (strcmp(DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.label, AuxiliaryTree.root.label))
        
        %verify if the connection point is available for adjunction
        if (DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1, BranchIndex}.adjunctionAvailable==1)
            
            
            %             FinalTree=DerivedTree;
            %verify if the connection point is root
            if isempty(DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.parent)% in case that the connection point is the root node
                % if it is root
                RootToFootDirection=AuxiliaryTree.foot.parent_offspring_link;
                DerivedTree.root.parent=AuxiliaryTree.foot.parent;
                DerivedTree.root.parent_offspring_link=AuxiliaryTree.foot.parent_offspring_link;
                DerivedTree.root.type="intermediate";
                %                 DerivedTree.root.adjunctionAvailable=0;
                if InitTreeAdjunctionAvailable==1
                    if ~isempty(DerivedTree.root.ownElementaryTree)
                        if isstring(DerivedTree.root.ownElementaryTree.name)
                            if isempty(find(InitTreeTypes.typesArray{[InitTreeTypes.starterIndex]} == DerivedTree.root.ownElementaryTree.name))
                                DerivedTree.root.adjunctionAvailable=0;
                            end
                        else
                            DerivedTree.root.adjunctionAvailable=0;
                        end
                    else
                        DerivedTree.root.adjunctionAvailable=0;
                    end
                else
                    DerivedTree.root.adjunctionAvailable=0;
                end
                
                %                 AuxiliaryTree.foot.offspring=DerivedTree.root.offspring; % the offspring of the node where the connection happened are transfered to the foot node
                %                 AuxiliaryTree.foot.relativeIndex=DerivedTree.root.relativeIndex;
                %                 AuxiliaryTree.foot.initialLabelList = DerivedTree.root.initialLabelList;
                %
                %                 AuxiliaryTree.foot.adjunctionAvailable = DerivedTree.root.adjunctionAvailable;
                %                 AuxiliaryTree.foot.substitutionAvailable = DerivedTree.root.substitutionAvailable;
                %                 AuxiliaryTree.foot.ownElementaryTree = DerivedTree.root.ownElementaryTree;
                %
                %                 AuxiliaryTree.foot.type = DerivedTree.root.type;
                AuxiliaryTree.foot=DerivedTree.root;
                %                 AuxiliaryTree.root.offspring{1,3}=AuxiliaryTree.foot;
                AuxiliaryTree.root.offspring{1,RootToFootDirection}=AuxiliaryTree.foot;
                
                FinalTree.root=AuxiliaryTree.root;
                
                
            else % in case that the connection point is not the root node
                if InitTreeAdjunctionAvailable==1
                    if ~isempty(DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.ownElementaryTree)
                        if isstring(DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.ownElementaryTree.name)
                            if isempty(find(InitTreeTypes.typesArray{[InitTreeTypes.starterIndex]} == DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.ownElementaryTree.name))
                                DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.adjunctionAvailable=0;
                            end
                        else
                            DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.adjunctionAvailable=0;
                        end
                    else
                        DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.adjunctionAvailable=0;
                    end
                else
                    DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.adjunctionAvailable=0;
                end
                
                DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.type = ("intermediate");
                
                
                
                % Step 0, get the partent offspring direction
                RootToFootDirection=AuxiliaryTree.foot.parent_offspring_link;
                direction=DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.parent_offspring_link;
                %                 AuxiliaryTree.foot.type=("intermediate"); % % Changing the old foot type to intermediate, because in the new tree it is intermediate node, no longer a foot node
                %                 AuxiliaryTree.foot.offspring=DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.offspring; % It takes the real offsprings!
                %                 AuxiliaryTree.foot.relativeIndex=DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.relativeIndex; % It takes the real relative index!
                %                 AuxiliaryTree.foot.initialLabelList =DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.initialLabelList; % It takes the real initialLabelList!
                %
                %                 AuxiliaryTree.foot.adjunctionAvailable = DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.adjunctionAvailable;
                %                 AuxiliaryTree.foot.substitutionAvailable = DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.substitutionAvailable;
                %                 AuxiliaryTree.foot.ownElementaryTree = DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.ownElementaryTree;
                %Step I Aux.root parent info = Target node. parent info
                AuxiliaryTree.root.type=("intermediate"); % Changing the old root type to intermediate, because in the new tree it is intermediate node
                AuxiliaryTree.root.parent=DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.parent;
                AuxiliaryTree.root.parent_offspring_link=direction;
                
                
                % Step II Target node. parent info = Aux.foot parent info
                DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.type = ("intermediate");
                
                DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.parent=AuxiliaryTree.foot.parent;
                DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.parent_offspring_link=AuxiliaryTree.foot.parent_offspring_link;
                
                % Step VI parent of Target node.offspring{1,direction} = Aux.root
                AuxiliaryTree.root.parent.offspring{direction}=AuxiliaryTree.root;
                %                 DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.parent.offspring{direction}=AuxiliaryTree.root;
                
                % Step III Aux.foot = target node
                AuxiliaryTree.foot = DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex};
                
                % Step IV Aux.root.offspring{1,3} = Aux.foot
                %                 AuxiliaryTree.root.offspring{1,3}=AuxiliaryTree.foot;
                AuxiliaryTree.root.offspring{1,RootToFootDirection}=AuxiliaryTree.foot;
                
                
                % The list represent the values of the real tree nodes
                
                FinalTree.root=DerivedTree.root;
            end
            
            
            
            
            %Update the DerivationTree of the main TREE
            
            AuxiliaryTree.parent=DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex,1);
            AuxiliaryTree.parentBranchIndex=BranchIndex;
            AuxiliaryTree.parentElementaryArrayIndex=ElementaryArrayIndex;
            AuxiliaryTree.ConnectionOperator=("Adjunction");
            
            %% Updating evolution in Derivation Tree
            % Appending the elementaryArray
            
            
            FinalTree.DerivationTree.ElementaryArray=[DerivedTree.DerivationTree.ElementaryArray(1:end,1);AuxiliaryTree.DerivationTree.ElementaryArray(1:end,1)];
            FinalTree.DerivationTree.ElementaryArrayRootLabels=[DerivedTree.DerivationTree.ElementaryArrayRootLabels(1:end,1);AuxiliaryTree.DerivationTree.ElementaryArrayRootLabels];
            FinalTree.DerivationTree.ElementaryArrayTypes=[DerivedTree.DerivationTree.ElementaryArrayTypes(1:end,1);AuxiliaryTree.DerivationTree.ElementaryArrayTypes];
            
            %updating the ElementaryArrayIndex in each elementary Tree
            [noElements,~]=size(FinalTree.DerivationTree.ElementaryArray);
            for elTree_counter=1:noElements
                FinalTree.DerivationTree.ElementaryArray(elTree_counter,1).ElementaryArrayIndex=elTree_counter;
            end
            
            ThisOperationAdiacentMatrix=zeros(noElements);
            ThisOperationAdiacentMatrix(ElementaryArrayIndex,AuxiliaryTree.ElementaryArrayIndex)=1;
            FinalTree.DerivationTree.AdiacentMatrix=[DerivedTree.DerivationTree.AdiacentMatrix, zeros(noElements-1,1);zeros(1,noElements)];
            
            FinalTree.DerivationTree.AdiacentMatrix=FinalTree.DerivationTree.AdiacentMatrix | ThisOperationAdiacentMatrix; % updating the AdiacentMatrix
            
            %% Update the Derivation Tree of the Auxiliary/Init Tree where the connection happened.
            %DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).DerivationTree.ElementaryArray
            % This idea might not work beucase, I have to store at what
            % possition an a ElementaryArray is this auxiliary tree.
            % Therefore oif one has n auxiliary tree, for each one you can
            % create a sub-elementary tree that will require a different
            % index for each auxiliary tree.
            
            
            
        else
            ErrorCode=1;
            display("ERROR:The node is not Available for Adjunction, Select another node")
            FinalTree=DerivedTree;
        end
    else
        ErrorCode=2;
        display("ERROR: The adjunction operation cannot take place because");
        display("the connection node label mismatches the Auxiliary tree root label");
        dbstop in Adjunction.m at 162
        FinalTree=DerivedTree;
        
        
    end
else
    ErrorCode=3;
    display("ERROR: The adjunction operation cannot take place because");
    display("the elementary tree index point to an empty object");
    FinalTree=DerivedTree;
    
    
end


end
%THE IDEA!!: Make the tree radial around the starter initial tree.
% If the node where the adjunction is taken place is the root node of the
% STARTER initial tree: the adjunction flag is not turned to 0, instead it
% is kept to 1. Therefore other auxiliary trees can adjoin to this initial
% tree thus creating a radial growth of the derivation tree.
% the command ~isempty(find(InitTreeTypes.typesArray{[InitTreeTypes.starterIndex]} == DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex,1).name))
% checks if the adjunction node auxiliary tree if an starter initial tree.
% if this check is positive then the adjoingAvailable flag is kept on 1,
% elese it is set of 0