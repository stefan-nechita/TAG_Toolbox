% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

function NodeArray=GetNode(Node,NodeArray) 
%% The function provides a list of node addresses
% We are starting the exploration from
% the Tree's root and not the Tree structure, because the root is a node
% type of object, the Tree object is a structure.


if ~isempty(Node.offspring{1,1})
    NodeArray=[GetNode(Node.offspring{1,1},NodeArray)];
end
if ~isempty(Node.offspring{1,2})
    NodeArray=[GetNode(Node.offspring{1,2},NodeArray)];
end
if ~isempty(Node.offspring{1,3})
    NodeArray=[GetNode(Node.offspring{1,3},NodeArray)];
end

NodeArray=[NodeArray;Node];
end