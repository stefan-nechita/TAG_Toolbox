% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

function PlotDerivationTree(Tree,specificText)
% This function plots the derivation tree

% nodesToChooseFrom=Tree.DerivationTree.ElementaryArrayTypes;
AdiacentMatrix=Tree.DerivationTree.AdiacentMatrix*1;
len=length(Tree.DerivationTree.ElementaryArrayTypes);

% $% Method 1
% nodes=zeros(1,len);
% for j=1:len
%     for i=1:len
%         if AdiacentMatrix(i,j)==1
%             nodes(j)=i;
%         end
%     end
%     
%     
%     
% end
% 
% treeplot(nodes)

%% Method 2
for i=1:len
node_names(i,1)=strcat(specificText,Tree.DerivationTree.ElementaryArrayTypes(i),"_{",num2str(i),"}");
end
G=graph(AdiacentMatrix,'upper');
G.Nodes.Name=node_names;


plot(G)
title(specificText);
end

