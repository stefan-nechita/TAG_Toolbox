% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

function [ErrorCode,FinalTree]=Substitution(DerivedTree,InitialTree,ElementaryArrayIndex,BranchIndex)
%% For a general TAG defined in this mechanism
% DerivedTree = The initial tree or an already Derived Tree that has
%                 previously done Adjunctions and Substitution operations.
% InitialTree = A separate entity of any Initial Tree type.
% ElementaryArrayIndex = is the index in the DerivedTree DerivationTree.ElementaryArray where the adjunction will take place
%                       (it points out on what other elementary tree the adjunction will take place).
% OrderIndex = Which Branch within the selected elementary tree will the
% adjunction take place
%
% BE CAREFULL!, whenever substituting a new Initial Tree to a Complex Tree,
% the passed Initial Tree has to be a new instance of InitialTree (use CreateInitTree function), otherwise if the same
% tree was previously used on the same Complex Tree one can create CIRCUITS
% which determine the given Tree to not be a TAG anymore.
% ErrorCode:
% 0 = All Ok,
% 1 = Sbustitution node is not available for substitution
% 2 = The connection node label mismatches the Initial tree root label
% 3 = There is no label for this substitution operator to take place
% 4 = The substitution node is not a leaf node.

% FinalTree=ComplexTree;


% End of the saturation

ErrorCode=0;
% verify if the elementary tree that the auxiliary tree will connect to
% exists
FinalTree=HandleTree("MainTree");
if   ~isempty(DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex,1))
    
    %verify if the connection point label matches the Auxiliary root label
    if (strcmp(DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.label, InitialTree.root.label))
        
        %verify if the connection point is available for substitution
        if (DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1, BranchIndex}.substitutionAvailable==1)
            
            %         if(strcmp(ComplexTree.list{LabelIndex,OrderIndex}.parent.offspring{direction}.type,("leaf")))
            if(strcmp(DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1, BranchIndex}.type,("leaf")))
                direction=DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.parent_offspring_link;
                
                InitialTree.root.type=("intermediate");
                InitialTree.root.parent=DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.parent;
                InitialTree.root.parent_offspring_link=direction;
                InitialTree.root.substitutionAvailable=0;
                InitialTree.root.adjunctionAvailable=0;
                
                DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).intermediate{1,BranchIndex-1}.substitutionAvailable=0; % because t initialBranchesList = {root, intermediate}
                DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex, 1).initialBranchesList{1,BranchIndex}.parent.offspring{direction}=InitialTree.root;
                
                % Now we have to update the list of the ordered labels within the Final
                % Tree
                
                FinalTree.root=DerivedTree.root;
                
                InitialTree.parent=DerivedTree.DerivationTree.ElementaryArray(ElementaryArrayIndex,1);
                InitialTree.parentBranchIndex=BranchIndex;
                InitialTree.parentElementaryArrayIndex=ElementaryArrayIndex;
                InitialTree.ConnectionOperator=("Substitution");
                
                %Update the DerivationTree
                % Updating evolution in Derivation Tree
                % Appending the elementaryArray
                
                
                FinalTree.DerivationTree.ElementaryArray=[DerivedTree.DerivationTree.ElementaryArray(1:end,1);InitialTree.DerivationTree.ElementaryArray(1:end,1)];
                FinalTree.DerivationTree.ElementaryArrayRootLabels=[DerivedTree.DerivationTree.ElementaryArrayRootLabels(1:end,1);InitialTree.DerivationTree.ElementaryArrayRootLabels];
                FinalTree.DerivationTree.ElementaryArrayTypes=[DerivedTree.DerivationTree.ElementaryArrayTypes(1:end,1);InitialTree.DerivationTree.ElementaryArrayTypes];
                
                %updating the ElementaryArrayIndex in each elementary Tree
                [noElements,~]=size(FinalTree.DerivationTree.ElementaryArray);
                for elTree_counter=1:noElements
                    FinalTree.DerivationTree.ElementaryArray(elTree_counter,1).ElementaryArrayIndex=elTree_counter;
                end
                
                ThisOperationAdiacentMatrix=zeros(noElements);
                ThisOperationAdiacentMatrix(ElementaryArrayIndex,InitialTree.ElementaryArrayIndex)=1;
                FinalTree.DerivationTree.AdiacentMatrix=[DerivedTree.DerivationTree.AdiacentMatrix, zeros(noElements-1,1);zeros(1,noElements)];
                
                FinalTree.DerivationTree.AdiacentMatrix=FinalTree.DerivationTree.AdiacentMatrix | ThisOperationAdiacentMatrix; % updating the AdiacentMatrix
                
                
            else
                ErrorCode=4;
                display("ERROR: The given node is not a leaf, (Change OrderIndex)");
                FinalTree=DerivedTree;
            end
        else
            ErrorCode=1;
            display("ERROR: The substitution operation cannot take place because");
            display("ERROR:The node is not Available for substitution, Select another node")
            FinalTree=DerivedTree;
            
        end
    else
        ErrorCode=2;
        display("ERROR: The adjunction operation cannot take place because");
        display("the connection node label mismatches the Initial tree root label")
        FinalTree=DerivedTree;
        
    end
else
    ErrorCode=3;
    display("ERROR: The adjunction operation cannot take place because");
    display("the elementary tree index point to an empty object");;
    FinalTree=DerivedTree ;
end


