% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

function TreeDerivation=GetTreeDerivation(Tree)
Label_list={};
Node_array={};
Label_list=GetLabel(Tree.root,Label_list);
Node_array=GetNode(Tree.root,Node_array);
TreeDerivation={Label_list,Node_array};
end