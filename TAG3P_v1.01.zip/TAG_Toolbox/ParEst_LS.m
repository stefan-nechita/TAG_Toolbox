% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
function [FittedparamArray,FittingPerformance,Runtime]  = ParEst_LS(individual,Data)

% test_mule=Generation{1}(20).physical;
%function call : [FittedparamArray,FittingPerformance,Runtime] = ParameterEstimationLeastSquares(Generation{1}(20).physical,uTrain{1,1},yTrain{1,1},ETrain{1,1})
% Y_LS = Phi_LS*Theta_LS
% Theta_LS=(Phi_LS'*Phi_LS)\Phi_LS'*Y_LS;
u=[];
y=[];
E=[];
if Data.ZeroProcessNoiseFlag == 1
        for counter =1:length(Data.uTrain)
%     for counter =1:1
        E = [E Data.NoiseAmplitude*zeros(Data.nE, Data.NumberOfSamples)]; % zeros
        
        u = [u Data.uTrain{1,counter}];
        y = [y Data.yTrain{1,counter}];
    end
else
    for CounterDataSets = 1:Data.NETrain
        E = [E Data.NoiseAmplitude*randn(Data.nE, length(Data.uTrain)*Data.NumberOfSamples)]; % Normally distributed random variable
        
           for counter =1:length(Data.uTrain)
%         for counter =1:1
            u = [u Data.uTrain{1,counter}];
            y = [y Data.yTrain{1,counter}];
        end
    end
    
end



if isfield(individual,"AddConstantTermToOutput")
    UseAdditionalConstant=individual.AddConstantTermToOutput;
else
    UseAdditionalConstant=0;
end
startRun=tic();
Fcn=individual.fcn;
noDelays=individual.noDelays;
noParameters=individual.noParams;
TemporalBasesFcn=GetTemporalBases(Fcn);
[ny,nt]=size(y); % number of time samples
AddParametersToCurrentNoiseTerm=0; % comment this out please
if AddParametersToCurrentNoiseTerm==1
    N=length(TemporalBasesFcn); % the place where E(k) is placed in the Temporal basis
else
    N=length(TemporalBasesFcn)-1; % the place where E(k) is placed in the Temporal basis
end


if UseAdditionalConstant==1
    TemporalBasesFcn{N,1} = TemporalBasesFcn{N+1,1};
    TemporalBasesFcn{N+1} = [];
end

% prepare data for simulation!
[nu,length_time]=size(u);
[ny,length_time]=size(y);
[nE,length_time]=size(E);
u_compare=[zeros(nu,noDelays) u];
y_compare=[ones(ny,noDelays).*y(:,1) y(:,1:end)];% If the input was 0 before the starting of the simulation,
% then the output of the system was unchanged from the past until the time
% sample of the simulation.
E_compare=[zeros(nE,noDelays) E(:,1:end)];
% t=[zeros(1,noDelays) t'];
% E_compare=[zeros(nE,noDelays+length_time)]; % Here define your noise signal: create one on spot, bring it from outside this function or ignore the noise by setting it on 0

y_hat=zeros(ny,noDelays+length_time);
% y_hat_2=zeros(1,noDelays+length_time);
% k=noDelays+1;
% while k<=noDelays+length_time
%     y_hat(:,k)=Fcn(individual.paramArray,y_compare,u_compare,E_compare,k);
%     k=k+1;
% end

Theta_LS = zeros(N,ny);
Y_LS=y_compare(:,noDelays+1:end)';
Phi_LS = zeros(nt,N);
for counter_Tb=1:N
    for  k=noDelays+1:noDelays+length_time
        Phi_LS(k-noDelays,counter_Tb) = TemporalBasesFcn{counter_Tb,1}(y_compare,u_compare,E_compare,k);
    end
   
    
end

Theta_LS=(Phi_LS'*Phi_LS)\Phi_LS'*Y_LS;

for counter_param=1:N
    paramArray(1,(counter_param-1)*ny+1:(counter_param)*ny) =  Theta_LS(counter_param,:);
end

Y_LS_hat = Phi_LS*Theta_LS;

for output_counter=1:ny
    PredErrorOutput(output_counter)=sqrt(sum((Y_LS_hat(:,output_counter)-Y_LS(:,output_counter)).^2)/nt); %  RootMean square error
end
PredError=mean(PredErrorOutput);
y_hat=Y_LS_hat';
y_compare=Y_LS';
if noParameters==0
    FittedparamArray="noParams";
    FittingPerformance=inf;
else
    FittingPerformance=PredError;
    FittedparamArray=paramArray;
end


Runtime=toc(startRun);
end

