% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

function [InitTree] = CreateInitTree(type)
%% Creates an initial tree For NARMAX as in Data-driven Modelling of Dynamical Systems
% Using Tree Adjoining Grammar and Genetic Programming
%%----------Taken from MIMOARXAuxAndInitTrees.m file ----------------
%% -------init leafs-------- NARMAX + preoperations
noise=HandleNode("E");
noise.type=("leaf");
noise.label=("noise");

sin = HandleNode("sin");
sin.type=("leaf");
sin.label=("sin");

cos = HandleNode("cos");
cos.type=("leaf");
cos.label=("cos");

abs = HandleNode("abs");
abs.type=("leaf");
abs.label=("abs");

invers = HandleNode("invers");
invers.type=("leaf");
invers.label=("invers");

exponent = HandleNode("exponent");
exponent.type=("leaf");
exponent.label=("exponent");
%%-----------end of leafs init-----------

%-----basic-----
LinkInfo="no Linking for initial elementary trees"; % there is no linking vector for initial elementary trees within
% MIMO ARX - > I think that in MIMO NARMAX, where noise is colloured, there
% will be a need for linking vector for noise.
% i put this here only to comply with the HandleElementaryTree class,
% most of the elementary trees have a linking matrix
InitTree = HandleElementaryTree("ElementaryTree",LinkInfo);
InitTree.root=HandleNode("node");
InitTree.root.type=("root");
%-----end of basic-----


%% Type alfa1 ARX
%%------ particularities for alfa1----------
switch type
    case "alfa1" %% NARMAX + preoperations
        InitTree = HandleElementaryTree("ElementaryTree",LinkInfo);
        InitTree.root=HandleNode("node");
        InitTree.foot=("Only for Auxiliary Trees");
        InitTree.root.type=("root");
        InitTree.name="alfa1";
        InitTree.root.ownElementaryTree=InitTree;
        
        %%----------intermediary nodes---------
        InitTree.intermediate{1}=HandleNode("node");
        InitTree.intermediate{1}.offspring{1}=noise;
        InitTree.intermediate{1}.type=("intermediate");
        InitTree.intermediate{1}.label=("aff");
        InitTree.intermediate{1}.parent=InitTree.root;
        InitTree.intermediate{1}.parent_offspring_link=1;
        InitTree.intermediate{1}.substitutionAvailable=0;
        InitTree.intermediate{1}.adjunctionAvailable=0;
        %%----------end of intermediary-------
        
        
        InitTree.root.offspring{1}=InitTree.intermediate{1}; % connecting with the only intermediary
        InitTree.root.label=("expr0");
        InitTree.root.substitutionAvailable=0;
        InitTree.root.adjunctionAvailable=1;
        
        
        
        
        %%-----end of particularities for alfa1----------
        InitTree.DerivationTree.ElementaryArray(1)=InitTree; %  All the elementary trees in this tree
        InitTree.DerivationTree.ElementaryArrayRootLabels=InitTree.root.label;
        InitTree.DerivationTree.ElementaryArrayTypes=InitTree.name;
        
    case "alfa2" %% NARMAX + preoperations
        InitTree = HandleElementaryTree("ElementaryTree",LinkInfo);
        InitTree.root=HandleNode("node");
        InitTree.foot=("Only for Auxiliary Trees");
        InitTree.root.type=("root");
        InitTree.name="alfa2";
        InitTree.root.ownElementaryTree=InitTree;
        
        %%----------intermediary nodes---------
        %%----------end of intermediary-------
        
        
        InitTree.root.offspring{1}=sin; % connecting with the only intermediary
        InitTree.root.label=("preop");
        InitTree.root.substitutionAvailable=0;
        InitTree.root.adjunctionAvailable=0;
        
        
        %%-----end of particularities for alfa2----------
        InitTree.DerivationTree.ElementaryArray(1)=InitTree; %  All the elementary trees in this tree
        InitTree.DerivationTree.ElementaryArrayRootLabels=InitTree.root.label;
        InitTree.DerivationTree.ElementaryArrayTypes=InitTree.name;
        
    case "alfa3" %% NARMAX + preoperations
        InitTree = HandleElementaryTree("ElementaryTree",LinkInfo);
        InitTree.root=HandleNode("node");
        InitTree.foot=("Only for Auxiliary Trees");
        InitTree.root.type=("root");
        InitTree.name="alfa3";
        InitTree.root.ownElementaryTree=InitTree;
        
        %%----------intermediary nodes---------
        %%----------end of intermediary-------
        
        
        InitTree.root.offspring{1}=cos; % connecting with the only intermediary
        InitTree.root.label=("preop");
        InitTree.root.substitutionAvailable=0;
        InitTree.root.adjunctionAvailable=0;
        
        
        %%-----end of particularities for alfa2----------
        InitTree.DerivationTree.ElementaryArray(1)=InitTree; %  All the elementary trees in this tree
        InitTree.DerivationTree.ElementaryArrayRootLabels=InitTree.root.label;
        InitTree.DerivationTree.ElementaryArrayTypes=InitTree.name;
        
    case "alfa4" %% NARMAX + preoperations
        InitTree = HandleElementaryTree("ElementaryTree",LinkInfo);
        InitTree.root=HandleNode("node");
        InitTree.foot=("Only for Auxiliary Trees");
        InitTree.root.type=("root");
        InitTree.name="alfa4";
        InitTree.root.ownElementaryTree=InitTree;
        
        %%----------intermediary nodes---------
        %%----------end of intermediary-------
        
        
        InitTree.root.offspring{1}=abs; % connecting with the only intermediary
        InitTree.root.label=("preop");
        InitTree.root.substitutionAvailable=0;
        InitTree.root.adjunctionAvailable=0;
        
        
        %%-----end of particularities for alfa2----------
        InitTree.DerivationTree.ElementaryArray(1)=InitTree; %  All the elementary trees in this tree
        InitTree.DerivationTree.ElementaryArrayRootLabels=InitTree.root.label;
        InitTree.DerivationTree.ElementaryArrayTypes=InitTree.name;
        
    case "alfa5" %% NARMAX + preoperations
        InitTree = HandleElementaryTree("ElementaryTree",LinkInfo);
        InitTree.root=HandleNode("node");
        InitTree.foot=("Only for Auxiliary Trees");
        InitTree.root.type=("root");
        InitTree.name="alfa5";
        InitTree.root.ownElementaryTree=InitTree;
        
        %%----------intermediary nodes---------
        %%----------end of intermediary-------
        
        
        InitTree.root.offspring{1}=invers; % connecting with the only intermediary
        InitTree.root.label=("preop");
        InitTree.root.substitutionAvailable=0;
        InitTree.root.adjunctionAvailable=0;
        
        
        %%-----end of particularities for alfa2----------
        InitTree.DerivationTree.ElementaryArray(1)=InitTree; %  All the elementary trees in this tree
        InitTree.DerivationTree.ElementaryArrayRootLabels=InitTree.root.label;
        InitTree.DerivationTree.ElementaryArrayTypes=InitTree.name;
        
    case "alfa6" %% NARMAX + preoperations
        InitTree = HandleElementaryTree("ElementaryTree",LinkInfo);
        InitTree.root=HandleNode("node");
        InitTree.foot=("Only for Auxiliary Trees");
        InitTree.root.type=("root");
        InitTree.name="alfa6";
        InitTree.root.ownElementaryTree=InitTree;
        
        %%----------intermediary nodes---------
        %%----------end of intermediary-------
        
        
        InitTree.root.offspring{1}=exponent; % connecting with the only intermediary
        InitTree.root.label=("preop");
        InitTree.root.substitutionAvailable=0;
        InitTree.root.adjunctionAvailable=0;
        
        
        %%-----end of particularities for alfa2----------
        InitTree.DerivationTree.ElementaryArray(1)=InitTree; %  All the elementary trees in this tree
        InitTree.DerivationTree.ElementaryArrayRootLabels=InitTree.root.label;
        InitTree.DerivationTree.ElementaryArrayTypes=InitTree.name;
    otherwise
        Errorhere=0;
        
end
%%----------Taken from MIMOARXAuxAndInitTrees.m file ----------------
%% Common instructions for all types
InitTree.initialBranchesList={InitTree.root,InitTree.intermediate{1:end}};% Create the list of the Aux Tree with all the nodes that can be used for TAG operators
InitTree.parent = {}; % address of the parent of this tree in the Derivation Tree
InitTree.parentBranchIndex = []; % At what branch (usefull node) of it's parent did this tree got Adjunct
InitTree.ElementaryArrayIndex =1; % At what index one can find this Elementary tree withing the DerivationTree.ElementaryArray
InitTree.parentElementaryArrayIndex=[]; % At what index one can find it's parent of this tree within the DerivationTree.ElementaryArray
InitTree.ConnectionOperator=[]; % what TAG operator was used to connect this tree to it's parent
% Copy the label list into each node for future relative indexing.
% To be uncommented when needed, for now we have a "global" Adiacent Matrix
% InitTree.offspringElementaryArrayIndices=[]; %At what indices in the DerivaitonTree.ElementaryArray one can find this tree's offsprings branch-wise ex: [10,[],4,12]
% %                                                 branch 1 offspring is located at DerivationList.ElementaryArray{10}
% %                                                 branch 2 is still available
% %                                                 branch 3 offspring is located at DerivationList.ElementaryArray{4}
% %                                                 branch 4 offspring is located at DerivationList.ElementaryArray{12}
% %                    This vector to be updated after each Adjunction that happens to this tree
% %                       And after each Crossover or mutation
%
for counter_nodes=1:length(InitTree.initialBranchesList)
    if ~isempty(InitTree.initialBranchesList{counter_nodes})
        InitTree.initialBranchesList{counter_nodes}.initialLabelList = InitTree.initialBranchesList;
        InitTree.initialBranchesList{counter_nodes}.relativeIndex = counter_nodes;
    end
    
end


InitTree.DerivationTree.AdiacentMatrix=0;

end
