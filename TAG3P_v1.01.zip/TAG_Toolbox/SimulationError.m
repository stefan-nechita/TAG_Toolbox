% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to
% SysId 2021 conference.
function [SimError,y_hat] = SimulationError(individual,Data,DataSetIdentifier)
%PREDICTIONERROR Summary of this function goes here
%   individual  = only the .physical structure from each individual of an
%   generation
%   tau = the amount of steps for tau-step-ahead-prediction
uCellIndex=DataSetIdentifier.uCellIndex;
yCellIndex=DataSetIdentifier.yCellIndex;
if  DataSetIdentifier.Train ==1
    uSelectedDataSet = Data.uTrain{1,uCellIndex};
    ySelectedDataSet = Data.yTrain{1,yCellIndex};
end

if  DataSetIdentifier.Test ==1
    uSelectedDataSet = Data.uTest{1,uCellIndex};
    ySelectedDataSet = Data.yTest{1,yCellIndex};
end

if  DataSetIdentifier.Valid ==1
    uSelectedDataSet = Data.uValid{1,uCellIndex};
    ySelectedDataSet = Data.yValid{1,yCellIndex};
end
u=[];
y=[];
[~,length_time]=size(uSelectedDataSet);
if Data.ZeroProcessNoiseFlag == 1
    E = zeros(1, length_time); % zeros
    u = [u uSelectedDataSet];
    y = [y ySelectedDataSet];
else
    E = Data.NoiseAmplitude*randn(1,length_time); % Normally distributed random variable
    
    u = [u uSelectedDataSet];
    y = [y ySelectedDataSet];
end
SimError=0;
Fcn=individual.fcn;
noDelays=individual.noDelays;
noParameters=individual.noParams;

% prepare data for simulation!
[nu,~]=size(u);
[ny,~]=size(y);
[nE,~]=size(E);
u_compare=[zeros(nu,noDelays) u(:,1:length_time)];
y_compare=[ones(ny,noDelays).*y(:,1) y(:,1:length_time)]; % If the input was 0 before the starting of the simulation,
% then the output of the system was unchanged from the past until the time
% sample of the simulation.

% u_compare=[u(:,1).*ones(nu,noDelays) u(:,1:tau)];
% y_compare=[y(:,1).*ones(ny,noDelays) y(:,1:tau)];

% t=[zeros(1,noDelays) t'];
% E=[zeros(ny,noDelays+tau)]; % Here define your noise signal: create one on spot, bring it from outside this function or ignore the noise by setting it on 0
E_compare=[zeros(nE,noDelays) E(:,1:length_time)];
y_hat=zeros(ny,noDelays+length_time);

% Set the initial condition (the constant to shift the results!)
k=noDelays+1;
y_hat(:,1:k)=y_compare(:,1:k);
k=k+1;% set the initial condition
while k<=length_time+noDelays
    y_hat(:,k)=Fcn(individual.paramArray,y_hat,u_compare,E_compare,k);
    k=k+1;
end

for output_counter=1:ny
    SimErrorOutput(output_counter,:) = sqrt(sum((y_hat(output_counter,:)-y_compare(output_counter,:)).^2)/length_time); % Root Mean square error
end
SimError=mean(SimErrorOutput);
if isnan(SimError) || ~isnumeric(noParameters)  || noParameters==0
    SimError=inf;
end
y_hat=y_hat(:,noDelays+1:end);
y_compare=y_compare(:,noDelays+1:end);
end

