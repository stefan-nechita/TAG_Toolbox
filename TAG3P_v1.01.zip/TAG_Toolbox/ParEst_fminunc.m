% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to
% SysId 2021 conference.
function [FittedparamArray,FittingPerformance,Runtime] = ParEst_fminunc(individual,Data,Parameters)
w_sim=Parameters.GeneticProgramming.CMAESParam.w_sim;
w_pred=Parameters.GeneticProgramming.CMAESParam.w_pred;
FminuncParam=Parameters.GeneticProgramming.FminuncParam;

Runtime.SimulationError = 0;
Runtime.PredictionError = 0;

N=individual.noParams;
tic_runtime=tic();

additional_parameters.individual=individual;
additional_parameters.Data=Data;
additional_parameters.w_sim=w_sim;
additional_parameters.w_pred=w_pred;

Step_Tolerance=FminuncParam.Step_Tolerance;
Function_Tolerance=FminuncParam.Function_Tolerance;
Max_iterations=FminuncParam.Max_iterations;
Max_function_evaluation=FminuncParam.Max_function_evaluation;
Display_option = FminuncParam.Display_option;
Algorithm=FminuncParam.Algorithm;
if N ~= 0
    [InitialParameters,FittingPerformanceLS,Runtime]  = ParEst_LS(individual,Data);
    SumarxSimulation_Error=0;
    for counter =1:length(Data.uTrain)
        DataSetIdentifier.uCellIndex =counter;
        DataSetIdentifier.yCellIndex =counter;
        DataSetIdentifier.Train =1;
        DataSetIdentifier.Test =0;
        DataSetIdentifier.Valid =0;
        [arxSimulation_Error,~]=SimulationError(individual,Data,DataSetIdentifier);
        SumarxSimulation_Error=SumarxSimulation_Error+arxSimulation_Error;
    end
    arxSimulation_Error=SumarxSimulation_Error/length(Data.uTrain);

    if ( isempty(find(isnan(InitialParameters))) && arxSimulation_Error<100 && max(InitialParameters)<1000)
        Fobj = @(x) SimulationAndPredictionErrorFitness(x,additional_parameters);
        options = optimoptions('fminunc', 'Algorithm' , Algorithm ,'Display',Display_option, 'StepTolerance', Step_Tolerance, 'FunctionTolerance', Function_Tolerance, 'MaxIterations',Max_iterations, 'MaxFunctionEvaluations', Max_function_evaluation);
        problem =createOptimProblem('fminunc','objective', Fobj, 'x0', InitialParameters, 'options', options);
        [FittedparamArray,FittingPerformance] = fminunc(problem);
        
    else
        FittedparamArray=InitialParameters;
        FittingPerformance= FittingPerformanceLS;
    end
    
else
    FittedparamArray="No Parameters";
    individual.paramArray=0;
    SumarxSimulation_Error=0;
    for counter =1:length(Data.uTrain)
        DataSetIdentifier.uCellIndex =counter;
        DataSetIdentifier.yCellIndex =counter;
        DataSetIdentifier.Train =1;
        DataSetIdentifier.Test =0;
        DataSetIdentifier.Valid =0;
        [arxSimulation_Error,~]=SimulationError(individual,Data,DataSetIdentifier);
        SumarxSimulation_Error=SumarxSimulation_Error+arxSimulation_Error;
    end
    arxSimulation_Error=SumarxSimulation_Error/length(Data.uTrain);
    
    SumarxPrediction_Error=0;
    for counter =1:length(Data.uTrain)
        DataSetIdentifier.uCellIndex =counter;
        DataSetIdentifier.yCellIndex =counter;
        DataSetIdentifier.Train =1;
        DataSetIdentifier.Test =0;
        DataSetIdentifier.Valid =0;
        [arxSimulation_Error,~]=SimulationError(individual,Data,DataSetIdentifier);
        SumarxPrediction_Error=SumarxSimulation_Error+arxSimulation_Error;
    end
    arxPrediction_Error=SumarxPrediction_Error/length(Data.uTrain);
    
    
    FittingPerformance=  w_sim*arxSimulation_Error + w_pred*arxPrediction_Error;
end

Runtime=toc(tic_runtime);
end

