% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

function [Performance] = WeightedPerformance(Generation,w_sim,w_pred)
%WEIGHTEDPERFORMANCE Summary of this function goes here
%   Detailed explanation goes here

sum_simulation_error=0;
sum_prediction_error=0;

for i=1:length(Generation)
    sum_simulation_error=sum_simulation_error+Generation(i).performance.SimulationError;
    sum_prediction_error=sum_prediction_error+Generation(i).performance.PredictionError;
end

Performance=w_sim*sum_simulation_error + w_pred*sum_prediction_error;
end


