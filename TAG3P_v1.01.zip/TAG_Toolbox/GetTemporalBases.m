% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to
% SysId 2021 conference.

function [TemporalBasisFcn] = GetTemporalBases(FunctionHandle)
Testfcn=FunctionHandle;
TestfcnStr=func2str(Testfcn);
TestfcnStrSplit1=split(TestfcnStr,'+');
TemporalBasisString=cell(length(TestfcnStrSplit1),1);
TemporalBasisFcn=cell(length(TestfcnStrSplit1),1);
for counter=1:length(TestfcnStrSplit1)
    if ~isempty(strfind(TestfcnStrSplit1{counter,1},')]*'))
        WorkVariable=split(TestfcnStrSplit1{counter,1},')]*');
        TemporalBasisString{counter,1}=WorkVariable{2,1};
        
        TemporalBasisFcn{counter,1}=eval(strcat('@(y,u,E,k) (',TemporalBasisString{counter,1}));
    else
        TemporalBasisString{counter,1} = TestfcnStrSplit1{counter,1};
        TemporalBasisFcn{counter,1}=eval(strcat('@(y,u,E,k) ',TemporalBasisString{counter,1}));
    end
    
    
    
    
end
end

