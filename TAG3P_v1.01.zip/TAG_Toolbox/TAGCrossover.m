% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.


function [Error,Offsprings,CrossoverPoint] = TAGCrossover(treeParent1,treeParent2,InitTreeTypes,EquationSolutionParam)
%% The crossover genetic programming operator applied to a TAG
% input: ParentTreeOne, ParentTreeTwo HandleTree
% output: Error, Offsprings(array of dimmension 0x1,1x1,1x2)
% Error = an error feedback to the main programme
% Error = 0 | Everything ok!
% Error = 1 | Couldn't find 2 valid crossover points in 100 tries.
% Error = 2 |
% Error = 3 |

%% Selecting a Crossover Point
Error=0;
validCrossover=0;
nu = EquationSolutionParam.nu;
ny = EquationSolutionParam.ny;
nE = EquationSolutionParam.nE;
MaskLink=EquationSolutionParam.MaskLink;

tic ;
while validCrossover==0
    % Create an array of common elementary trees used in each parent
    
    UniqueLabelsParent1 = unique(treeParent1.DerivationTree.ElementaryArrayRootLabels(2:end),'sorted');
    UniqueLabelsParent2 = unique(treeParent2.DerivationTree.ElementaryArrayRootLabels(2:end),'sorted');
    
    % pick random elementary tree
    
    RandomLabelIndexParent1=randi([1 length(UniqueLabelsParent1)],1,1);
    RandomLabelIndexParent2=randi([1 length(UniqueLabelsParent2)],1,1);
    
    
    RandomLabelParent1=UniqueLabelsParent1(RandomLabelIndexParent1);
    RandomLabelParent2=UniqueLabelsParent2(RandomLabelIndexParent2);
    
    
    ChosingArrayParent1=find(treeParent1.DerivationTree.ElementaryArrayRootLabels == RandomLabelParent1);
    ChosingArrayParent2=find(treeParent2.DerivationTree.ElementaryArrayRootLabels == RandomLabelParent2);
    
    % !!!!!!!The Crossover point SHOULD NOT BE the root of the tree, since you cannot adjunct the initial tree to a derived tree
    
    ConnectionPointsOK=0;
    while ConnectionPointsOK~=1
        
        RandomPointParent1=ChosingArrayParent1(randi([1 length(ChosingArrayParent1)],1,1));
        RandomPointParent2=ChosingArrayParent2(randi([1 length(ChosingArrayParent2)],1,1));
        if ((RandomPointParent1~=1) && (RandomPointParent2 ~=1))
            ConnectionPointsOK=1;
        else
            ConnectionPointsOK=0;
        end
        
        
    end
    
    
    
    
    
    %% Select the elementary trees that are connected to the random point
    length_ElementaryArrayParent1=length(treeParent1.DerivationTree.ElementaryArrayTypes);
    length_ElementaryArrayParent2=length(treeParent2.DerivationTree.ElementaryArrayTypes);
    
    AdiacentMatrixParent1 = treeParent1.DerivationTree.AdiacentMatrix;
    AdiacentMatrixParent2 = treeParent2.DerivationTree.AdiacentMatrix;
    
    SubTreeIndicesParent1=RandomPointParent1;
    SubTreeIndicesParent2=RandomPointParent2;
    
    
    counter=1;
    while counter<=length(SubTreeIndicesParent1)
        SubTreeIndicesParent1=[SubTreeIndicesParent1, find(AdiacentMatrixParent1(SubTreeIndicesParent1(counter),:)==1)];
        counter=counter+1;
    end
    
    counter=1;
    while counter<=length(SubTreeIndicesParent2)
        SubTreeIndicesParent2=[SubTreeIndicesParent2, find(AdiacentMatrixParent2(SubTreeIndicesParent2(counter),:)==1)];
        counter=counter+1;
    end
    
    work_variableParent1=1:length_ElementaryArrayParent1;
    work_variableParent2=1:length_ElementaryArrayParent2;
    
    SupraTreeIndicesParent1=setdiff(work_variableParent1,SubTreeIndicesParent1);
    SupraTreeIndicesParent2=setdiff(work_variableParent2,SubTreeIndicesParent2);
    
    
    % Creating the Supra and Sub adiacent Matrix for each Parent
    SupraAdiacentMatrixParent1 = double(AdiacentMatrixParent1 (SupraTreeIndicesParent1,SupraTreeIndicesParent1));
    SupraAdiacentMatrixParent2 = double(AdiacentMatrixParent2 (SupraTreeIndicesParent2,SupraTreeIndicesParent2));
    
    SubAdiacentMatrixParent1= double(AdiacentMatrixParent1(SubTreeIndicesParent1,SubTreeIndicesParent1));
    SubAdiacentMatrixParent2= double(AdiacentMatrixParent2(SubTreeIndicesParent2,SubTreeIndicesParent2));
    
    
    lengthSubTreeParent1=length(SubTreeIndicesParent1);
    lengthSupraTreeParent1=length_ElementaryArrayParent1-lengthSubTreeParent1;
    
    lengthSubTreeParent2=length(SubTreeIndicesParent2);
    lengthSupraTreeParent2=length_ElementaryArrayParent2-lengthSubTreeParent2;
    
    
    % Creating the Stem of each NEW PARENT
    
    newParent1ElementaryArrayTypes=[treeParent1.DerivationTree.ElementaryArrayTypes(SupraTreeIndicesParent1)];
    newParent2ElementaryArrayTypes=[treeParent2.DerivationTree.ElementaryArrayTypes(SupraTreeIndicesParent2)];
    
    newParent1ElementaryArray=[treeParent1.DerivationTree.ElementaryArray(SupraTreeIndicesParent1)];
    newParent2ElementaryArray=[treeParent2.DerivationTree.ElementaryArray(SupraTreeIndicesParent2)];
    
    
    len_newParent1ElementaryArray=length(SupraTreeIndicesParent1);
    len_newParent2ElementaryArray=length(SupraTreeIndicesParent2);
    
    
    newParent1CreationInformation.parent=zeros(len_newParent1ElementaryArray,1);
    newParent1CreationInformation.parentBranchIndex=zeros(len_newParent1ElementaryArray,1);
    newParent1CreationInformation.TreeType=cell(len_newParent1ElementaryArray,1);
    newParent1CreationInformation.ConnectionOperator=cell(len_newParent1ElementaryArray,1);
    newParent1CreationInformation.LinkInfo=cell(len_newParent1ElementaryArray,1);
    
    newParent2CreationInformation.parent=zeros(len_newParent2ElementaryArray,1);
    newParent2CreationInformation.parentBranchIndex=zeros(len_newParent2ElementaryArray,1);
    newParent2CreationInformation.TreeType=cell(len_newParent2ElementaryArray,1);
    newParent2CreationInformation.ConnectionOperator=cell(len_newParent2ElementaryArray,1);
    newParent2CreationInformation.LinkInfo=cell(len_newParent2ElementaryArray,1); % passing the linking information
    
    for i=1:len_newParent1ElementaryArray
        for j=1:len_newParent1ElementaryArray
            if SupraAdiacentMatrixParent1(i,j)~=0
                newParent1CreationInformation.parent(j,1)=i;
                newParent1CreationInformation.parentBranchIndex(j,1) = newParent1ElementaryArray(j,1).parentBranchIndex;
                newParent1CreationInformation.TreeType{j,1} = newParent1ElementaryArrayTypes(j,1);
                newParent1CreationInformation.ConnectionOperator{j,1}=newParent1ElementaryArray(j,1).ConnectionOperator;
                newParent1CreationInformation.LinkInfo{j,1}=newParent1ElementaryArray(j,1).LinkInfo;
            end
        end
    end
    
    for i=1:len_newParent2ElementaryArray
        for j=1:len_newParent2ElementaryArray
            if SupraAdiacentMatrixParent2(i,j)~=0
                newParent2CreationInformation.parent(j,1)=i;
                newParent2CreationInformation.parentBranchIndex(j,1) = newParent2ElementaryArray(j,1).parentBranchIndex;
                newParent2CreationInformation.TreeType{j,1} = newParent2ElementaryArrayTypes(j,1);
                newParent2CreationInformation.ConnectionOperator{j,1}=newParent2ElementaryArray(j,1).ConnectionOperator;
                newParent2CreationInformation.LinkInfo{j,1}=newParent2ElementaryArray(j,1).LinkInfo;
            end
        end
    end
    
    RootOfnewParent1 = find(newParent1CreationInformation.parent==0);
    RootOfnewParent2 = find(newParent2CreationInformation.parent==0);
    
    newParent1CreationInformation.TreeType{RootOfnewParent1,1}=newParent1ElementaryArrayTypes(RootOfnewParent1,1);
    newParent2CreationInformation.TreeType{RootOfnewParent2,1}=newParent2ElementaryArrayTypes(RootOfnewParent2,1);
    newParent1CreationInformation.ConnectionOperator{RootOfnewParent1,1}="Initialisation";
    newParent2CreationInformation.ConnectionOperator{RootOfnewParent2,1}="Initialisation";
    
    % Creating the newParents
    tic ;
    [Error,newParent1] = CreateComplexTree(newParent1CreationInformation,ny,nu,nE,InitTreeTypes,MaskLink);
    time1=toc;
    
    tic;
    [Error,newParent2] = CreateComplexTree(newParent2CreationInformation,ny,nu,nE,InitTreeTypes,MaskLink);
    time2=toc;
    
    
    AvailableElementaryNewParent1=GetAvailableElementaryTrees(newParent1);
    AvailableElementaryNewParent2=GetAvailableElementaryTrees(newParent2);
    
    
    
    % Search if in new parent1 there is an available label for
    % Adjunction/Substitution for the node selected from old parent 2:
    % tree1Parent(RandomPointParent2)
    
    SearchLabel=treeParent2.DerivationTree.ElementaryArray(RandomPointParent2).root.label;
    SearchConnectionOperator=treeParent2.DerivationTree.ElementaryArray(RandomPointParent2, 1).ConnectionOperator;
    
    SearchSuccessfullyParent1=0;
    ElementaryIndexPossibleHost1=cell(1,1);
    AvailableBranchIndex1=cell(1,1);
    counter=1;
    for i=1:1:len_newParent1ElementaryArray
        switch SearchConnectionOperator
            case "Adjunction"
                if ~isempty(AvailableElementaryNewParent1.Adjunction{i,1})
                    for j=1:length(AvailableElementaryNewParent1.Adjunction{i,3})
                        if strcmp(AvailableElementaryNewParent1.Adjunction{i, 3}(1,j),SearchLabel) % if there is a label the same as the one looking for
                            ElementaryIndexPossibleHost1{counter,1}=i;%save the elementaryTreeArrayIndex
                            AvailableBranchIndex1{counter,1}=AvailableElementaryNewParent1.Adjunction{i, 2}(1,j);% save the branch index
                            counter=counter+1;
                            SearchSuccessfullyParent1=1;
                        end
                    end
                end
                
            case "Substitution"
                if ~isempty(AvailableElementaryNewParent1.Substitution{i,1})
                    for j=1:length(AvailableElementaryNewParent1.Substitution{i,3})
                        if strcmp(AvailableElementaryNewParent1.Substitution{i, 3}(1,j),SearchLabel) % if there is a label the same as the one looking for
                            ElementaryIndexPossibleHost1{counter,1}=i;%save the elementaryTreeArrayIndex
                            AvailableBranchIndex1{counter,1}=AvailableElementaryNewParent1.Substitution{i, 2}(1,j);% save the branch index
                            counter=counter+1;
                            SearchSuccessfullyParent1=1;
                        end
                    end
                end
        end
    end
    
    PossibleHost1ElemArrayIndices=[];
    PossibleHost1BranchIndices=cell(counter-1,1);
    
    for i=1:counter-1
        PossibleHost1ElemArrayIndices(i,1)=ElementaryIndexPossibleHost1{i,1};
        PossibleHost1BranchIndices{i,1}=AvailableBranchIndex1{i,1};
    end
    
    SearchLabel=treeParent1.DerivationTree.ElementaryArray(RandomPointParent1).root.label;
    SearchConnectionOperator=treeParent1.DerivationTree.ElementaryArray(RandomPointParent1, 1).ConnectionOperator;
    
    SearchSuccessfullyParent2=0;
    ElementaryIndexPossibleHost2=cell(1,1);
    AvailableBranchIndex2=cell(1,1);
    counter=1;
    
    for i=1:1:len_newParent2ElementaryArray
        switch SearchConnectionOperator
            case "Adjunction"
                if ~isempty(AvailableElementaryNewParent2.Adjunction{i,1})
                    for j=1:length(AvailableElementaryNewParent2.Adjunction{i,3})
                        if strcmp(AvailableElementaryNewParent2.Adjunction{i, 3}(1,j),SearchLabel) % if there is a label the same as the one looking for
                            
                            ElementaryIndexPossibleHost2{counter,1}=i;%save the elementaryTreeArrayIndex
                            AvailableBranchIndex2{counter,1}=AvailableElementaryNewParent2.Adjunction{i, 2}(1,j);% save the branch index
                            counter=counter+1;
                            SearchSuccessfullyParent2=1;
                        end
                    end
                end
                
            case "Substitution"
                if ~isempty(AvailableElementaryNewParent2.Substitution{i,1})
                    for j=1:length(AvailableElementaryNewParent2.Substitution{i,3})
                        if strcmp(AvailableElementaryNewParent2.Substitution{i, 3}(1,j),SearchLabel) % if there is a label the same as the one looking for
                            ElementaryIndexPossibleHost2{counter,1}=i;%save the elementaryTreeArrayIndex
                            AvailableBranchIndex2{counter,1}=[AvailableElementaryNewParent2.Substitution{i, 2}(1,j)];% save the branch index
                            counter=counter+1;
                            SearchSuccessfullyParent2=1;
                        end
                    end
                end
        end
    end
    
    
    PossibleHost2ElemArrayIndices=[];
    PossibleHost2BranchIndices=cell(counter-1,1);
    
    for i=1:counter-1
        PossibleHost2ElemArrayIndices(i,1)=ElementaryIndexPossibleHost2{i,1};
        PossibleHost2BranchIndices{i,1}=AvailableBranchIndex2{i,1};
    end
    % Pick a random Host index and a random of it's branch
    
    if ((SearchSuccessfullyParent1==1) && (SearchSuccessfullyParent2==1))
        workVariable1= randi([1,length(PossibleHost1ElemArrayIndices)],1,1);
        RandomHostPointParent1 = PossibleHost1ElemArrayIndices(workVariable1);
        RandomHostBranchIndexParent1 = PossibleHost1BranchIndices{workVariable1,1};
        
        workVariable2= randi([1,length(PossibleHost2ElemArrayIndices)],1,1);
        RandomHostPointParent2 = PossibleHost2ElemArrayIndices(workVariable2);
        RandomHostBranchIndexParent2 = PossibleHost2BranchIndices{workVariable2,1};
        
        validCrossover=1;
        
        %         display ("SearchLabel in Parent1")
        %         treeParent2.DerivationTree.ElementaryArray(RandomPointParent2).root.label
        %         display ("SearchLabel in Parent2")
        %         treeParent1.DerivationTree.ElementaryArray(RandomPointParent1).root.label
        %
        %         validCrossover
        
    else
        validCrossover=0;
        SearchSuccessfullyParent1=0;
        SearchSuccessfullyParent2=0;
    end
end

validCrossovertime=toc;

tic;

% DISPLAYED VALUES for Debug!!!
CrossoverPoint.Parent1RandomLabel=RandomLabelParent1;
CrossoverPoint.Parent2RandomLabel=RandomLabelParent2;
CrossoverPoint.Parent1DetachedIndex=RandomPointParent1;
CrossoverPoint.Parent2DetachedIndex=RandomPointParent2;
CrossoverPoint.Parent1HostIndex=RandomHostPointParent1;%Where parent1 will receive the information from Detached part of Parent2
CrossoverPoint.Parent2HostIndex=RandomHostPointParent2; %Where parent2 will receive the information from Detached part of Parent1
CrossoverPoint.Parent1DetachedType=treeParent1.DerivationTree.ElementaryArrayTypes(RandomPointParent1,1);
CrossoverPoint.Parent2DetachedType=treeParent2.DerivationTree.ElementaryArrayTypes(RandomPointParent2,1);




%%% COMPOSE THE NEW ADIACENT MATRICES


AdiacentMatrixOffspring1=[ newParent1.DerivationTree.AdiacentMatrix  , zeros(lengthSupraTreeParent1,lengthSubTreeParent2);
    zeros(lengthSubTreeParent2,lengthSupraTreeParent1), 100*SubAdiacentMatrixParent2];

AdiacentMatrixOffspring2=[ newParent2.DerivationTree.AdiacentMatrix, zeros(lengthSupraTreeParent2,lengthSubTreeParent1);
    zeros(lengthSubTreeParent1,lengthSupraTreeParent2), 100*SubAdiacentMatrixParent1];

% Get the new index of each parent connection point in its own old ElementaryArray

% if isempty(treeParent1.DerivationTree.ElementaryArray(RandomPointParent1,1).parent.ElementaryArrayIndex)
%     display ("BUGBUGBUG treeParent1.DerivationTree.ElementaryArray(RandomPointParent1,1) line 98")
% end
% if isempty(treeParent2.DerivationTree.ElementaryArray(RandomPointParent2,1).parent.ElementaryArrayIndex)
%     display ("BUGBUGBUG treeParent1.DerivationTree.ElementaryArray(RandomPointParent1,1) line 98")
% end

% check if the chosen point is the root of the Derivation tree (It has no parent and the
% treeParent1.DerivationTree.ElementaryArray(RandomPointParent1, 1).parent.ElementaryArrayIndex; call fails)



%% Based on the redefined Adiacent Matrix and the ElementaryArrayTypes information,
% Create the parent list for each elementary tree + its type + parent's
% BranchIndex wehre the elementary tree will be adjoint or substitute

% AdiacentMatrixOffspring1(RandomHostPointParent1,lengthSupraTreeParent1+1)=1;
% AdiacentMatrixOffspring2(RandomHostPointParent2,lengthSupraTreeParent2+1)=1;

AdiacentMatrixOffspring1(RandomHostPointParent1,lengthSupraTreeParent1+1)=50;
AdiacentMatrixOffspring2(RandomHostPointParent2,lengthSupraTreeParent2+1)=50;




Offspring1ElementaryArrayTypes=[newParent1.DerivationTree.ElementaryArrayTypes; treeParent2.DerivationTree.ElementaryArrayTypes(SubTreeIndicesParent2)];
Offspring2ElementaryArrayTypes=[newParent2.DerivationTree.ElementaryArrayTypes; treeParent1.DerivationTree.ElementaryArrayTypes(SubTreeIndicesParent1)];

Offspring1ElementaryArray=[newParent1.DerivationTree.ElementaryArray; treeParent2.DerivationTree.ElementaryArray(SubTreeIndicesParent2)];
Offspring2ElementaryArray=[newParent2.DerivationTree.ElementaryArray; treeParent1.DerivationTree.ElementaryArray(SubTreeIndicesParent1)];


len_offpsring1ElementaryArray=length(Offspring1ElementaryArrayTypes);
len_offpsring2ElementaryArray=length(Offspring2ElementaryArrayTypes);

Offspring1CreationInformation.parent=zeros(len_offpsring1ElementaryArray,1);
Offspring1CreationInformation.parentBranchIndex=zeros(len_offpsring1ElementaryArray,1);
Offspring1CreationInformation.TreeType=cell(len_offpsring1ElementaryArray,1);
Offspring1CreationInformation.ConnectionOperator=cell(len_offpsring1ElementaryArray,1);
Offspring1CreationInformation.LinkInfo=cell(len_offpsring1ElementaryArray,1);


Offspring2CreationInformation.parent=zeros(len_offpsring2ElementaryArray,1);
Offspring2CreationInformation.parentBranchIndex=zeros(len_offpsring2ElementaryArray,1);
Offspring2CreationInformation.TreeType=cell(len_offpsring2ElementaryArray,1);
Offspring2CreationInformation.ConnectionOperator=cell(len_offpsring1ElementaryArray,1);
Offspring2CreationInformation.LinkInfo=cell(len_offpsring2ElementaryArray,1);

for i=1:len_offpsring1ElementaryArray
    for j=1:len_offpsring1ElementaryArray
        if AdiacentMatrixOffspring1(i,j)~=0
            Offspring1CreationInformation.parent(j,1)=i;
            Offspring1CreationInformation.parentBranchIndex(j,1) = Offspring1ElementaryArray(j,1).parentBranchIndex;
            Offspring1CreationInformation.TreeType{j,1} = Offspring1ElementaryArrayTypes(j,1);
            Offspring1CreationInformation.ConnectionOperator{j,1}=Offspring1ElementaryArray(j,1).ConnectionOperator;
            Offspring1CreationInformation.LinkInfo{j,1}=Offspring1ElementaryArray(j,1).LinkInfo;
        end
    end
end
% adjustment for branchindex of the connection point!
StartingPointOfDetached2=lengthSupraTreeParent1+1;
Offspring1CreationInformation.parentBranchIndex(StartingPointOfDetached2,1)=RandomHostBranchIndexParent1;

for i=1:len_offpsring2ElementaryArray
    for j=1:len_offpsring2ElementaryArray
        if AdiacentMatrixOffspring2(i,j)~=0
            Offspring2CreationInformation.parent(j,1)=i;
            Offspring2CreationInformation.parentBranchIndex(j,1) = Offspring2ElementaryArray(j,1).parentBranchIndex;
            Offspring2CreationInformation.TreeType{j,1} = Offspring2ElementaryArrayTypes(j,1);
            Offspring2CreationInformation.ConnectionOperator{j,1}=Offspring2ElementaryArray(j,1).ConnectionOperator;
            Offspring2CreationInformation.LinkInfo{j,1}=Offspring2ElementaryArray(j,1).LinkInfo;
        end
    end
end

% adjustment for branchindex of the connection point!
StartingPointOfDetached1=lengthSupraTreeParent2+1;
Offspring2CreationInformation.parentBranchIndex(StartingPointOfDetached1,1)=RandomHostBranchIndexParent2;


RootOfOffspring1 = find( Offspring1CreationInformation.parent==0);
RootOfOffspring2 = find( Offspring2CreationInformation.parent==0);
Offspring1CreationInformation.TreeType{RootOfOffspring1,1}=Offspring1ElementaryArrayTypes(RootOfOffspring1,1);
Offspring2CreationInformation.TreeType{RootOfOffspring2,1}=Offspring2ElementaryArrayTypes(RootOfOffspring2,1);
Offspring1CreationInformation.ConnectionOperator{RootOfOffspring1,1}="Initialisation";
Offspring2CreationInformation.ConnectionOperator{RootOfOffspring2,1}="Initialisation";



%% Visualising the offsprings
% specificText="Off1.";
% for i=1:len_offpsring1ElementaryArray
%     node_names1(i,1)=strcat(specificText,Offspring1CreationInformation.TreeType{i,1},"_{",num2str(i),"}");
% end
% G=graph(AdiacentMatrixOffspring1,'upper');
% G.Nodes.Name=node_names1;
% figure(1)
% subplot(2,3,2)
% plot(G)
% title(specificText);
% xlabel(strcat("Detached Point = ",num2str(CrossoverPoint.Parent1DetachedIndex), "Conection Point = ",num2str(CrossoverPoint.Parent2HostIndex)));
%
%
% specificText="Off2.";
% for i=1:len_offpsring2ElementaryArray
%     node_names2(i,1)=strcat(specificText,Offspring2CreationInformation.TreeType{i,1},"_{",num2str(i),"}");
% end
% G=graph(AdiacentMatrixOffspring2,'upper');
% G.Nodes.Name=node_names2;
% figure(1)
% subplot(2,3,3)
% plot(G)
% title(specificText);
% xlabel(strcat("Detached Point = ",num2str(CrossoverPoint.Parent2DetachedIndex), "Conection Point = ",num2str(CrossoverPoint.Parent1HostIndex)));

%% Begin creation of each Offspring
preparingOffspringCreationtime=toc;
tic;
[Error,Offspring1] = CreateComplexTree(Offspring1CreationInformation,ny,nu,nE,InitTreeTypes,MaskLink);
time1=toc;

tic
[Error,Offspring2] = CreateComplexTree(Offspring2CreationInformation,ny,nu,nE,InitTreeTypes,MaskLink);
time2=toc;

% DIsplay offsprings DerivationTree
% disp(strcat("Creating offspring1 took ",num2str(time1+preparingOffspringCreationtime+validCrossovertime)," sec"))
% disp(strcat("Creating offspring1 took ",num2str(time2+preparingOffspringCreationtime+validCrossovertime)," sec"))

Offsprings(1).tree=Offspring1;
Offsprings(2).tree=Offspring2;
Offsprings(1).time=time1+preparingOffspringCreationtime+validCrossovertime;
Offsprings(2).time=time2+preparingOffspringCreationtime+validCrossovertime;

validCrossovertime;
preparingOffspringCreationtime;
CreatingFromAdiacentMatrixOffspring1=time1;
CreatingFromAdiacentMatrixOffspring2=time2;

end










