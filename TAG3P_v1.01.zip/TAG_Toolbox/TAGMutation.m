% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
function [Error,Offspring,MutationPoint] = TAGMutation(Parent,minimumComplexity,maximumComplexity,InitTreeTypes,AuxiliaryTreeTypes,EquationSolutionParam)
%% The crossover genetic programming operator applied to a TAG
% input: ParentTreeOne, ParentTreeTwo
% output: Error, Offsprings(array of dimmension 0x1,1x1,1x2)
% Error = an error feedback tot he main programme
% Error = 0 | Everything ok!
% Error = 1 |
% Error = 2 |
% Error = 3 |
ny=EquationSolutionParam.ny;
nu=EquationSolutionParam.nu;
nE=EquationSolutionParam.nE;
MaskLink=EquationSolutionParam.MaskLink;
Error=0;
Offspring=0;% to be further completed

% pick a random point

%% Main idea:
% 0 chose if either Delete content or Create new content or both!
% 1. Split the parent into Stem and Detached part, DELETE + CREATE
% 2. Reconstruct the Stem
% 3. Chose a Host point in the new parent
% 4. Chose a new order index based on min/max
% 5. Construct randomly the a new sub-derivation tree
% 6. The sub derivation tree can start from anywhere. As a true mutation,
% one loses a leg and grows a second head at the end of right hand.
ChangeLinkMatrixFlag=0;
CreateContentFlag=0;
DeleteContentFlag=0;

LenParentDerivTree=length(Parent.DerivationTree.ElementaryArrayRootLabels);
if LenParentDerivTree > 1
    choseVariable=randi([1 3],1,1);
    switch choseVariable
        case 1
            DeleteContentFlag=1;
            CreateContentFlag=0;
            ChangeLinkMatrixFlag=0;
        case 2
            DeleteContentFlag=0;
            CreateContentFlag=1;
            ChangeLinkMatrixFlag=0;
        case 3
            DeleteContentFlag=0;
            CreateContentFlag=0;
            ChangeLinkMatrixFlag=1;
    end
else
    DeleteContentFlag=0;
    CreateContentFlag=1;
end


%% START OF DELETION of content
if DeleteContentFlag ==1
    % 1. Split the parent into Stem and Detached part,
    % Create an array of common elementary trees used in each parent
    UniqueLabelsParent = unique(Parent.DerivationTree.ElementaryArrayRootLabels(1:end),'sorted');
    % pick random elementary tree
    RandomLabelIndexParent=randi([1 length(UniqueLabelsParent)],1,1);
    RandomLabelParent=UniqueLabelsParent(RandomLabelIndexParent);
    
    ChosingArrayParent=find(Parent.DerivationTree.ElementaryArrayRootLabels == RandomLabelParent);
    
    % !!!!!!!The Mutation point SHOULD NOT BE the root of the tree
    MutationPointsOK=0;
    while MutationPointsOK~=1
        RandomPointParent=ChosingArrayParent(randi([1 length(ChosingArrayParent)],1,1));
        if ((RandomPointParent~=1))
            MutationPointsOK=1;
        else
            MutationPointsOK=0;
        end
    end
    
    %% Select the elementary trees that are connected to the random point
    length_ElementaryArrayParent=length(Parent.DerivationTree.ElementaryArrayTypes);
    
    AdiacentMatrixParent = Parent.DerivationTree.AdiacentMatrix;
    SubTreeIndicesParent = RandomPointParent;
    
    
    counter=1;while counter<=length(SubTreeIndicesParent)
        SubTreeIndicesParent=[SubTreeIndicesParent, find(AdiacentMatrixParent(SubTreeIndicesParent(counter),:)==1)];
        counter=counter+1;
    end
    
    work_variableParent=1:length_ElementaryArrayParent;
    SupraTreeIndicesParent=setdiff(work_variableParent,SubTreeIndicesParent);
    
    
    % 2. Reconstruct the Stem
    % Creating the Supra and Sub adiacent Matrix for each Parent
    SupraAdiacentMatrixParent = double(AdiacentMatrixParent (SupraTreeIndicesParent,SupraTreeIndicesParent));
    
    lengthSupraTreeParent=length(SupraTreeIndicesParent);
    
    
    % Creating the Stem of each NEW PARENT
    
    newParentElementaryArrayTypes=[Parent.DerivationTree.ElementaryArrayTypes(SupraTreeIndicesParent)];
    newParentElementaryArray=[Parent.DerivationTree.ElementaryArray(SupraTreeIndicesParent)];
    
    len_newParentElementaryArray=length(newParentElementaryArrayTypes);
    
    
    
    newParentCreationInformation.parent=zeros(len_newParentElementaryArray,1);
    newParentCreationInformation.parentBranchIndex=zeros(len_newParentElementaryArray,1);
    newParentCreationInformation.TreeType=cell(len_newParentElementaryArray,1);
    newParentCreationInformation.ConnectionOperator=cell(len_newParentElementaryArray,1);
    newParentCreationInformation.LinkInfo=cell(len_newParentElementaryArray,1);
    
    
    for i=1:len_newParentElementaryArray
        for j=1:len_newParentElementaryArray
            if SupraAdiacentMatrixParent(i,j)~=0
                newParentCreationInformation.parent(j,1)=i;
                newParentCreationInformation.parentBranchIndex(j,1) = newParentElementaryArray(j,1).parentBranchIndex;
                newParentCreationInformation.TreeType{j,1} = newParentElementaryArrayTypes(j,1);
                newParentCreationInformation.ConnectionOperator{j,1}=newParentElementaryArray(j,1).ConnectionOperator;
                newParentCreationInformation.LinkInfo{j,1}=newParentElementaryArray(j,1).LinkInfo;
            end
        end
    end
    
    RootOfnewParent = find(newParentCreationInformation.parent==0);
    newParentCreationInformation.TreeType{RootOfnewParent,1}=newParentElementaryArrayTypes(RootOfnewParent,1);
    newParentCreationInformation.ConnectionOperator{RootOfnewParent,1}="Initialisation";
    %% creating the tree after the mutation index
    
    tic ;
    [Error,newParent] = CreateComplexTree(newParentCreationInformation,ny,nu,nE,InitTreeTypes,MaskLink);
    time1=toc;
    
    
    %     disp("An individual got some information DELETED")
else
    % Create a copy of the parent to prepare it for a possible Creation of
    % content
    % Creating the Stem of each NEW PARENT
    
    copyParentElementaryArrayTypes=[Parent.DerivationTree.ElementaryArrayTypes];
    copyParentElementaryArray=[Parent.DerivationTree.ElementaryArray];
    copyParentAdiacentMatrix=Parent.DerivationTree.AdiacentMatrix;
    
    len_copyParentElementaryArray=length(copyParentElementaryArrayTypes);
    
    
    
    copyParentCreationInformation.parent=zeros(len_copyParentElementaryArray,1);
    copyParentCreationInformation.parentBranchIndex=zeros(len_copyParentElementaryArray,1);
    copyParentCreationInformation.TreeType=cell(len_copyParentElementaryArray,1);
    copyParentCreationInformation.ConnectionOperator=cell(len_copyParentElementaryArray,1);
    copyParentCreationInformation.LinkInfo=cell(len_copyParentElementaryArray,1);
    
    for i=1:len_copyParentElementaryArray
        for j=1:len_copyParentElementaryArray
            if copyParentAdiacentMatrix(i,j)~=0
                copyParentCreationInformation.parent(j,1)=i;
                copyParentCreationInformation.parentBranchIndex(j,1) = copyParentElementaryArray(j,1).parentBranchIndex;
                copyParentCreationInformation.TreeType{j,1} = copyParentElementaryArrayTypes(j,1);
                copyParentCreationInformation.ConnectionOperator{j,1}=copyParentElementaryArray(j,1).ConnectionOperator;
                copyParentCreationInformation.LinkInfo{j,1}=copyParentElementaryArray(j,1).LinkInfo;
                
            end
        end
    end
    
    RootOfnewParent = find(copyParentCreationInformation.parent==0);
    copyParentCreationInformation.TreeType{RootOfnewParent,1}=copyParentElementaryArrayTypes(RootOfnewParent,1);
    copyParentCreationInformation.ConnectionOperator{RootOfnewParent,1}="Initialisation";
    %% creating the tree after the mutation index
    
    [Error,newParent] = CreateComplexTree(copyParentCreationInformation,ny,nu,nE,InitTreeTypes,MaskLink);
    
end
%% END OF DELETION of content

%% START the Creation of content
if CreateContentFlag ==1
    
    newParentElementaryArrayTypes=[newParent.DerivationTree.ElementaryArrayTypes];
    len_newParentElementaryArray= length(newParentElementaryArrayTypes);
    AvailableElementaryNewParent=GetAvailableElementaryTrees(newParent);
    
    % % 3. Chose a Host point in the new parent
    UniqueLabelsnewParent = unique(newParent.DerivationTree.ElementaryArrayRootLabels(1:end),'sorted');
    
    
    % pick random elementary tree
    % %Random Selection Operator (To be uncommented when such is needed and Substitution function works well)
    % selectOperator=randi([1,2],1,1);
    % if selectOperator==1
    %     SearchConnectionOperator="Substitution";
    % else
    %     if selectOperator==2
    %         SearchConnectionOperator=("Adjunction");
    %     end
    % end
    SearchConnectionOperator=("Adjunction");
    for i=1:length(AuxiliaryTreeTypes.typeRootNode)
        AuxTreeRootNodesArray(i)=(AuxiliaryTreeTypes.typeRootNode{i});
        AuxTreeTypesArray(i)=(AuxiliaryTreeTypes.typesArray{i});
    end
    AuxTreeRootNodes=unique(AuxTreeRootNodesArray);
    % While the mutation is not valid, search for a different label
    validMutation=0;
    while validMutation~=1
        SearchLabel=AuxTreeRootNodes(randi([1,length(AuxTreeRootNodes)],1,1));
        
        
        SearchSuccessfullyHost=0;
        ElementaryIndexPossibleHost=cell(1,1);
        AvailableBranchIndex=cell(1,1);
        counter=1;
        for i=1:1:len_newParentElementaryArray
            switch SearchConnectionOperator
                case "Adjunction"
                    if ~isempty(AvailableElementaryNewParent.Adjunction{i,1})
                        for j=1:length(AvailableElementaryNewParent.Adjunction{i,3})
                            if strcmp(AvailableElementaryNewParent.Adjunction{i, 3}(1,j),SearchLabel) % if there is a label the same as the one looking for
                                
                                ElementaryIndexPossibleHost{counter,1}=i;%save the elementaryTreeArrayIndex
                                AvailableBranchIndex{counter,1}=AvailableElementaryNewParent.Adjunction{i, 2}(1,j);% save the branch index
                                counter=counter+1;
                                SearchSuccessfullyHost=1;
                            end
                        end
                    end
                    
                case "Substitution"
                    if ~isempty(AvailableElementaryNewParent.Substitution{i,1})
                        for j=1:length(AvailableElementaryNewParent.Substitution{i,3})
                            if strcmp(AvailableElementaryNewParent.Substitution{i, 3}(1,j),SearchLabel) % if there is a label the same as the one looking for
                                ElementaryIndexPossibleHost{counter,1}=i;%save the elementaryTreeArrayIndex
                                AvailableBranchIndex{counter,1}=AvailableElementaryNewParent.Substitution{i, 2}(1,j);% save the branch index
                                counter=counter+1;
                                SearchSuccessfullyHost=1;
                            end
                        end
                    end
            end
        end
        
        PossibleHostElemArrayIndices=[];
        PossibleHostBranchIndices=cell(counter-1,1);
        
        for i=1:counter-1
            PossibleHostElemArrayIndices(i,1)=ElementaryIndexPossibleHost{i,1};
            PossibleHostBranchIndices{i,1}=AvailableBranchIndex{i,1};
        end
        
        if ((SearchSuccessfullyHost==1))
            workVariable= randi([1,length(PossibleHostElemArrayIndices)],1,1);
            RandomHostPointParent = PossibleHostElemArrayIndices(workVariable);
            RandomHostBranchIndexParent = PossibleHostBranchIndices{workVariable,1};
            validMutation=1;
        else
            validMutation=0;
        end
    end
    
    
    
    % 4. Chose a new order index based on min/max
    %  after the first generation of population, due to the crossover operator,
    %  one individual might have a complexity higher that the bounded one,
    %  because he gave away a shorter path of elementary trees than then one it
    %  received. Therefore if one wants to do a mutation on an already higher
    %  complexity individual, both of bounds will be violet because the
    %  individual is already too big compared to the standards. So the mutation
    %  will cut a part of it but will not grow any elementary trees!
    if  max(maximumComplexity-len_newParentElementaryArray,0) <= max(minimumComplexity-len_newParentElementaryArray,0)
        display("A individual is already too big into complexity and cannot accept more content")
    end
    
    numberOfNewElementaryTrees = randi([max(minimumComplexity-len_newParentElementaryArray,0),max(maximumComplexity-len_newParentElementaryArray,0)],1,1);
    
    % 5. Construct randomly the a new sub-derivation tree
    % The connection point of the new sub-derivation tree is defined by:
    
    ElementaryArrayIndexStartingMutation=len_newParentElementaryArray+1;
    constructionCounter=1;
    DerivedTreeDevelopment{1}=newParent;
    
    AdditionalComplexityOrder=numberOfNewElementaryTrees;
    DerivedTreeDevelopment=[DerivedTreeDevelopment, cell(1,numberOfNewElementaryTrees)];
    
    
    
    while constructionCounter<=AdditionalComplexityOrder
        OperationDone=0; % reset the flag if the operation is done
        Error=0;% reset the flag if error occured
        NoAvailableNodes=0; %reset the flag for available nodes: this comes because first,
        SubstitutionNotAvailable=0; % reset the flag for availabeSubstitution
        % the TAg operator is randomly selected and than it is checked if
        % the operator can be performed
        work_tree=[]; % reset the working_tree
        SaveDerivedTreeDevelopment=DerivedTreeDevelopment{constructionCounter};
        
        AvailableElementary = GetAvailableElementaryTrees(DerivedTreeDevelopment{constructionCounter});
        
        if AvailableElementary.substitutionFlag==1
            % If substitution is available, then perform substitution, else if
            % adjunction is available, perform adjunction
            % substitution selected
            if InitTreeTypes.noInitTrees>=InitTreeTypes.starterIndex+1 % check if the model set permit Substitutions, for ARX it does not
                SelectRandomLabelSucceed=0;
                while SelectRandomLabelSucceed~=1
                    %% Step 1 Select the auxiliary tree and branch where to substitute.
                    selectInitTreeType=randi([InitTreeTypes.starterIndex+1 InitTreeTypes.noInitTrees],1,1);
                    %% Step 2 Select the initial tree root label from available ones
                    rootNodeLabel=InitTreeTypes.typeRootNode{selectInitTreeType};
                    %--- determine which Elementary tree has a free branch with branch label == rootNodeLabel
                    [noElemTrees,~]=size(AvailableElementary.Substitution);
                    %% Step 3 Construct a list of available branches for substitution
                    BranchesToChoseFrom=[];
                    BranchesToChoseFromIndexes=[];
                    BranchesToChoseFrom=cell(noElemTrees,1);
                    for i=1:noElemTrees
                        noAvailableBranches=length(AvailableElementary.Substitution{i,3});
                        for j=1:noAvailableBranches
                            if strcmp(AvailableElementary.Substitution{i,3}(1,j),rootNodeLabel)
                                BranchesToChoseFrom{i,1}=[BranchesToChoseFrom{i,1} AvailableElementary.Substitution{i,2}(1,j)];
                                SelectRandomLabelSucceed=1;
                                BranchesToChoseFromIndexes=[BranchesToChoseFromIndexes ; i];
                            end
                        end
                    end
                end
                %% Step 3 Select a random initial tree type that have that root label
                SelectRandomElementaryIndexSucceed=0;
                while SelectRandomElementaryIndexSucceed~=1
                    
                    RandomElementaryTreeIndex=BranchesToChoseFromIndexes(randi([1,length(BranchesToChoseFromIndexes)],1,1));
                    
                    % Verify if it has a branch with the same label as the chosen
                    % one (rootNodeLabel) by doing if isempty(BranchesToChoseFrom{randomelementarytree,1})
                    if ~isempty(BranchesToChoseFrom{RandomElementaryTreeIndex,1})
                        SelectRandomElementaryIndexSucceed=1;
                        
                        selectBranchIndex=randi([1,length(BranchesToChoseFrom{RandomElementaryTreeIndex,1})],1,1); % randomly select an available order index
                        BranchIndex=BranchesToChoseFrom{RandomElementaryTreeIndex,1}(selectBranchIndex);
                        
                        treetype=InitTreeTypes.typesArray{selectInitTreeType}; % get the tree type
                        MutationStartingTreeType=treetype;
                        
                        %% Step 4 Create the selected initial tree
                        work_tree=CreateInitTree(treetype); % create a tree of that type with the proposed random linking matrix
                        
                        [Error,ResultedTreeFromOperation]=Substitution(DerivedTreeDevelopment{constructionCounter},work_tree,RandomElementaryTreeIndex,BranchIndex);
                        
                        ConstructionDebug{constructionCounter,1}=constructionCounter;% DEBUG ONLY!
                        ConstructionDebug{constructionCounter,2}=RandomElementaryTreeIndex;% DEBUG ONLY!
                        ConstructionDebug{constructionCounter,3}=work_tree.name;% DEBUG ONLY!
                        ConstructionDebug{constructionCounter,4}=rootNodeLabel; % DEBUG ONLY!
                        
                        if Error==0
                            OperationDone=1;
                        else
                            display("Error happened")
                            Error=1;
                        end
                    end
                end
                
                
                if OperationDone==1 % if the operation is done, increment the construction counter
                    constructionCounter=constructionCounter+1;
                    DerivedTreeDevelopment{constructionCounter}= ResultedTreeFromOperation;
                    %                 partiallyDerivationTree=DerivedTreeDevelopment{constructionCounter}.DerivationTree; % for debug only!
                    %                 Labels=GetTreeDerivation(DerivedTreeDevelopment{constructionCounter}); % for debug only!
                    
                else
                    if Error~=0
                        
                        DerivedTreeDevelopment{constructionCounter}=SaveDerivedTreeDevelopment;
                    end
                    if Error==0
                        if NoAvailableNodes==1
                            disp("Random Operation was not possible due to lack of available nodes")
                            
                        end
                        
                    end
                end
            end
        else
            %% check if adjunction is available - in 100% of cases it should be available because each new Aux elem tree is adding more labels that can be used for adjunction. The only case when adjunction is not possible is when all the nodes had beed used by auxiliary trees that introduced nodes that were not avaialble for adjunction
            if AvailableElementary.adjunctionFlag==1
                
                SelectRandomLabelSucceed=0;
                
                if constructionCounter==1 % The connection to the newParent is already defined, do not have to look for it!
                    SelectRandomLabelSucceed=1;
                    RandomElementaryTreeIndex=RandomHostPointParent;
                    BranchIndex=RandomHostBranchIndexParent;
                    AuxTreeTypestoChooseFrom = find(AuxTreeRootNodesArray == DerivedTreeDevelopment{constructionCounter}.DerivationTree.ElementaryArray(RandomHostPointParent).initialBranchesList{BranchIndex}.label);
                    
                    treetype = AuxTreeTypesArray(AuxTreeTypestoChooseFrom(randi([1,length(AuxTreeTypestoChooseFrom)],1,1)));
                    MutationStartingTreeType=treetype;
                    
                    linkflagOK=0;
                    %                     while linkflagOK==0
                    LinkInfo=randi([0,1],1,max([ny,nu,nE])); % propose a random linking matrix
                    %                      LinkInfo=ones(1,max(ny,nu)) ;
                    %                         if ~isempty(find(LinkInfo(1:min(ny,nu,nE))==1)) % Check if there is at least one spot filled with one from index 1 to min of (ny,nu) to avoid linking vectors full of zeros!
                    %                             linkflagOK=1;
                    %                         end
                    %                     end
                    %
                    %                     if isempty(find(LinkInfo(1:min(ny,nu,nE))==1))
                    %
                    %                         dbstop in TAGMutation at 354 LinkInfo is full 0.
                    %                     end
                    %
                    work_tree=CreateAuxTree(treetype,LinkInfo,ny,nu,nE,MaskLink); % create a tree of that type
                    
                    % perform substitution
                    % DerivedTree,AuxiliaryTree,ElementaryArrayIndex,BranchIndex
                    
                    [Error,ResultedTreeFromOperation]=Adjunction(DerivedTreeDevelopment{constructionCounter},work_tree,RandomElementaryTreeIndex,BranchIndex,InitTreeTypes);
                    
                    
                    rootNodeLabel=DerivedTreeDevelopment{constructionCounter}.DerivationTree.ElementaryArray(RandomHostPointParent).initialBranchesList{BranchIndex}.label; % DEBUG only!
                    ConstructionDebug{constructionCounter,1}=constructionCounter;% DEBUG ONLY!
                    ConstructionDebug{constructionCounter,2}=RandomElementaryTreeIndex;% DEBUG ONLY!
                    ConstructionDebug{constructionCounter,3}=work_tree.name;% DEBUG ONLY!
                    ConstructionDebug{constructionCounter,4}=rootNodeLabel; % DEBUG ONLY!
                    
                    if Error==0
                        OperationDone=1;
                    else
                        display("Error happened")
                        Error=1;
                    end
                    
                else  % if construction counter~=1 than, continue the normal procedure
                    % Chose a random root node label
                    SubTreeIsOk=0;
                    while SubTreeIsOk ==0
                        ElementaryArrayIndexStartingMutation = randi([1,len_newParentElementaryArray],1,1);
                        AvailableElementary = GetAvailableElementaryTreesSubTree(DerivedTreeDevelopment{constructionCounter},ElementaryArrayIndexStartingMutation);
                      if ~isempty(AvailableElementary.Adjunction{ElementaryArrayIndexStartingMutation,2})
                          SubTreeIsOk =1;
                      else
                          pauseHere=0;
                      end
                    end
                    
                    while SelectRandomLabelSucceed~=1
                        %--- Select the Random aux tree with a label=rootNodeLabel
                        selectAuxTreeType=randi([1 AuxiliaryTreeTypes.noAuxTrees],1,1);
                        
                        rootNodeLabel=AuxiliaryTreeTypes.typeRootNode{selectAuxTreeType};
                        %--- determine which Elementary tree has a free branch with branch label == rootNodeLabel
                        [noElemTrees,~]=size(AvailableElementary.Adjunction);
                        
                        %--- This part is looking through elementary trees that
                        %have branches with the same labe as the randomly chosen
                        %label
                        BranchesToChoseFrom=cell(noElemTrees,1);
                        for i=1:noElemTrees
                            noAvailableBranches=length(AvailableElementary.Adjunction{i,3});
                            for j=1:noAvailableBranches
                                if strcmp(AvailableElementary.Adjunction{i,3}(1,j),rootNodeLabel)
                                    BranchesToChoseFrom{i,1}=[BranchesToChoseFrom{i,1} AvailableElementary.Adjunction{i,2}(1,j)];
                                    SelectRandomLabelSucceed=1;
                                end
                            end
                        end
                    end
                    
                    % Chose a random elementary tree
                    SelectRandomElementaryIndexSucceed=0;
                    while SelectRandomElementaryIndexSucceed~=1
                        RandomElementaryTreeIndex=randi([1,noElemTrees],1,1);
                        
                        
                        % Verify if it has a branch with the same label as the chosen
                        % one (rootNodeLabel) by doing if isempty(BranchesToChoseFrom{randomelementarytree,1})
                        if ~isempty(BranchesToChoseFrom{RandomElementaryTreeIndex,1})
                            SelectRandomElementaryIndexSucceed=1;
                            
                            selectBranchIndex=randi([1,length(BranchesToChoseFrom{RandomElementaryTreeIndex,1})],1,1); % randomly select an available order index
                            BranchIndex=BranchesToChoseFrom{RandomElementaryTreeIndex,1}(selectBranchIndex);
                            
                            treetype=AuxiliaryTreeTypes.typesArray{selectAuxTreeType}; % get the tree type
                            
                            linkflagOK=0;
                            %                             while linkflagOK==0
                            %
                            LinkInfo=randi([0,1],1,max([ny,nu,nE])); % propose a random linking matrix
                            %                                 if ~isempty(find(LinkInfo(1:min(ny,nu))==1)) % Check if there is at least one spot filled with one from index 1 to min of (ny,nu) to avoid linking vectors full of zeros!
                            %                                     linkflagOK=1;
                            %                                 end
                            %                             end
                            %
                            %                             if isempty(find(LinkInfo(1:min(ny,nu))==1))
                            %                                 dbstop in TAGMutation at 429 LinkInfo is full 0.
                            %                             end % propose a random linking matrix
                            work_tree=CreateAuxTree(treetype,LinkInfo,ny,nu,nE,MaskLink); % create a tree of that type
                            
                            
                            % DerivedTree,AuxiliaryTree,ElementaryArrayIndex,BranchIndex
                            
                            
                            [Error,ResultedTreeFromOperation]=Adjunction(DerivedTreeDevelopment{constructionCounter},work_tree,RandomElementaryTreeIndex,BranchIndex,InitTreeTypes);
                            
                            ConstructionDebug{constructionCounter,1}=constructionCounter;% DEBUG ONLY!
                            ConstructionDebug{constructionCounter,2}=RandomElementaryTreeIndex;% DEBUG ONLY!
                            ConstructionDebug{constructionCounter,3}=work_tree.name;% DEBUG ONLY!
                            ConstructionDebug{constructionCounter,4}=rootNodeLabel; % DEBUG ONLY!
                            
                            if Error==0
                                OperationDone=1;
                            else
                                display("Error happened")
                                Error=1;
                            end
                            
                            
                        end
                    end
                end % If constructioncounter==1
                if OperationDone==1 % if the operation is done, increment the construction counter
                    constructionCounter=constructionCounter+1;
                    DerivedTreeDevelopment{constructionCounter}= ResultedTreeFromOperation;
                    partiallyDerivationTree=DerivedTreeDevelopment{constructionCounter}.DerivationTree; % for debug only!
                    Labels=GetTreeDerivation(DerivedTreeDevelopment{constructionCounter});
                    
                else
                    if Error~=0
                        
                        DerivedTreeDevelopment{constructionCounter}=SaveDerivedTreeDevelopment;
                    end
                    if Error==0
                        if NoAvailableNodes==1
                            disp("Random Operation was not possible due to lack of available nodes")
                            
                        end
                        if SubstitutionNotAvailable==1
                            %                 disp("Substitution is not available for this model set");
                        end
                        
                    end
                end
            end
        end
        
    end
    
    Offspring=DerivedTreeDevelopment{AdditionalComplexityOrder+1};
    
    % DISPLAYED VALUES for Debug!!!
    if DeleteContentFlag==0
        MutationPoint.ParentRandomLabel="No deletion happened";
        MutationPoint.ParentDetachedIndex="No deletion happened";
    else
        MutationPoint.ParentRandomLabel=RandomLabelParent;
        MutationPoint.ParentDetachedIndex=RandomPointParent;
    end
    
    MutationPoint.LengthOfMutation=AdditionalComplexityOrder;
    MutationPoint.ParentHostIndex=RandomHostPointParent;%Where parent1 will receive the information from Detached part of Parent2
    
    % if numberOfNewElementaryTrees == 0 then the MutationStartingTreeType variable is not
    % filled in, therefore it has to be initialised with ("Mutation growth not produced,
    % random numberOfNewElementaryTrees ==0 ")
    
    if numberOfNewElementaryTrees ==0
        MutationStartingTreeType=("Mutation growth not produced, random numberOfNewElementaryTrees ==0 ");
    end
    
    MutationPoint.MutationStartTreeType=MutationStartingTreeType;
    
else
    % if the creation flag is not true, than the newParent is given as
    % offspring even if it got some information deleted or not!
    Offspring = newParent;
    
    % DISPLAYED VALUES for Debug!!!
    if DeleteContentFlag==0
        MutationPoint.ParentRandomLabel="No deletion happened";
        MutationPoint.ParentDetachedIndex="No deletion happened";
    else
        MutationPoint.ParentRandomLabel=RandomLabelParent;
        MutationPoint.ParentDetachedIndex=RandomPointParent;
    end
    MutationPoint.LengthOfMutation="No creation added";
    MutationPoint.ParentHostIndex="No creation added";%Where parent1 will receive the information from Detached part of Parent2
    
    % if numberOfNewElementaryTrees == 0 then the MutationStartingTreeType variable is not
    % filled in, therefore it has to be initialised with ("Mutation growth not produced,
    % random numberOfNewElementaryTrees ==0 ")
    
    
    MutationStartingTreeType=("Mutation growth not produced, random numberOfNewElementaryTrees ==0 ");
    
    
    MutationPoint.MutationStartTreeType=MutationStartingTreeType;
    
end

if ChangeLinkMatrixFlag==1
    % Create a copy of the parent to prepare it for a Change on a Link
    % Matrix extry
    copyParentElementaryArrayTypes=[Parent.DerivationTree.ElementaryArrayTypes];
    copyParentElementaryArray=[Parent.DerivationTree.ElementaryArray];
    copyParentAdiacentMatrix=Parent.DerivationTree.AdiacentMatrix;
    
    len_copyParentElementaryArray=length(copyParentElementaryArrayTypes);
    ChangeLinkMatrixIndex=randi([2,len_copyParentElementaryArray],1,1);
    while ~isnumeric(copyParentElementaryArray(ChangeLinkMatrixIndex,1).LinkInfo)
        ChangeLinkMatrixIndex=randi([2,len_copyParentElementaryArray],1,1);
    end
    
    copyParentCreationInformation.parent=zeros(len_copyParentElementaryArray,1);
    copyParentCreationInformation.parentBranchIndex=zeros(len_copyParentElementaryArray,1);
    copyParentCreationInformation.TreeType=cell(len_copyParentElementaryArray,1);
    copyParentCreationInformation.ConnectionOperator=cell(len_copyParentElementaryArray,1);
    copyParentCreationInformation.LinkInfo=cell(len_copyParentElementaryArray,1);
    
    for i=1:len_copyParentElementaryArray
        for j=1:len_copyParentElementaryArray
            if copyParentAdiacentMatrix(i,j)~=0
                copyParentCreationInformation.parent(j,1)=i;
                copyParentCreationInformation.parentBranchIndex(j,1) = copyParentElementaryArray(j,1).parentBranchIndex;
                copyParentCreationInformation.TreeType{j,1} = copyParentElementaryArrayTypes(j,1);
                copyParentCreationInformation.ConnectionOperator{j,1}=copyParentElementaryArray(j,1).ConnectionOperator;
                
                if j==ChangeLinkMatrixIndex
                    copyParentCreationInformation.LinkInfo{j,1}=randi([0,1],size(copyParentElementaryArray(ChangeLinkMatrixIndex,1).LinkInfo));
                else
                    copyParentCreationInformation.LinkInfo{j,1}=copyParentElementaryArray(j,1).LinkInfo;
                end
                
            end
        end
    end
    
    RootOfnewParent = find(copyParentCreationInformation.parent==0);
    copyParentCreationInformation.TreeType{RootOfnewParent,1}=copyParentElementaryArrayTypes(RootOfnewParent,1);
    copyParentCreationInformation.ConnectionOperator{RootOfnewParent,1}="Initialisation";
    %% creating the tree after the mutation index
    
    [Error,newParent] = CreateComplexTree(copyParentCreationInformation,ny,nu,nE,InitTreeTypes,MaskLink);
    
    
    Offspring = newParent;
    % DISPLAYED VALUES for Debug!!!
    if DeleteContentFlag==0
        MutationPoint.ParentRandomLabel="No deletion happened";
        MutationPoint.ParentDetachedIndex="No deletion happened";
    else
        MutationPoint.ParentRandomLabel=RandomLabelParent;
        MutationPoint.ParentDetachedIndex=RandomPointParent;
    end
    MutationPoint.LengthOfMutation="No creation added";
    MutationPoint.ParentHostIndex="No creation added";%Where parent1 will receive the information from Detached part of Parent2
    
    % if numberOfNewElementaryTrees == 0 then the MutationStartingTreeType variable is not
    % filled in, therefore it has to be initialised with ("Mutation growth not produced,
    % random numberOfNewElementaryTrees ==0 ")
    disp(strcat("Link matrix changed at:",num2str(ChangeLinkMatrixIndex)));
    
    MutationStartingTreeType=(strcat("Mutation growth not produced, The Link matrix chaged at:",num2str(ChangeLinkMatrixIndex)));
    
    
    MutationPoint.MutationStartTreeType=MutationStartingTreeType;
end

end

