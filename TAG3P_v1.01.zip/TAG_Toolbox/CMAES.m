% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
% The Covariance Matrix Adaptation - Evolutionary strategy core script was
% provided by the algorithm authors: Nikolaus Hansen and Andreas
% Ostermeier. The CMA-ES algorithm is developed and described by Nikolaus
% Hansen and Andreas Ostermeier in "Completely Derandomized Self-Adaptation in Evolution
% Strategies" In Evolutionary Computation, 9(2), pp. 159-195 (2001) please
% refer to this paper for more information about CMA-ES.
function [FittedparamArray,FittingPerformance,Runtime] = CMAES(individual,Data,Parameters)
%% CMA-ES for non-linear function minimization
% See also http://www.bionik.tu-berlin.de/user/niko

CMAESParam = Parameters.GeneticProgramming.CMAESParam;

tau=Parameters.EquationSolution.tau_param_fitting;

% Set dimension, fitness fct, stop criteria, start values...
CMAES_ParametersInitialScale =CMAESParam.CMAES_ParametersInitialScale; % The initial scale of the parameters:
% User guess A good hinch is to see the ratio between input and output:
% If the output is several magnitudes higher than the input, try a small
% value for CMAES_ParametersInitialScale

CMAES_GivenStopFitness=CMAESParam.CMAES_GivenStopFitness; % CMA-ES fitness limit
CMAES_GivenStopCriterion=CMAESParam.CMAES_GivenStopCriterion;% CMA-ES fitness gradient limit
CMAES_Iterations=CMAESParam.CMAES_Iterations;
MAX_CMAES_Iterations=CMAESParam.MAX_CMAES_Iterations;
CMAES_watchdog=CMAESParam.CMAES_watchdog; % after "CMAES_watchdog" seconds the CMAES stops and return the best set of parameters
MAX_CMAES_watchdog =CMAESParam.MAX_CMAES_watchdog; % 5 mins per each candidate;


N=individual.noParams;
% noCoefParameters=individual.noParams;
% noDelayParameters=individual.noDelayParams;
% N=noCoefParameters+noDelayParameters;
Runtime.SimulationError = 0;
Runtime.PredictionError = 0;
% strfitnessfct = "cigar";
maxeval = CMAES_Iterations*(N+2)^2;
% maxeval=10;
% stopfitness = 1e-9; % stop criteria should be 1e-10
% stop_criterion=1e-10;
stopfitness = CMAES_GivenStopFitness;
stop_criterion= CMAES_GivenStopCriterion;

% CMAES_watchdog = max(40,(exp((N)/450))*30);
CMAES_watchdog = max(50,CMAES_Iterations*(N+2)^1.8/1.8e+5);

% stopfitness=1e-1;
% stop_criterion=1e-1;

xmeanw = CMAES_ParametersInitialScale*rand(N, 1); % object parameter start point (weighted mean)
sigma = CMAES_ParametersInitialScale*1;
minsigma = 1e-15; % step size, minimal step size

% Parameter setting: selection,
lambda = 4 + floor(3*log(N));
mu = floor(lambda/2);
arweights = log((lambda+1)/2) - log(1:mu)'; % for recombination

% parameter setting: adaptation
cc = 4/(N+4);
ccov = 2/(N+2^0.5)^2;
cs = 4/(N+4);
alfa=1;
damp = alfa/cs + 1;

% Initialize dynamic strategy parameters and constants
B = eye(N);
D = eye(N);
BD = B*D;
C = BD*transpose(BD);
pc = zeros(N,1);
ps = zeros(N,1);
cw = sum(arweights)/norm(arweights);
chiN = N^0.5*(1-1/(4*N)+1/(21*N^2));

% Generation loop
counteval = 0;
arfitness(1) = 2*abs(stopfitness)+1;
last_best_fitness=1500;
second_last_best_fitness=1500;
third_last_best_fitness=1550;
forth_last_best_fitness=1600;
fitness_gradient=1000;
FittingPerformance = inf;
WorkVariable_SumativeSimulationError=0;
WorkVariable_SumativePredictionError=0;
Performance_NanInf_Tryouts = 10;
counter_NanInf_Tryout=0;
if N>=1
    Watchdog=tic;
    FlagTimeout=0;
    % Why this while is here: If the CMAES swarn optimisation starts from a
    % initial set of parameters that makes the system instable, the fitting
    % performance will turn very quickly to Nan or Inf => thus the CMAES
    % did not converge, although the structure might be good but needs
    % another set of initial parameters. For each time a set of parameters
    % is proposet the counter for Nan or Inf Tryouts is increased, if the
    % set of parameters produces a non Nan or Inf fitting value then the
    % set is valid, else the optimisation problem is run again.
    while ( (FittingPerformance == inf | isnan(FittingPerformance)) && counter_NanInf_Tryout <= Performance_NanInf_Tryouts )
        
        %         while arfitness(1) > stopfitness && counteval < maxeval && fitness_gradient>stop_criterion && FlagTimeout==0
        while arfitness(1) > stopfitness && counteval < maxeval && FlagTimeout==0
            % Generate and evaluate lambda offspring
            if toc(Watchdog)>CMAES_watchdog
                FlagTimeout=1;
            end
            
            for k=1:lambda
                % repeat the next two lines until arx(:,k) is feasible
                arz(:,k) = randn(N,1);
                arx(:,k) = xmeanw + sigma * (BD * arz(:,k)); % Eq.(13)
                %             arx(:,k) =
                %             [arx(1:noCoefParameters,k);max(0,floor(arx(noCoefParameters+1:noCoefParameters+noDelayParameter,k)))]
                %             noCoefParameters= number of coeficients, real, to be fitted
                %             to the structure,
                %             noDelayParameters = number of transport delays per dynamicsal
                %             structure. Delay parameters are in [0 maxTransportDelay]
                individual.paramArray=arx(:,k)';
                
                WorkVariable_SumativePredictionError=0;
                WorkVariable_SumativeSimulationError=0;
                SimulationError_generator = tic; % Profiling
                %% Generate Simulation error for each training data set
                for counter =1:length(Data.uTrain)
                    DataSetIdentifier.uCellIndex =counter;
                    DataSetIdentifier.yCellIndex =counter;
                    DataSetIdentifier.Train =1;
                    DataSetIdentifier.Test =0;
                    DataSetIdentifier.Valid =0;
                    [WorkVariable_SimulationError,~]=SimulationError(individual,Data,DataSetIdentifier);
                    WorkVariable_SumativeSimulationError = WorkVariable_SumativeSimulationError+WorkVariable_SimulationError;
                end
                % si
                arxSimulation_Error(1,k) = WorkVariable_SumativeSimulationError/length(Data.uTrain);
                
                Runtime.SimulationError = Runtime.SimulationError + toc(SimulationError_generator);
                
                PredictionError_generator = tic; % Profiling
                for counter =1:length(Data.uTrain)
                    DataSetIdentifier.uCellIndex =counter;
                    DataSetIdentifier.yCellIndex =counter;
                    DataSetIdentifier.Train =1;
                    DataSetIdentifier.Test =0;
                    DataSetIdentifier.Valid =0;
                    [WorkVariable_PredictionError,~]=PredictionError(individual,Data,DataSetIdentifier);
                    WorkVariable_SumativePredictionError = WorkVariable_SumativePredictionError+WorkVariable_PredictionError;
                end
                arxPrediction_Error(1,k) = WorkVariable_SumativePredictionError/length(Data.uTrain);
                Runtime.PredictionError = Runtime.PredictionError + toc(PredictionError_generator);
                
                if arxSimulation_Error(1,k)==inf || isnan(arxSimulation_Error(1,k))
                    arfitness(k) = CMAESParam.w_pred*arxPrediction_Error(1,k);
                else
                    if arxPrediction_Error(1,k) == inf || isnan(arxPrediction_Error(1,k))
                        arfitness(k) = CMAESParam.w_sim*arxSimulation_Error(1,k);
                    else
                        arfitness(k) = (CMAESParam.w_sim*arxSimulation_Error(1,k) + CMAESParam.w_pred*arxPrediction_Error(1,k))/2;
                    end
                end
                
                %         arfitness(k) = arxPrediction_Error(1,k);
                %         arfitness(k) = arxSimulation_Error(1,k);
                counteval = counteval+1;
            end
            
            % Sort by fitness and compute weighted mean
            [arfitness, arindex] = sort(arfitness); % minimization
            
            %stop_criterion based on fitness gradiend flattenning
            fitness_gradient=sqrt((last_best_fitness - arfitness(1))^2 + (second_last_best_fitness - last_best_fitness)^2 + (third_last_best_fitness - forth_last_best_fitness)^2);
            forth_last_best_fitness=third_last_best_fitness;
            third_last_best_fitness=second_last_best_fitness;
            second_last_best_fitness=last_best_fitness;
            last_best_fitness=arfitness(1);
            
            xmeanw = arx(:,arindex(1:mu))*arweights/sum(arweights);
            zmeanw = arz(:,arindex(1:mu))*arweights/sum(arweights);
            
            
            % Adapt covariance matrix
            pc = (1-cc)*pc + (sqrt(cc*(2-cc))*cw) * (BD*zmeanw); % Eq.(14)
            C = (1-ccov)*C + ccov*pc*transpose(pc); % Eq.(15)
            
            % adapt sigma
            ps = (1-cs)*ps + (sqrt(cs*(2-cs))*cw) * (B*zmeanw); % Eq.(16)
            sigma = sigma * exp((norm(ps)-chiN)/chiN/damp); % Eq.(17)
            
            % Update B and D from C
            if mod(counteval/lambda, N/10) < 1
                C=triu(C)+transpose(triu(C,1)); % enforce symmetry
                [B,D] = eig(C);
                
                % limit condition of C to 1e14 + 1
                if max(diag(D)) > 1e14*min(diag(D))
                    tmp = max(diag(D))/1e14 - min(diag(D));
                    C = C + tmp*eye(N);
                    D = D + tmp*eye(N);
                    
                end
                D = diag(sqrt(diag(D))); % D contains standard deviations now
                BD = B*D; % for speed up only
            end % if mod
            % Adjust minimal step size
            if sigma*min(diag(D)) < minsigma | arfitness(1) == arfitness(min(mu+1,lambda)) | xmeanw == xmeanw + 0.2*xmeanw + 0.2*sigma*BD(:,1+floor(mod(counteval/lambda,N)))
                sigma = 1.4*sigma;
            end
            
        end % while, end generation loop
        % display(strcat([num2str(counteval),": ", num2str(arfitness(1))]));
        FittedparamArray = arx(:, arindex(1))'; % return best point of last generation
        FittingPerformance= arfitness(1);
        counter_NanInf_Tryout=counter_NanInf_Tryout+1;
    end
else
    FittedparamArray="No Parameters";
    individual.paramArray=0;
    [arxSimulation_Error,~,~]=SimulationError(individual,u,y,E,t,tau);
    [arxPrediction_Error,~,~]=PredictionError(individual,u,y,E,t);
    FittingPerformance=  w_sim*arxSimulation_Error + w_pred*arxPrediction_Error;
end
if counter_NanInf_Tryout>1
    %     disp("CMAES retry")
    %     counteval
    %     counter_NanInf_Tryout
end
end

