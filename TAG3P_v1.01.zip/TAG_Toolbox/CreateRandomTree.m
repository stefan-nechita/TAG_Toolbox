% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

function [DerivedTree,ConstructionDebug] = CreateRandomTree(ComplexityOrder,InitTreeTypes,AuxiliaryTreeTypes,EquationSolutionParam)
%% This function creates a random  derived tree and its derivation tree
% Output:
% DerivationTree = an array of steps required to rebuild the tree
% DerivatedTree = A Tree new entity
% Input:
% ComplexityOrder = how many substitution/adjunction will be done (initialisation does not count)
% InitTreeTypes = a structure that has all the information about the
% available Initial tree types:

% InitTreeTypes.typesArray = an array of strings where each cell is a known init type
% InitTreeTypes.typeRootNode = an array of strings where each cell is the
% label of the root node of each Init Tree

% InitTreeTypes.starterIndex = The index until one can pick a starter
% initial Tree (from 1 to index)

% InitTreeTypes.noInitTrees;

% AuxTreeTypes = similar to the initTreeTypes but for Auxiliary trees,
% it has no starterIndex number.

% ny= dimension of output;
% nu= dimension of input;

nu = EquationSolutionParam.nu;
ny = EquationSolutionParam.ny;
nE = EquationSolutionParam.nE;
MaskLink = EquationSolutionParam.MaskLink;

ConstructionDebug=[];% DEBUG
constructionCounter=1;
DerivedTreeDevelopment=cell(1,ComplexityOrder);
InitTypeIndex=randi(InitTreeTypes.starterIndex,1,1); % pick a random initial tree type
DerivedTreeDevelopment{1}=CreateInitTree(InitTreeTypes.typesArray{InitTypeIndex});


%% Start the Tree with an starter Init Tree

constructionCounter=1;

while constructionCounter<=ComplexityOrder
    OperationDone=0; % reset the flag if the operation is done
    Error=0;% reset the flag if error occured
    NoAvailableNodes=0; %reset the flag for available nodes: this comes because first,
    SubstitutionNotAvailable=0; % reset the flag for availabeSubstitution
    % the TAg operator is randomly selected and than it is checked if
    % the operator can be performed
    work_tree=[]; % reset the working_tree
    SaveDerivedTreeDevelopment=DerivedTreeDevelopment{constructionCounter};
    
    AvailableElementary = GetAvailableElementaryTrees(DerivedTreeDevelopment{constructionCounter});
    
    
    if AvailableElementary.substitutionFlag==1
        % If substitution is available, then perform substitution, else if
        % adjunction is available, perform adjunction
        % substitution selected
        if InitTreeTypes.noInitTrees>=InitTreeTypes.starterIndex+1 % check if the model set permit Substitutions, for ARX it does not
            SelectRandomLabelSucceed=0;
            while SelectRandomLabelSucceed~=1
                %% Step 1 Select the auxiliary tree and branch where to substitute.
                selectInitTreeType=randi([InitTreeTypes.starterIndex+1 InitTreeTypes.noInitTrees],1,1);
                %% Step 2 Select the initial tree root label from available ones
                rootNodeLabel=InitTreeTypes.typeRootNode{selectInitTreeType};
                %--- determine which Elementary tree has a free branch with branch label == rootNodeLabel
                [noElemTrees,~]=size(AvailableElementary.Substitution);
                %% Step 3 Construct a list of available branches for substitution
                BranchesToChoseFrom=[];
                BranchesToChoseFromIndexes=[];
                BranchesToChoseFrom=cell(noElemTrees,1);
                for i=1:noElemTrees
                    noAvailableBranches=length(AvailableElementary.Substitution{i,3});
                    for j=1:noAvailableBranches
                        if strcmp(AvailableElementary.Substitution{i,3}(1,j),rootNodeLabel)
                            BranchesToChoseFrom{i,1}=[BranchesToChoseFrom{i,1} AvailableElementary.Substitution{i,2}(1,j)];
                            SelectRandomLabelSucceed=1;
                            BranchesToChoseFromIndexes=[BranchesToChoseFromIndexes ; i];
                        end
                    end
                end
            end
            %% Step 3 Select a random initial tree type that have that root label
            SelectRandomElementaryIndexSucceed=0;
            while SelectRandomElementaryIndexSucceed~=1
                
                RandomElementaryTreeIndex=BranchesToChoseFromIndexes(randi([1,length(BranchesToChoseFromIndexes)],1,1));
                
                % Verify if it has a branch with the same label as the chosen
                % one (rootNodeLabel) by doing if isempty(BranchesToChoseFrom{randomelementarytree,1})
                if ~isempty(BranchesToChoseFrom{RandomElementaryTreeIndex,1})
                    SelectRandomElementaryIndexSucceed=1;
                    
                    selectBranchIndex=randi([1,length(BranchesToChoseFrom{RandomElementaryTreeIndex,1})],1,1); % randomly select an available order index
                    BranchIndex=BranchesToChoseFrom{RandomElementaryTreeIndex,1}(selectBranchIndex);
                    
                    treetype=InitTreeTypes.typesArray{selectInitTreeType}; % get the tree type
                   
                    
                    %% Step 4 Create the selected initial tree
                    work_tree=CreateInitTree(treetype); % create a tree of that type with the proposed random linking matrix
                    
                    [Error,ResultedTreeFromOperation]=Substitution(DerivedTreeDevelopment{constructionCounter},work_tree,RandomElementaryTreeIndex,BranchIndex);
                   
                    ConstructionDebug{constructionCounter,1}=constructionCounter;% DEBUG ONLY!
                    ConstructionDebug{constructionCounter,2}=RandomElementaryTreeIndex;% DEBUG ONLY!
                    ConstructionDebug{constructionCounter,3}=work_tree.name;% DEBUG ONLY!
                    ConstructionDebug{constructionCounter,4}=rootNodeLabel; % DEBUG ONLY!
                    
                    if Error==0
                        OperationDone=1;
                    else
                        display("Error happened")
                        Error=1;
                    end
                end
            end
            
            
            if OperationDone==1 % if the operation is done, increment the construction counter
                constructionCounter=constructionCounter+1;
                DerivedTreeDevelopment{constructionCounter}= ResultedTreeFromOperation;
                %                 partiallyDerivationTree=DerivedTreeDevelopment{constructionCounter}.DerivationTree; % for debug only!
                %                 Labels=GetTreeDerivation(DerivedTreeDevelopment{constructionCounter}); % for debug only!
                
            else
                if Error~=0
                    
                    DerivedTreeDevelopment{constructionCounter}=SaveDerivedTreeDevelopment;
                end
                if Error==0
                    if NoAvailableNodes==1
                        disp("Random Operation was not possible due to lack of available nodes")
                        
                    end
                    
                end
                
                
            end
            
            
        else
            NoAvailableNodes=1;
        end
        
    else % check if adjunction is available - in 100% of cases it should be available because each new Aux elem tree is adding more labels that can be used for adjunction. The only case when adjunction is not possible is when all the nodes had beed used by auxiliary trees that introduced nodes that were not avaialble for adjunction
        if AvailableElementary.adjunctionFlag==1
            SelectRandomLabelSucceed=0;
            while SelectRandomLabelSucceed~=1
                %--- Select the Random aux tree with a label=rootNodeLabel
                selectAuxTreeType=randi([1 AuxiliaryTreeTypes.noAuxTrees],1,1);
                
                rootNodeLabel=AuxiliaryTreeTypes.typeRootNode{selectAuxTreeType};
                %--- determine which Elementary tree has a free branch with branch label == rootNodeLabel
                [noElemTrees,~]=size(AvailableElementary.Adjunction);
                
                %--- This part is looking through the avaliable elementary trees that
                %have branches with the same label as the randomly chosen
                %label
                BranchesToChoseFrom=[];
                BranchesToChoseFromIndexes=[];
                BranchesToChoseFrom=cell(noElemTrees,1);
                for i=1:noElemTrees
                    noAvailableBranches=length(AvailableElementary.Adjunction{i,3});
                    for j=1:noAvailableBranches
                        if strcmp(AvailableElementary.Adjunction{i,3}(1,j),rootNodeLabel)
                            BranchesToChoseFrom{i,1}=[BranchesToChoseFrom{i,1} AvailableElementary.Adjunction{i,2}(1,j)];
                            SelectRandomLabelSucceed=1;
                            BranchesToChoseFromIndexes=[BranchesToChoseFromIndexes;i];
                        end
                    end
                end
            end
            
            % Chose a random elementary tree
            SelectRandomElementaryIndexSucceed=0;
            while SelectRandomElementaryIndexSucceed~=1
                RandomElementaryTreeIndex=BranchesToChoseFromIndexes(randi([1,length(BranchesToChoseFromIndexes)],1,1));
                
                % Verify if it has a branch with the same label as the chosen
                % one (rootNodeLabel) by doing if isempty(BranchesToChoseFrom{randomelementarytree,1})
                if ~isempty(BranchesToChoseFrom{RandomElementaryTreeIndex,1})
                    SelectRandomElementaryIndexSucceed=1;
                    
                    selectBranchIndex=randi([1,length(BranchesToChoseFrom{RandomElementaryTreeIndex,1})],1,1); % randomly select an available order index
                    BranchIndex=BranchesToChoseFrom{RandomElementaryTreeIndex,1}(selectBranchIndex);
                    treetype=AuxiliaryTreeTypes.typesArray{selectAuxTreeType}; % get the tree type
                    
                    linkflagOK=0;
                    LinkInfo=randi([0,1],1,max([ny,nu,nE])); % propose a random linking matrix
                    
                    
                    work_tree=CreateAuxTree(treetype,LinkInfo,ny,nu,nE,MaskLink); % create a tree of that type with the proposed random linking matrix
                    % DerivedTree,AuxiliaryTree,ElementaryArrayIndex,BranchIndex
                    
                    [Error,ResultedTreeFromOperation]=Adjunction(DerivedTreeDevelopment{constructionCounter},work_tree,RandomElementaryTreeIndex,BranchIndex,InitTreeTypes);
                    %  [Error,ResultedTreeFromOperation]=Adjunction(DerivedTreeDevelopment{constructionCounter},work_tree,RandomElementaryTreeIndex,BranchIndex);
                    
                    ConstructionDebug{constructionCounter,1}=constructionCounter;% DEBUG ONLY!
                    ConstructionDebug{constructionCounter,2}=RandomElementaryTreeIndex;% DEBUG ONLY!
                    ConstructionDebug{constructionCounter,3}=work_tree.name;% DEBUG ONLY!
                    ConstructionDebug{constructionCounter,4}=rootNodeLabel; % DEBUG ONLY!
                    
                    if Error==0
                        OperationDone=1;
                    else
                        display("Error happened")
                        Error=1;
                    end
                    
                    
                end
            end
            if OperationDone==1 % if the operation is done, increment the construction counter
                constructionCounter=constructionCounter+1;
                DerivedTreeDevelopment{constructionCounter}= ResultedTreeFromOperation;
                %                 partiallyDerivationTree=DerivedTreeDevelopment{constructionCounter}.DerivationTree; % for debug only!
                %                 Labels=GetTreeDerivation(DerivedTreeDevelopment{constructionCounter}); % for debug only!
                
            else
                if Error~=0
                    
                    DerivedTreeDevelopment{constructionCounter}=SaveDerivedTreeDevelopment;
                end
                if Error==0
                    if NoAvailableNodes==1
                        disp("Random Operation was not possible due to lack of available nodes")
                        
                    end
                    
                end
                
                
            end
            
            
        end
        
        
    end
end
DerivedTree=DerivedTreeDevelopment{ComplexityOrder+1};
end


