% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
function Label=GetLabel(TreeRoot,Label) 
%% The function provides a list of all the labels in a TAG Tree
% We are starting the exploration from
% the Tree's root and not the Tree structure, because the root is a node
% type of object, the Tree object is a structure.

if ~isempty(TreeRoot.offspring{1,1})
    Label=[GetLabel(TreeRoot.offspring{1,1},Label)];
end
if ~isempty(TreeRoot.offspring{1,2})
    Label=[GetLabel(TreeRoot.offspring{1,2},Label)];
end
if ~isempty(TreeRoot.offspring{1,3})
    Label=[GetLabel(TreeRoot.offspring{1,3},Label)];
end
Label=[Label;TreeRoot.label];
end