% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to
% SysId 2021 conference.

function [Fobj] = SimulationAndPredictionErrorFitness(x,additional_parameters)

individual=additional_parameters.individual;
Data=additional_parameters.Data;
N=individual.noParams;
DataSetSimError=0;
SimError=0;
WorkVariable_SumativeSimulationError=0;
%% Simulation error average over data sets
for counter =1:length(Data.uTrain)
    DataSetIdentifier.uCellIndex =counter;
    DataSetIdentifier.yCellIndex =counter;
    DataSetIdentifier.Train =1;
    DataSetIdentifier.Test =0;
    DataSetIdentifier.Valid =0;
    
    uCellIndex=DataSetIdentifier.uCellIndex;
    yCellIndex=DataSetIdentifier.yCellIndex;
    if  DataSetIdentifier.Train ==1
        uSelectedDataSet = Data.uTrain{1,uCellIndex};
        ySelectedDataSet = Data.yTrain{1,yCellIndex};
    end
    
    u=[];
    y=[];
    [~,length_time]=size(uSelectedDataSet);
    if Data.ZeroProcessNoiseFlag == 1
        E = zeros(1, length_time); % zeros
        u = [u uSelectedDataSet];
        y = [y ySelectedDataSet];
    else
        E = Data.NoiseAmplitude*randn(1,length_time); % Normally distributed random variable
        
        u = [u uSelectedDataSet];
        y = [y ySelectedDataSet];
    end
    
    w_sim=additional_parameters.w_sim;
    w_pred=additional_parameters.w_pred;
    
    
    N=individual.noParams;
    SimError=0;
    Fcn=individual.fcn;
    noDelays=individual.noDelays;
    noParameters=individual.noParams;
    
    % prepare data for simulation!
    [nu,length_time]=size(u);
    [ny,length_time]=size(y);
    [nE,length_time]=size(E);
    
    u_compare=[zeros(nu,noDelays) u(:,1:length_time)];
    y_compare=[ones(ny,noDelays).*y(:,1) y(:,1:length_time)]; % If the input was 0 before the starting of the simulation,
    E_compare=[zeros(nE,noDelays) E(:,1:length_time)];
    y_hat=zeros(ny,noDelays+length_time);
    
    % Set the initial condition (the constant to shift the results!)
    k=noDelays+1;
    y_hat(:,1:k)=y_compare(:,1:k);
    k=k+1;% set the initial condition
    while k<=length_time+noDelays
        y_hat(:,k)=Fcn(x,y_hat,u_compare,E_compare,k);
        k=k+1;
    end
    
    for output_counter=1:ny
        SimErrorOutput(output_counter,:) = sqrt(sum((y_hat(output_counter,:)-y_compare(output_counter,:)).^2)/length_time); % Root Mean square error
    end
    DataSetSimError=mean(SimErrorOutput);
    
    WorkVariable_SumativeSimulationError = WorkVariable_SumativeSimulationError+DataSetSimError;
end

SimError=WorkVariable_SumativeSimulationError/length(Data.uTrain);
%% Prediction error average over data sets

PredError=0;
DataSetPredError=0;
WorkVariable_SumativePredictionError=0;
for counter =1:length(Data.uTrain)
    DataSetIdentifier.uCellIndex =counter;
    DataSetIdentifier.yCellIndex =counter;
    DataSetIdentifier.Train =1;
    DataSetIdentifier.Test =0;
    DataSetIdentifier.Valid =0;
    
    uCellIndex=DataSetIdentifier.uCellIndex;
    yCellIndex=DataSetIdentifier.yCellIndex;
    if  DataSetIdentifier.Train ==1
        uSelectedDataSet = Data.uTrain{1,uCellIndex};
        ySelectedDataSet = Data.yTrain{1,yCellIndex};
    end
    
    u=[];
    y=[];
    [~,length_time]=size(uSelectedDataSet);
    if Data.ZeroProcessNoiseFlag == 1
        E = zeros(1, length_time); % zeros
        u = [u uSelectedDataSet];
        y = [y ySelectedDataSet];
    else
        E = Data.NoiseAmplitude*randn(1,length_time); % Normally distributed random variable
        
        u = [u uSelectedDataSet];
        y = [y ySelectedDataSet];
    end
    
    w_sim=additional_parameters.w_sim;
    w_pred=additional_parameters.w_pred;
    
    
    Fcn=individual.fcn;
    noDelays=individual.noDelays;
    noParameters=individual.noParams;
    % prepare data for simulation!
    [nu,length_time]=size(u);
    [ny,length_time]=size(y);
    [nE,length_time]=size(E);
    u_compare=[zeros(nu,noDelays) u];
    y_compare=[ones(ny,noDelays).*y(:,1) y(:,1:end)];% If the input was 0 before the starting of the simulation,
    % then the output of the system was unchanged from the past until the time
    % sample of the simulation.
    E_compare=[zeros(nE,noDelays) E(:,1:end)];
    % then the output of the system was unchanged from the past until the time
    % sample of the simulation.
    y_hat=zeros(ny,noDelays+length_time);
    % E=[zeros(ny,noDelays+length_time)];
    
    
    % y_hat_2=zeros(1,noDelays+length_time);
    k=noDelays+1;
    while k<=noDelays+length_time
        y_hat(:,k)=Fcn(x,y_compare,u_compare,E_compare,k);
        k=k+1;
    end
    % Idea: predict only half of the time... useless idea
    for output_counter=1:ny
        PredErrorOutput(output_counter) = sqrt(sum((y_hat(output_counter,:)-y_compare(output_counter,:)).^2)/length_time); %  RootMean square error
    end
    DataSetPredError=mean(PredErrorOutput);
    
    
    WorkVariable_SumativePredictionError = WorkVariable_SumativePredictionError+DataSetPredError;
end
PredError=WorkVariable_SumativePredictionError/length(Data.uTrain);


FitnessSimulation_Error=SimError;
FitnessPrediction_Error=PredError;

if (FitnessSimulation_Error==inf || isnan(FitnessSimulation_Error))
    Fobj = w_pred*FitnessPrediction_Error;
else
    if (FitnessPrediction_Error == inf || isnan(FitnessPrediction_Error))
        Fobj = w_sim*FitnessSimulation_Error;
    else
        Fobj = (w_sim*FitnessSimulation_Error + w_pred*FitnessPrediction_Error)/2;
    end
end

end

