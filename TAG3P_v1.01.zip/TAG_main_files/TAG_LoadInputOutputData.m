% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Msc Student within Control Systems reseach group
% at Technical University of Eindhoven.
% In case of using the code, contact the author at: s.nechita@student.tue.nl
% Parts of the implementation are described in the Internship report file
% submited in Feb 2020

%Initialise Input - Output data.

% ParralelWienerHammerstein nonlinear-benchmark model
load('.\Data_ParralelWienerHammerstein\ParWHData.mat')

Parameters.GeneticProgramming.GenerateNewDataSets = 1; % 0 / 1 Generate or not a new data set trigger for an external data generating function
Parameters.GeneticProgramming.TrainingDataSets = 5; % Number of Training Data Sets
Parameters.GeneticProgramming.TestingDataSets  = 3; % Number of Testing Data Sets
Parameters.GeneticProgramming.ValidationDataSets = 2; % Number of Validation Data Sets


%% Initialising Data containers
Data.uTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
Data.uTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
Data.uValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);

Data.yTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
Data.yTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
Data.yValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);


% Data.ETrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.ETest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.EValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);

% Data.NumberOfSamples=16384*2;
Data.NumberOfSamples=16384/16;
Data.Ts =1/fs;
Data.nu = 1; % Number of Input channels
Data.ny = 1; % Number of Output channels
Data.nE = 1; % Number of Process noise channels

Data.NETrain = 1;% Number of process noise instances to be generated for/within parameter estimation procedure
Data.ZeroProcessNoiseFlag = 0;% 0 / 1, 1 = the process noise will be zero; 0 = the process noise will be normal distributed random variable;


NAmps= length(amp);
NMultisine=20; % for estimation only.
MultisineToChoose=[1,5,10,15,20];  % for estimation only.
CounterDataSet=1;
for CounterMultisine=1:length(MultisineToChoose)
    for CounterAMps =1:NAmps
        WorkVariableU=uEst(:,:,MultisineToChoose(CounterMultisine),CounterAMps)';
                Data.uTrain{1,CounterDataSet}= [WorkVariableU(1,1:Data.NumberOfSamples)];
%         Data.uTrain{1,CounterDataSet}= [WorkVariableU(1,:), WorkVariableU(2,:)];
        WorkVariableY = yEst(:,:,MultisineToChoose(CounterMultisine),CounterAMps)';
                Data.yTrain{1,CounterDataSet}= [WorkVariableY(1,1:Data.NumberOfSamples)];
%         Data.yTrain{1,CounterDataSet}= [WorkVariableY(1,:), WorkVariableY(2,:)];
        CounterDataSet=CounterDataSet+1;
    end
end

CounterDataSet=1;
MultisineToChoose=[1]; % for validation
for CounterMultisine=1:length(MultisineToChoose)
    for CounterAMps =1:NAmps
        WorkVariableU = uVal(:,:,MultisineToChoose(CounterMultisine),CounterAMps)';
                Data.uTest{1,CounterDataSet}= [WorkVariableU(1,1:8*Data.NumberOfSamples)];
%         Data.uTest{1,CounterDataSet}= [WorkVariableU(1,:), WorkVariableU(2,:)];
        WorkVariableY = yVal(:,:,MultisineToChoose(CounterMultisine),CounterAMps)';
                Data.yTest{1,CounterDataSet}= [WorkVariableY(1,1:8*Data.NumberOfSamples)];
%         Data.yTest{1,CounterDataSet}= [WorkVariableY(1,:), WorkVariableY(2,:)];
        CounterDataSet=CounterDataSet+1;
    end
end
WorkVariableU= uValArr';
Data.uValid{1,1}=[WorkVariableU(1,1020:end)];
% Data.uValid{1,1}=[WorkVariableU(1,:)];
WorkVariableY =  yValArr';
Data.yValid{1,1}= [WorkVariableY(1,1020:end)];
% Data.yValid{1,1}= [WorkVariableY(1,:)];


whitenoisemean=mean(WorkVariableU(1,100:1000));
whitenoisestd=std(WorkVariableU(1,100:1000));
MeasuredNoise = (WorkVariableU(1,100:1000) - whitenoisemean);
Data.NoiseAmplitude = whitenoisestd;

GeneratedWhiteNoise = whitenoisestd*randn(1,length(WorkVariableU(1,100:1000)));
Parameters.GeneticProgramming.TrainingDataSets = length(Data.uTrain); % Number of Training Data Sets
Parameters.GeneticProgramming.TestingDataSets  =  length(Data.uTest); % Number of Testing Data Sets
Parameters.GeneticProgramming.ValidationDataSets = length(Data.uValid); % Number of Validation Data Sets


StandardiseInputOutput
clear amp ans uEst uVal whitenoisemean MeasuredNoise whitenoisestd uValArr yEst yVal yValArr lines fs WorkVariableY WorkVariableU NAmps NMultisine MultisineToChoose CounterMultisine CounterDataSet CounterAMps

%% Bouc-Wen oscilator DATA
% % Initialising Data containers
%
% Parameters.GeneticProgramming.TrainingDataSets = 5;
% Parameters.GeneticProgramming.TestingDataSets = 5;
% Parameters.GeneticProgramming.ValidationDataSets=2;
% Parameters.GeneticProgramming.GenerateNewDataSets = 1; % 0 / 1 Generate or not a new data set trigger for an external data generating function
% Data.uTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.uTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.uValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
% Data.yTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.yTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.yValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
%
% Data.ETrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.ETest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.EValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
% oldpath = path;
% path(oldpath,".\Data_BoucWen");
% % Data.NumberOfSamples=16384*2;
% Data.NumberOfSamples=2^12;
% Data.Ts =1/750;
% Data.nu = 1; % Number of Input channels
% Data.ny = 1; % Number of Output channels
% Data.nE = 1; % Number of Process noise channels
%
% Data.NETrain = 1;% Number of process noise instances to be generated for/within parameter estimation procedure
% Data.ZeroProcessNoiseFlag = 1;% 0 / 1, 1 = the process noise will be zero; 0 = the process noise will be normal distributed random variable;
% Data.NoiseAmplitude =0;
% if Parameters.GeneticProgramming.GenerateNewDataSets==1
%     for CounterDataSet=1:Parameters.GeneticProgramming.TrainingDataSets
%        [Data.uTrain{1,CounterDataSet},Data.yTrain{1,CounterDataSet}] = BoucWenDataGenerator(Data.NumberOfSamples);
%     end
%
%     for CounterDataSet=1:Parameters.GeneticProgramming.TestingDataSets
%         [Data.uTest{1,CounterDataSet},Data.yTest{1,CounterDataSet}] = BoucWenDataGenerator(Data.NumberOfSamples);
%     end
%
%     load('.\Data_BoucWen\uval_multisine.mat')
%     load('.\Data_BoucWen\yval_sinesweep.mat')
%     load('.\Data_BoucWen\uval_sinesweep.mat')
%     load('.\Data_BoucWen\yval_multisine.mat')
%
%     Data.uValid{1,1} = uval_multisine;
%     Data.uValid{1,2} = uval_sinesweep;
%     Data.yValid{1,1} = yval_multisine;
%     Data.yValid{1,2} = yval_sinesweep;
%
%     StandardiseInputOutput
% end
% clear uval_multisine uval_sinesweep yval_multisine yval_sinesweepa


%% DATA FROM SHIMA
%
%
% Parameters.GeneticProgramming.GenerateNewDataSets = 1; % 0 / 1 Generate or not a new data set trigger for an external data generating function
% Parameters.GeneticProgramming.TrainingDataSets = 1; % Number of Training Data Sets
% Parameters.GeneticProgramming.TestingDataSets  = 1; % Number of Testing Data Sets
% Parameters.GeneticProgramming.ValidationDataSets =1; % Number of Validation Data Sets
%
%
% %% Initialising Data containers
% Data.uTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.uTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.uValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
% Data.yTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.yTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.yValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
%
% Data.ETrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.ETest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.EValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
%
% Data.NumberOfSamples=1500;
% Data.nu = 1; % Number of Input channels
% Data.ny = 1; % Number of Output channels
% Data.nE = 1; % Number of Process noise channels
%
% Data.NETrain = 10;% Number of process noise instances to be generated for/within parameter estimation procedure
% Data.ZeroProcessNoiseFlag = 0;% 0 / 1, 1 = the process noise will be zero; 0 = the process noise will be normal distributed random variable;
%
% load('.\Data_Shima\d_feed_filter.mat')
% load('.\Data_Shima\d_force_filter.mat')
% Data.Ts =1;
% for CounterGeneric =1:Parameters.GeneticProgramming.TrainingDataSets
%     Data.uTrain{1,CounterGeneric}= d_feed_filter(1:Data.NumberOfSamples,1)';
%     Data.yTrain{1,CounterGeneric}= d_force_filter(1:Data.NumberOfSamples,1)';
% end
% clear d_feed_filter
% clear d_force_filter
% load('.\Data_Shima\d_feed_filter_validation.mat')
% load('.\Data_Shima\d_force_filter_validation.mat')
% for  CounterGeneric=1:Parameters.GeneticProgramming.TestingDataSets
%     Data.uTest{1,CounterGeneric}= d_feed_filter(1:Data.NumberOfSamples,1)';
%     Data.yTest{1,CounterGeneric}= d_force_filter(1:Data.NumberOfSamples,1)';
% end
% clear d_feed_filter
% clear d_force_filter
% for  CounterGeneric=1:Parameters.GeneticProgramming.ValidationDataSets
%     Data.uValid{1,CounterGeneric}= zeros(1,Data.NumberOfSamples);
%     Data.yValid{1,CounterGeneric}= zeros(1,Data.NumberOfSamples);
% end
%

%% Couples Drive nonlinear-benchmark model
% load('.\Data_CoupledElectricDrives\DATAUNIF.mat')
% load('.\Data_CoupledElectricDrives\DATAPRBS.mat')
% Data.UseCase =1; % 1= Training Data = PRBS,      Testing Data = Uniform;
%                  % 0= Training Data = Uniform,   Testing Data = PRBS;
%
% switch Data.UseCase
%     case 0
%         Parameters.GeneticProgramming.TrainingDataSets = 2; % Number of Training Data Sets
%         Parameters.GeneticProgramming.TestingDataSets  = 3; % Number of Testing Data Sets
%         Parameters.GeneticProgramming.ValidationDataSets = 3; % Number of Validation Data Sets
%
%         %% Initialising Data containers
%         Data.uTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
%         Data.uTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
%         Data.uValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
%         Data.yTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
%         Data.yTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
%         Data.yValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
%
%         Data.ETrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
%         Data.ETest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
%         Data.EValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
%         % Data.NumberOfSamples=16384*2;
% Data.NumberOfSamples=500;
% Data.Ts =20*1e-3;
% Data.nu = 1; % Number of Input channels
% Data.ny = 1; % Number of Output channels
% Data.nE = 1; % Number of Process noise channels
%
% Data.NETrain = 1;% Number of process noise instances to be generated for/within parameter estimation procedure
% Data.ZeroProcessNoiseFlag = 0;% 0 / 1, 1 = the process noise will be zero; 0 = the process noise will be normal distributed random variable;
%
%
%         Data.uTrain{1,1}= u11';
%         Data.uTrain{1,2}= u12';
%         Data.yTrain{1,1}= z11';
%         Data.yTrain{1,2}= z12';
%
%         Data.uTest{1,1}= u1';
%         Data.uTest{1,2}= u2';
%         Data.uTest{1,3}= u3';
%
%         Data.yTest{1,1}= z1';
%         Data.yTest{1,2}= z2';
%         Data.yTest{1,3}= z3';
%
%     case 1
%         Parameters.GeneticProgramming.TrainingDataSets = 3; % Number of Training Data Sets
%         Parameters.GeneticProgramming.TestingDataSets  = 2; % Number of Testing Data Sets
%         Parameters.GeneticProgramming.ValidationDataSets = 2; % Number of Validation Data Sets
%
%         %% Initialising Data containers
%         Data.uTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
%         Data.uTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
%         Data.uValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
%         Data.yTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
%         Data.yTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
%         Data.yValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
%
%         Data.ETrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
%         Data.ETest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
%         Data.EValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
%         % Data.NumberOfSamples=16384*2;
% Data.NumberOfSamples=500;
% Data.Ts =20*1e-3;
% Data.nu = 1; % Number of Input channels
% Data.ny = 1; % Number of Output channels
% Data.nE = 1; % Number of Process noise channels
%
% Data.NETrain = 2;% Number of process noise instances to be generated for/within parameter estimation procedure
% Data.ZeroProcessNoiseFlag = 0;% 0 / 1, 1 = the process noise will be zero; 0 = the process noise will be normal distributed random variable;
%
%         Data.uTrain{1,1}= u1';
%         Data.uTrain{1,2}= u2';
%         Data.uTrain{1,3}= u3';
%
%         Data.yTrain{1,1}= z1';
%         Data.yTrain{1,2}= z2';
%         Data.yTrain{1,3}= z3';
%
%         Data.uTest{1,1}= u11'
%         Data.uTest{1,2}= u12';
%
%         Data.yTest{1,1}= z11';
%         Data.yTest{1,2}= z12';
%
% end
%
% Parameters.GeneticProgramming.TrainingDataSets = 1; % Number of Training Data Sets
% Parameters.GeneticProgramming.TestingDataSets  = 1; % Number of Testing Data Sets
% Parameters.GeneticProgramming.ValidationDataSets = 1; % Number of Validation Data Sets
%
% %% Initialising Data containers
% Data.uTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.uTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.uValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
% Data.yTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.yTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.yValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
%
% Data.ETrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.ETest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.EValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
% % Data.NumberOfSamples=16384*2;
% Data.NumberOfSamples=500;
% Data.Ts =20*1e-3;
% Data.nu = 1; % Number of Input channels
% Data.ny = 1; % Number of Output channels
% Data.nE = 1; % Number of Process noise channels
%
% Data.NETrain = 1;% Number of process noise instances to be generated for/within parameter estimation procedure
% Data.ZeroProcessNoiseFlag = 0;% 0 / 1, 1 = the process noise will be zero; 0 = the process noise will be normal distributed random variable;
%
%
% Data.uTrain{1,1}= u11';
% Data.yTrain{1,1}= z11';
%
% Data.uTest{1,1}= u12';
% Data.yTest{1,1}= z12';
%
% Data.uValid{1,1}= Data.uTest{1,1};
% Data.yValid{1,1}= Data.yTest{1,1};
%
% Data.NoiseAmplitude = 1;
%
% Parameters.GeneticProgramming.TrainingDataSets = length(Data.uTrain); % Number of Training Data Sets
% Parameters.GeneticProgramming.TestingDataSets  =  length(Data.uTest); % Number of Testing Data Sets
% Parameters.GeneticProgramming.ValidationDataSets = length(Data.uValid); % Number of Validation Data Sets
%
%
% % StandardiseInputOutput
% clear u1 u2 u3 u11 u12 z1 z2 z3 z11 z12
% %

% %% Proposed MIMO sin/cos/abs random academinc model with one process noise
% Parameters.GeneticProgramming.GenerateNewDataSets =1; % 0 / 1 Generate or not a new data set trigger for an external data generating function
% Parameters.GeneticProgramming.TrainingDataSets = 3; % Number of Training Data Sets
% Parameters.GeneticProgramming.TestingDataSets  = 3; % Number of Testing Data Sets
% Parameters.GeneticProgramming.ValidationDataSets = 3; % Number of Validation Data Sets
%
% %% Initialising Data containers
% Data.uTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.uTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.uValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
% Data.yTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.yTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.yValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
%
%
% Data.ETrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.ETest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.EValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
% switch Parameters.GeneticProgramming.GenerateNewDataSets
%     case 1
%         % Data.NumberOfSamples=16384*2;
%         Data.NumberOfSamples=1500;
%
%         load(".\Data_RandomMIMO model\parameters_data.mat")
%         Data.Ts =20*1e-3;
%         Data.nu = 2; % Number of Input channels
%         Data.ny = 2; % Number of Output channels
%         Data.nE = 1; % Number of Process noise channels
%         % NDRvalues=0.4*randn(2,50000);
%         Data.NETrain = 1;% Number of process noise instances to be generated for/within parameter estimation procedure
%         Data.ZeroProcessNoiseFlag = 1;% 0 / 1, 1 = the process noise will be zero; 0 = the process noise will be normal distributed random variable;
%         Data.NoiseAmplitude = 5e-4;
%         CounterRandomValues=1;
%         for CounterDataSets=1:Parameters.GeneticProgramming.TrainingDataSets
%             Data.uTrain{1,CounterDataSets} = [zeros(2,30),NDRvalues(:,(CounterRandomValues-1)*Data.NumberOfSamples+1:CounterRandomValues*Data.NumberOfSamples)];
%             Data.yTrain{1,CounterDataSets} = RandomMimoModel(Data.NumberOfSamples,Data.uTrain{1,CounterDataSets},c);
%             CounterRandomValues=CounterRandomValues+1;
%             Data.uTrain{1,CounterDataSets} = Data.uTrain{1,CounterDataSets}(:,1:Data.NumberOfSamples);
%             figure()
%             subplot(2,1,1)
%             plot(Data.yTrain{1,CounterDataSets}(1,:))
%             subplot(2,1,2)
%             plot(Data.yTrain{1,CounterDataSets}(2,:))
%         end
%
%
%         for CounterDataSets=1:Parameters.GeneticProgramming.TestingDataSets
%             Data.uTest{1,CounterDataSets} = [zeros(2,30),NDRvalues(:,(CounterRandomValues-1)*Data.NumberOfSamples+1:CounterRandomValues*Data.NumberOfSamples)];
%             Data.yTest{1,CounterDataSets} = RandomMimoModel(Data.NumberOfSamples,Data.uTrain{1,CounterDataSets},c);
%             CounterRandomValues=CounterRandomValues+1;
%             Data.uTest{1,CounterDataSets} = Data.uTest{1,CounterDataSets}(:,1:Data.NumberOfSamples);
%
%
%             figure()
%             subplot(2,1,1)
%             plot(Data.yTest{1,CounterDataSets}(1,:))
%             subplot(2,1,2)
%             plot(Data.yTest{1,CounterDataSets}(2,:))
%         end
%
%
%         for CounterDataSets=1:Parameters.GeneticProgramming.ValidationDataSets
%             Data.uValid{1,CounterDataSets} = [zeros(2,30),NDRvalues(:,(CounterRandomValues-1)*Data.NumberOfSamples+1:CounterRandomValues*Data.NumberOfSamples)];
%             Data.yValid{1,CounterDataSets} = RandomMimoModel(Data.NumberOfSamples,Data.uTrain{1,CounterDataSets},c);
%             CounterRandomValues=CounterRandomValues+1;
%             %
%
%             Data.uValid{1,CounterDataSets} = Data.uValid{1,CounterDataSets}(:,1:Data.NumberOfSamples);
%             figure()
%             subplot(2,1,1)
%             plot(Data.yValid{1,CounterDataSets}(1,:))
%             subplot(2,1,2)
%             plot(Data.yValid{1,CounterDataSets}(2,:))
%         end
%
%         clear CounterDataSets CounterRandomValues NDRvalues
%
%     case 0
%
%         load(".\Data_RandomMIMO model\parameters_data.mat")
%         Parameters.GeneticProgramming.GenerateNewDataSets = 0; % 0 / 1 Generate or not a new data set trigger for an external data generating function
%         Parameters.GeneticProgramming.TrainingDataSets = 3; % Number of Training Data Sets
%         Parameters.GeneticProgramming.TestingDataSets  = 3; % Number of Testing Data Sets
%         Parameters.GeneticProgramming.ValidationDataSets = 3; % Number of Validation Data Sets
%         Data.NETrain = 5;% Number of process noise instances to be generated for/within parameter estimation procedure
%         Data.ZeroProcessNoiseFlag = 0;% 0 / 1, 1 = the process noise will be zero; 0 = the process noise will be normal distributed random variable;
%         Data.NoiseAmplitude = 5e-4;
%         clear NDRvalues c
% end
% function [y] =  RandomMimoModel(NumberOfSamples,Input,c)
% NumberMaxDelays=4;
% u=[zeros(2,NumberMaxDelays) Input];
% y=zeros(2,NumberOfSamples+NumberMaxDelays);
% E=5e-4*randn(1,NumberOfSamples+NumberMaxDelays);
%
% for k=NumberMaxDelays+1:1:NumberOfSamples+NumberMaxDelays
% %     y(1,k) = -c(1)*y(1,k-2) + c(2)*y(1,k-2)*y(1,k-1)*u(1,k-3) + c(3)*u(1,k-2)*abs(y(2,k-3)) + c(4)*y(1,k-1)*cos(y(1,k-1)) + c(5)*y(1,k-2)*sin(y(2,k-1))+ -0.2*u(k-2);
% %     y(2,k) = 2*c(6)*y(1,k-4)+ c(7)*y(1,k-1)*y(2,k-1)*u(2,k-1) + c(8)*y(2,k-2)*abs(u(1,k-1)) + c(9)*u(2,k-1)*abs(y(1,k-1)) + c(10)*u(2,k-2)*u(2,k-2)*cos(u(1,k-1));
%     y(1,k) = -c(1)*y(1,k-2)+u(2,k);
%     y(2,k) = +2*c(6)*y(1,k-4);
% end
% y=y(:,NumberMaxDelays+1:end);
% end
%
%
%

% %% Stir Tank MIMO DATA
% % Initialising Data containers
% 
% Parameters.GeneticProgramming.TrainingDataSets = 11;
% Parameters.GeneticProgramming.TestingDataSets = 11;
% Parameters.GeneticProgramming.ValidationDataSets=13;
% Parameters.GeneticProgramming.GenerateNewDataSets = 1; % 0 / 1 Generate or not a new data set trigger for an external data generating function
% Data.uTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.uTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.uValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
% 
% Data.yTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.yTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.yValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
% 
% 
% Data.ETrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.ETest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.EValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
% 
% oldpath = path;
% path(oldpath,".\Data_StirTank\data");
% % Data.NumberOfSamples=16384*2;
% Data.NumberOfSamples=500;
% Data.Ts =60;
% Data.nu = 3; % Number of Input channels
% Data.ny = 2; % Number of Output channels
% Data.nE = 2; % Number of Process noise channels
% 
% Data.NETrain = 1;% Number of process noise instances to be generated for/within parameter estimation procedure
% Data.ZeroProcessNoiseFlag = 1;% 0 / 1, 1 = the process noise will be zero; 0 = the process noise will be normal distributed random variable;
% Data.NoiseAmplitude =0;
% if Parameters.GeneticProgramming.GenerateNewDataSets==1
%     for CounterDataSet=1:Parameters.GeneticProgramming.TrainingDataSets
%         if CounterDataSet<10
%             load(strcat(".\Data_StirTank\data\exp_Est_F0",num2str(CounterDataSet)))
%         else
%             load(strcat(".\Data_StirTank\data\exp_Est_F",num2str(CounterDataSet)))
%         end
%         Data.uTrain{1,CounterDataSet}(1,:)=L_Q1';
%         Data.uTrain{1,CounterDataSet}(2,:)=L_Tc';
%         Data.uTrain{1,CounterDataSet}(3,:)=L_C1';
%         Data.yTrain{1,CounterDataSet}(1,:)=T2_noisy';
%         Data.yTrain{1,CounterDataSet}(2,:)=C2_noisy';
%         
%         clear C1 C2 C2_noisy C2_true C2pv DC1 Finpv L_C1 L_Q1 L_Tc Q1 snrC smrT T T1 T2 T2_noisy T2_true T2pv Tcinpv Td
%     end
%     
%     for CounterDataSet=1:Parameters.GeneticProgramming.TestingDataSets
%         if CounterDataSet<10
%             load(strcat(".\Data_StirTank\data\exp_Test_F0",num2str(CounterDataSet)))
%         else
%             load(strcat(".\Data_StirTank\data\exp_Test_F",num2str(CounterDataSet)))
%         end
%         Data.uTest{1,CounterDataSet}(1,:)=L_Q1';
%         Data.uTest{1,CounterDataSet}(2,:)=L_Tc';
%         Data.uTest{1,CounterDataSet}(3,:)=L_C1';
%         Data.yTest{1,CounterDataSet}(1,:)=T2_noisy';
%         Data.yTest{1,CounterDataSet}(2,:)=C2_noisy';
%         clear C1 C2 C2_noisy C2_true C2pv DC1 Finpv L_C1 L_Q1 L_Tc Q1 snrC smrT T T1 T2 T2_noisy T2_true T2pv Tcinpv TD
%     end
%     
%     for CounterDataSet=1:Parameters.GeneticProgramming.ValidationDataSets-1
%         if CounterDataSet<10
%             load(strcat(".\Data_StirTank\data\exp_Valid_F0",num2str(CounterDataSet)))
%         else
%             load(strcat(".\Data_StirTank\data\exp_Valid_F",num2str(CounterDataSet)))
%         end
%         Data.uValid{1,CounterDataSet}(1,:)=L_Q1';
%         Data.uValid{1,CounterDataSet}(2,:)=L_Tc';
%         Data.uValid{1,CounterDataSet}(3,:)=L_C1';
%         Data.yValid{1,CounterDataSet}(1,:)=T2_noisy';
%         Data.yValid{1,CounterDataSet}(2,:)=C2_noisy';
%         clear C1 C2 C2_noisy C2_true C2pv DC1 Finpv L_C1 L_Q1 L_Tc Q1 snrC smrT T T1 T2 T2_noisy T2_true T2pv Tcinpv TD
%     end
%     
%     load(strcat(".\Data_StirTank\data\exp_Valid_F",num2str(12)))
%         Data.uValid{1,13}(1,:)=L_Q1';
%         Data.uValid{1,13}(2,:)=L_Tc';
%         Data.uValid{1,13}(3,:)=L_C1';
%         Data.yValid{1,13}(1,:)=T2_true';
%         Data.yValid{1,13}(2,:)=C2_true';
%         clear C1 C2 C2_noisy C2_true C2pv DC1 Finpv L_C1 L_Q1 L_Tc Q1 snrC smrT T T1 T2 T2_noisy T2_true T2pv Tcinpv TD
%     
%     
%     
%     StandardiseInputOutput
% end
% clear uval_multisine uval_sinesweep yval_multisine yval_sinesweepa



% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Msc Student within Control Systems reseach group
% at Technical University of Eindhoven.
% In case of using the code, contact the author at: s.nechita@student.tue.nl
% Parts of the implementation are described in the Internship report file
% submited in Feb 2020
% 
% Parameters.GeneticProgramming.TrainingDataSets = 10;
% Parameters.GeneticProgramming.TestingDataSets = 10;
% Parameters.GeneticProgramming.ValidationDataSets=10;
% Parameters.GeneticProgramming.GenerateNewDataSets = 0; % 0 / 1 Generate or not a new data set trigger for an external data generating function
% Data.uTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.uTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.uValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
% 
% Data.yTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.yTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.yValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
% 
% 
% Data.ETrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
% Data.ETest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
% Data.EValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);
% 
% UseOneDataSet=0;
% oldpath = path;
% path(oldpath,".\Data_MirrorThermalModel");
% oldpath = path;
% path(oldpath,".\Data_MirrorThermalModel\GetExpansionCoef");
% 
% % Load input-output data
% load("NormalDistribInputSequence2.mat"); % the input signal data sets are given by ordered sequences of normal distributed random values.
% % %%%%% Use the data generation m files for this %%%%%%%
% % load("PODBasis.mat");
% load(".\Data_MirrorThermalModel\PODBasis_smoothInput_noisy_08_12_2020.mat");
% SelectModel=2; %1 -Expansion coefficients of Fourier basis, or on-spot generated POD basis
% %2 -Expansion coefficients of pre-generated POD basis.
% SelectInputOutputScenario=3; %%%%%% !!!! <<<-- SET THIS 
%             %%%%%% !!!! <<<-- SET THIS 
% %Scenario 1: input = Heat Flux, output = Temperature over X space Fourier Expansion coefficients
% %Scenario 2: input = Temperature over Space Y, output = Deformation over Y space POD Expansion coefficients
% %Scenario 3: input = Heat over Space X, output = Temperature over X space POD Expansion coefficients
% %Scenario 4: input = Heat over Space X, output = Deformation over Y space POD Expansion coefficients
% 
% if Parameters.GeneticProgramming.GenerateNewDataSets==1
%     switch SelectModel
%         case 1
%             SpaceProperties.Lx1=8; % x1 dimension
%             SpaceProperties.Lx2=14;% x2 dimension
%             SpaceProperties.Ly1=80; % x1 dimension
%             SpaceProperties.Ly2=140; % x2 dimension
%             SpaceProperties.points_x1=80; % x1 grid size
%             SpaceProperties.points_x2=140; % x2 grid size
%             SpaceProperties.points_y1=35; %80
%             SpaceProperties.points_y2=50; %80
%             SpaceProperties.nKx=40; % dimension of x1 basis functions set
%             SpaceProperties.nLx=40; % dimension of x2 basis functions set
%             SpaceProperties.nKy=1;
%             SpaceProperties.nLy=2;
%             SpaceProperties.int_q_x1=SpaceProperties.Lx1/(SpaceProperties.points_x1-1);
%             SpaceProperties.int_q_x2=SpaceProperties.Lx2/(SpaceProperties.points_x2-1);
%             SpaceProperties.int_q_y1=SpaceProperties.Ly1/(SpaceProperties.points_y1-1);
%             SpaceProperties.int_q_y2=SpaceProperties.Ly2/(SpaceProperties.points_y2-1);
%             
%             InputSignal.number_of_inputs = 3; % define the number of inputs to be used in the simulation
%             InputSignal.inputLimit_x2=SpaceProperties.Lx2/(InputSignal.number_of_inputs*2-0)*ones(1,InputSignal.number_of_inputs); % grid-wise spread limit of the input bell shape
%             InputSignal.inputLimit_x1=SpaceProperties.int_q_x1*0.99*ones(1,InputSignal.number_of_inputs); % grid-wise spread limit of the input bell shape
%             InputSignal.inputBellVariance=5*ones(1,InputSignal.number_of_inputs); % the variance of the input_i spatial shape
%             InputSignal.inputBellAmplitude=ones(1,InputSignal.number_of_inputs); % the amplitude of the input_i spatial shape
%             InputSignal.InputAmplitude=0.7e+3*ones(1,InputSignal.number_of_inputs); % The actual maximum absolut value of the input signal
%             InputSignal.u_x1=zeros(1,InputSignal.number_of_inputs);% position over x1 of [input_i]  phisycal-wise
%             InputSignal.u_x2=[SpaceProperties.Lx2/6 SpaceProperties.Lx2/2 SpaceProperties.Lx2-SpaceProperties.Lx2/6]; % position over x2 of [input_i ] phisycal-wise
%             SelectPOD=1;
%             SelectInputOutputScenario=2;
%             %Scenario 1: input = Heat Flux, output = Temperature over X space Fourier Expansion coefficients
%             %Scenario 2: input = Temperature over Space Y, output = Deformation over Y space POD Expansion coefficients
%             %Scenario 3: input = Heat over Space X, output = Temperature over X space POD Expansion coefficients
%             %Scenario 4: input = Heat over Space X, output = Deformation over Y space POD Expansion coefficients
%             
%             
%             nu=SpaceProperties.nKx*SpaceProperties.nLx; %number of inputs for TAG
%             randomSampleSize =15;
%             Ts=700;
%             t=700*2000; %10 minutes
%             
%         case 2
%             
%             SpaceProperties.Lx1=8; % x1 dimension
%             SpaceProperties.Lx2=14;% x2 dimension
%             SpaceProperties.Ly1=80; % x1 dimension
%             SpaceProperties.Ly2=140; % x2 dimension
%             SpaceProperties.points_x1=80; % x1 grid size
%             SpaceProperties.points_x2=140; % x2 grid size
%             SpaceProperties.points_y1=60; %80
%             SpaceProperties.points_y2=105; %80
%             SpaceProperties.nKx=40; % dimension of x1 basis functions set
%             SpaceProperties.nLx=40; % dimension of x2 basis functions set
%             SpaceProperties.nKy=1;
%             SpaceProperties.nLy=2;
%             SpaceProperties.int_q_x1=SpaceProperties.Lx1/(SpaceProperties.points_x1-1);
%             SpaceProperties.int_q_x2=SpaceProperties.Lx2/(SpaceProperties.points_x2-1);
%             SpaceProperties.int_q_y1=SpaceProperties.Ly1/(SpaceProperties.points_y1-1);
%             SpaceProperties.int_q_y2=SpaceProperties.Ly2/(SpaceProperties.points_y2-1);
%             
%             InputSignal.number_of_inputs = 3; % define the number of inputs to be used in the simulation
%             InputSignal.inputLimit_x2=SpaceProperties.Lx2/(InputSignal.number_of_inputs*2-0)*ones(1,InputSignal.number_of_inputs); % grid-wise spread limit of the input bell shape
%             InputSignal.inputLimit_x1=SpaceProperties.int_q_x1*0.99*ones(1,InputSignal.number_of_inputs); % grid-wise spread limit of the input bell shape
%             InputSignal.inputBellVariance=0.65*ones(1,InputSignal.number_of_inputs); % the variance of the input_i spatial shape
%             InputSignal.inputBellAmplitude=ones(1,InputSignal.number_of_inputs); % the amplitude of the input_i spatial shape
%             InputSignal.InputAmplitude=0.5e+3*ones(1,InputSignal.number_of_inputs); % The actual maximum absolut value of the input signal
%             InputSignal.u_x1=zeros(1,InputSignal.number_of_inputs);% position over x1 of [input_i]  phisycal-wise
%             InputSignal.u_x2=[SpaceProperties.Lx2/6 SpaceProperties.Lx2/2 SpaceProperties.Lx2-SpaceProperties.Lx2/6]; % position over x2 of [input_i ] phisycal-wise
%             SelectPOD=1;
%             InputSignal.RandomSeed=(1500001:1600001);
%             %Scenario 1: input = Heat Flux, output = Temperature over X space Fourier Expansion coefficients
%             %Scenario 2: input = Temperature over Space Y, output = Deformation over Y space POD Expansion coefficients
%             %Scenario 3: input = Heat over Space X, output = Temperature over X space POD Expansion coefficients
%             %Scenario 4: input = Heat over Space X, output = Deformation over Y space POD Expansion coefficients
%             
%             
%             
%             nu=SpaceProperties.nKx*SpaceProperties.nLx; %number of inputs for TAG
%             randomSampleSize =15;
%             Ts=500;
%             t=Ts*500; %10 minutes
%             
%     end
%     
%     noSamples=t/Ts+1; % number of samples of data to be used
%     N=noSamples;
%     time=0:Ts:t;
%     
%     
%     
%     
%     %Scenario 1: input = Heat Flux, output = Temperature over X space Fourier Expansion coefficients
%     %Scenario 2: input = Temperature over Space Y, output = Deformation over Y space POD Expansion coefficients
%     %Scenario 3: input = Heat over Space X, output = Temperature over X space POD Expansion coefficients
%     %Scenario 4: input = Heat over Space X, output = Deformation over Y space POD Expansion coefficients
%     
%     
%     
%     %
%     switch UseOneDataSet
%         case 0
%             %       Generating Training Data Sets
%             total_counter_dataset=0;
%             InputSignalCounter = 1; % Reset this if you want to use the same set for Training/TEsting and Validation
%             for counter_datasets=1:Parameters.GeneticProgramming.TrainingDataSets
%                 total_counter_dataset=total_counter_dataset+1;
%                 counter_datasets
%                 inputSequence=[];
%                 switch SelectModel
%                     case 1
%                         randomSampleSize=randomSampleSize; % for randomSampleSize samples, the input will be the same
%                         for counter=1: InputSignal.number_of_inputs
%                             if (round(length(time)/randomSampleSize)*InputSignalCounter > length(NormalDistribInputSequence))
%                                 InputSignalCounter=1;
%                             end
%                             inputSequenceRandom(counter,:)=NormalDistribInputSequence(round(length(time)/randomSampleSize)*(InputSignalCounter-1)+1:round(length(time)/randomSampleSize)*InputSignalCounter);
%                             InputSignalCounter=InputSignalCounter+1;
%                             inputSequence(counter,:) = zeros(1,noSamples);
%                             for counter_i=1:length(inputSequenceRandom(counter,:))-1
%                                 inputSequence(counter,randomSampleSize*(counter_i-1)+1:randomSampleSize*(counter_i)) = inputSequenceRandom(counter,counter_i);
%                             end
%                         end
%                         inputSequence = [inputSequence zeros(InputSignal.number_of_inputs,1)]; % adding a last term so it will match the simulation time
%                     case 2
%                         randomSampleSize=randomSampleSize; % for randomSampleSize samples, the input will be the same
%                         for counter=1: InputSignal.number_of_inputs
%                             if (round(length(time)/randomSampleSize)*InputSignalCounter > length(NormalDistribInputSequence))
%                                 InputSignalCounter=1;
%                             end
%                             inputSequenceRandom(counter,:)=NormalDistribInputSequence(round(length(time)/randomSampleSize)*(InputSignalCounter-1)+1:round(length(time)/randomSampleSize)*InputSignalCounter);
%                             InputSignalCounter=InputSignalCounter+1;
%                             inputSequence(counter,:) = zeros(1,noSamples);
%                             for counter_i=1:length(inputSequenceRandom(counter,:))-1
%                                 inputSequence(counter,randomSampleSize*(counter_i-1)+1:randomSampleSize*(counter_i)) = inputSequenceRandom(counter,counter_i);
%                             end
%                         end
%                         inputSequence = [inputSequence zeros(InputSignal.number_of_inputs,1)]; % adding a last term so it will match the simulation time
%                 end
%                 % Add an +1 and -1 input sequence at the beggining of the simulation
%                 
%                 inputSequence = [ones(InputSignal.number_of_inputs,randomSampleSize), -1*ones(InputSignal.number_of_inputs,randomSampleSize),inputSequence];
%                 inputSequence = inputSequence(:,1:length(time));
%                 InputSignal.inputSequence =  inputSequence; % the input signal for all locations.
%                 InputSignal.RandomSeedSelection=InputSignal.RandomSeed((total_counter_dataset-1)*length(time)+1:total_counter_dataset*length(time))
%                 %             Get the output signal
%                 switch SelectModel
%                     case 1
%                         [OutputStruct]=dataGeneratingSystem_Scheme2(InputSignal,SpaceProperties,time);
%                     case 2
%                         [OutputStruct]=GetExpansionCoef(InputSignal,SpaceProperties,time,PODBasis);
%                 end
%                 %     Each time matrix -> collumn array
%                 switch SelectInputOutputScenario
%                     case 1
%                         for counter_t=1:length(time)
%                             A_kl_array=[];
%                             Q_kl_array=[];
%                             for counter=1:SpaceProperties.nKx
%                                 A_kl_array=[A_kl_array; OutputStruct.A_kl{1,counter_t}(counter,:)'];
%                                 Q_kl_array=[Q_kl_array; OutputStruct.Q_kl{1,counter_t}(counter,:)'];
%                             end
%                             Data.uTrain{1,counter_datasets}(:,counter_t)=Q_kl_array;
%                             Data.yTrain{1,counter_datasets}(:,counter_t)=A_kl_array;
% %                             ETrain{1,counter_datasets}(:,counter_t)=zeros(1,1);
%                         end
%                     case 2
%                         if SelectPOD==1
%                             Data.uTrain{1,counter_datasets}=[];
%                             Data.yTrain{1,counter_datasets}=[];
%                             for counter_t=1:length(time)
%                                 Data.uTrain{1,counter_datasets}(:,counter_t)=OutputStruct.Tk{:,counter_t};
%                                 Data.yTrain{1,counter_datasets}(:,counter_t)=OutputStruct.Bk{:,counter_t};
% %                                 ETrain{1,counter_datasets}(:,counter_t)=zeros(1,1);
%                             end
%                         end
%                     case 3
%                         if SelectPOD==1
%                             Data.uTrain{1,counter_datasets}=[];
%                             Data.yTrain{1,counter_datasets}=[];
%                             for counter_t=1:length(time)
%                                 Data.uTrain{1,counter_datasets}(:,counter_t)=OutputStruct.Qk{:,counter_t};
%                                 Data.yTrain{1,counter_datasets}(:,counter_t)=OutputStruct.Ak{:,counter_t};
% %                                 ETrain{1,counter_datasets}(:,counter_t)=zeros(1,1);
%                             end
%                         end
%                     case 4
%                         if SelectPOD==1
%                             Data.uTrain{1,counter_datasets}=[];
%                             Data.yTrain{1,counter_datasets}=[];
%                             for counter_t=1:length(time)
%                                 Data.uTrain{1,counter_datasets}(:,counter_t)=OutputStruct.Qk{:,counter_t}; %Heat
%                                 Data.yTrain{1,counter_datasets}(:,counter_t)=OutputStruct.Bk{:,counter_t}; %Deform
% %                                 ETrain{1,counter_datasets}(:,counter_t)=zeros(1,1);
%                             end
%                         end
%                         
%                 end
%                 
%             end
%             
%             
%             for counter_datasets=1:Parameters.GeneticProgramming.TestingDataSets
%                 total_counter_dataset=total_counter_dataset+1;
%                 counter_datasets
%                 inputSequence=[];
%                 switch SelectModel
%                     case 1
%                         randomSampleSize=randomSampleSize; % for randomSampleSize samples, the input will be the same
%                         for counter=1: InputSignal.number_of_inputs
%                             if (round(length(time)/randomSampleSize)*InputSignalCounter > length(NormalDistribInputSequence))
%                                 InputSignalCounter=1;
%                             end
%                             inputSequenceRandom(counter,:)=NormalDistribInputSequence(round(length(time)/randomSampleSize)*(InputSignalCounter-1)+1:round(length(time)/randomSampleSize)*InputSignalCounter);
%                             InputSignalCounter=InputSignalCounter+1;
%                             inputSequence(counter,:) = zeros(1,noSamples);
%                             for counter_i=1:length(inputSequenceRandom(counter,:))-1
%                                 inputSequence(counter,randomSampleSize*(counter_i-1)+1:randomSampleSize*(counter_i)) = inputSequenceRandom(counter,counter_i);
%                             end
%                         end
%                         inputSequence = [inputSequence zeros(InputSignal.number_of_inputs,1)]; % adding a last term so it will match the simulation time
%                     case 2
%                         randomSampleSize=randomSampleSize; % for randomSampleSize samples, the input will be the same
%                         for counter=1: InputSignal.number_of_inputs
%                             if (round(length(time)/randomSampleSize)*InputSignalCounter > length(NormalDistribInputSequence))
%                                 InputSignalCounter=1;
%                             end
%                             inputSequenceRandom(counter,:)=NormalDistribInputSequence(round(length(time)/randomSampleSize)*(InputSignalCounter-1)+1:round(length(time)/randomSampleSize)*InputSignalCounter);
%                             InputSignalCounter=InputSignalCounter+1;
%                             inputSequence(counter,:) = zeros(1,noSamples);
%                             for counter_i=1:length(inputSequenceRandom(counter,:))-1
%                                 inputSequence(counter,randomSampleSize*(counter_i-1)+1:randomSampleSize*(counter_i)) = inputSequenceRandom(counter,counter_i);
%                             end
%                         end
%                         inputSequence = [inputSequence zeros(InputSignal.number_of_inputs,1)]; % adding a last term so it will match the simulation time
%                         
%                 end
%                 % Add an +1 and -1 input sequence at the beggining of the simulation
%                 
%                 inputSequence = [ones(InputSignal.number_of_inputs,randomSampleSize), -1*ones(InputSignal.number_of_inputs,randomSampleSize),inputSequence];
%                 inputSequence = inputSequence(:,1:length(time));
%                 InputSignal.inputSequence =  inputSequence; % the input signal for all locations.
%                InputSignal.RandomSeedSelection=InputSignal.RandomSeed((total_counter_dataset-1)*length(time)+1:total_counter_dataset*length(time))
%                 %             Get the output signal
%                 switch SelectModel
%                     case 1
%                         [OutputStruct]=dataGeneratingSystem_Scheme2(InputSignal,SpaceProperties,time);
%                     case 2
%                         [OutputStruct]=GetExpansionCoef(InputSignal,SpaceProperties,time,PODBasis);
%                 end
%                 %     Each time matrix -> collumn array
%                 switch SelectInputOutputScenario
%                     case 1
%                         for counter_t=1:length(time)
%                             A_kl_array=[];
%                             Q_kl_array=[];
%                             for counter=1:SpaceProperties.nKx
%                                 A_kl_array=[A_kl_array; OutputStruct.A_kl{1,counter_t}(counter,:)'];
%                                 Q_kl_array=[Q_kl_array; OutputStruct.Q_kl{1,counter_t}(counter,:)'];
%                             end
%                             Data.uTest{1,counter_datasets}(:,counter_t)=Q_kl_array;
%                             Data.yTest{1,counter_datasets}(:,counter_t)=A_kl_array;
% %                             ETest{1,counter_datasets}(:,counter_t)=zeros(1,1);
%                         end
%                     case 2
%                         if SelectPOD==1
%                             for counter_t=1:length(time)
%                                 Data.uTest{1,counter_datasets}(:,counter_t)=OutputStruct.Tk{:,counter_t};
%                                 Data.yTest{1,counter_datasets}(:,counter_t)=OutputStruct.Bk{:,counter_t};
% %                                 ETest{1,counter_datasets}(:,counter_t)=zeros(1,1);
%                             end
%                         end
%                     case 3
%                         if SelectPOD==1
%                             Data.uTest{1,counter_datasets}=[];
%                             Data.yTest{1,counter_datasets}=[];
%                             for counter_t=1:length(time)
%                                 Data.uTest{1,counter_datasets}(:,counter_t)=OutputStruct.Qk{:,counter_t};
%                                 Data.yTest{1,counter_datasets}(:,counter_t)=OutputStruct.Ak{:,counter_t};
% %                                 ETest{1,counter_datasets}(:,counter_t)=zeros(1,1);
%                             end
%                         end
%                     case 4
%                         if SelectPOD==1
%                             for counter_t=1:length(time)
%                                 Data.uTest{1,counter_datasets}(:,counter_t)=OutputStruct.Qk{:,counter_t}; %Heat
%                                 Data.yTest{1,counter_datasets}(:,counter_t)=OutputStruct.Bk{:,counter_t}; %Deform
% %                                 ETest{1,counter_datasets}(:,counter_t)=zeros(1,1);
%                             end
%                         end
%                         
%                 end
%                 
%             end
%             
%             
%             for counter_datasets=1:Parameters.GeneticProgramming.ValidationDataSets
%                 total_counter_dataset=total_counter_dataset+1;
%                 counter_datasets
%                 inputSequence=[];
%                 switch SelectModel
%                     case 1
%                         randomSampleSize=randomSampleSize; % for randomSampleSize samples, the input will be the same
%                         for counter=1: InputSignal.number_of_inputs
%                             if (round(length(time)/randomSampleSize)*InputSignalCounter > length(NormalDistribInputSequence))
%                                 InputSignalCounter=1;
%                             end
%                             inputSequenceRandom(counter,:)=NormalDistribInputSequence(round(length(time)/randomSampleSize)*(InputSignalCounter-1)+1:round(length(time)/randomSampleSize)*InputSignalCounter);
%                             InputSignalCounter=InputSignalCounter+1;
%                             inputSequence(counter,:) = zeros(1,noSamples);
%                             for counter_i=1:length(inputSequenceRandom(counter,:))-1
%                                 inputSequence(counter,randomSampleSize*(counter_i-1)+1:randomSampleSize*(counter_i)) = inputSequenceRandom(counter,counter_i);
%                             end
%                         end
%                         inputSequence = [inputSequence zeros(InputSignal.number_of_inputs,1)]; % adding a last term so it will match the simulation time
%                     case 2
%                         randomSampleSize=randomSampleSize; % for randomSampleSize samples, the input will be the same
%                         for counter=1: InputSignal.number_of_inputs
%                             if (round(length(time)/randomSampleSize)*InputSignalCounter > length(NormalDistribInputSequence))
%                                 InputSignalCounter=1;
%                             end
%                             inputSequenceRandom(counter,:)=NormalDistribInputSequence(round(length(time)/randomSampleSize)*(InputSignalCounter-1)+1:round(length(time)/randomSampleSize)*InputSignalCounter);
%                             InputSignalCounter=InputSignalCounter+1;
%                             inputSequence(counter,:) = zeros(1,noSamples);
%                             for counter_i=1:length(inputSequenceRandom(counter,:))-1
%                                 inputSequence(counter,randomSampleSize*(counter_i-1)+1:randomSampleSize*(counter_i)) = inputSequenceRandom(counter,counter_i);
%                             end
%                         end
%                         inputSequence = [inputSequence zeros(InputSignal.number_of_inputs,1)]; % adding a last term so it will match the simulation time
%                         
%                 end
%                 % Add an +1 and -1 input sequence at the beggining of the simulation
%                 
%                 inputSequence = [ones(InputSignal.number_of_inputs,randomSampleSize), -1*ones(InputSignal.number_of_inputs,randomSampleSize),inputSequence];
%                 inputSequence = inputSequence(:,1:length(time));
%                 InputSignal.inputSequence =  inputSequence; % the input signal for all locations.
%                InputSignal.RandomSeedSelection=InputSignal.RandomSeed((total_counter_dataset-1)*length(time)+1:total_counter_dataset*length(time))
%                 %             Get the output signal
%                 switch SelectModel
%                     case 1
%                         [OutputStruct]=dataGeneratingSystem_Scheme2(InputSignal,SpaceProperties,time);
%                     case 2
%                         [OutputStruct]=GetExpansionCoef(InputSignal,SpaceProperties,time,PODBasis);
%                 end
%                 %     Each time matrix -> collumn array
%                 switch SelectInputOutputScenario
%                     case 1
%                         for counter_t=1:length(time)
%                             A_kl_array=[];
%                             Q_kl_array=[];
%                             for counter=1:SpaceProperties.nKx
%                                 A_kl_array=[A_kl_array; OutputStruct.A_kl{1,counter_t}(counter,:)'];
%                                 Q_kl_array=[Q_kl_array; OutputStruct.Q_kl{1,counter_t}(counter,:)'];
%                             end
%                             Data.uValid{1,counter_datasets}(:,counter_t)=Q_kl_array;
%                             Data.yValid{1,counter_datasets}(:,counter_t)=A_kl_array;
% %                             EValid{1,counter_datasets}(:,counter_t)=zeros(1,1);
%                         end
%                     case 2
%                         if SelectPOD==1
%                             for counter_t=1:length(time)
%                                 Data.uValid{1,counter_datasets}(:,counter_t)=OutputStruct.Tk{:,counter_t};
%                                 Data.yValid{1,counter_datasets}(:,counter_t)=OutputStruct.Bk{:,counter_t};
% %                                 EValid{1,counter_datasets}(:,counter_t)=zeros(1,1);
%                             end
%                         end
%                     case 3
%                         if SelectPOD==1
%                             Data.uValid{1,counter_datasets}=[];
%                             Data.yValid{1,counter_datasets}=[];
%                             for counter_t=1:length(time)
%                                 Data.uValid{1,counter_datasets}(:,counter_t)=OutputStruct.Qk{:,counter_t};
%                                 Data.yValid{1,counter_datasets}(:,counter_t)=OutputStruct.Ak{:,counter_t};
% %                                 EValid{1,counter_datasets}(:,counter_t)=zeros(1,1);
%                             end
%                         end
%                     case 4
%                         if SelectPOD==1
%                             for counter_t=1:length(time)
%                                 Data.uValid{1,counter_datasets}(:,counter_t)=OutputStruct.Qk{:,counter_t}; %Heat
%                                 Data.yValid{1,counter_datasets}(:,counter_t)=OutputStruct.Bk{:,counter_t}; %Deform
% %                                 EValid{1,counter_datasets}(:,counter_t)=zeros(1,1);
%                             end
%                         end
%                         
%                 end
%                 
%             end
%         case 1
%             %         Generating Training Data Sets
%             InputSignalCounter = 1; % Reset this if you want to use the same set for Training/TEsting and Validation
%             for counter_datasets=1:Parameters.GeneticProgramming.TrainingDataSets
%                 inputSequence=[];
%                 switch SelectModel
%                     case 1
%                         randomSampleSize=randomSampleSize; % for randomSampleSize samples, the input will be the same
%                         for counter=1: InputSignal.number_of_inputs
%                             if (round(length(time)/randomSampleSize)*InputSignalCounter > length(NormalDistribInputSequence))
%                                 InputSignalCounter=1;
%                             end
%                             inputSequenceRandom(counter,:)=NormalDistribInputSequence(round(length(time)/randomSampleSize)*(InputSignalCounter-1)+1:round(length(time)/randomSampleSize)*InputSignalCounter);
%                             InputSignalCounter=InputSignalCounter+1;
%                             inputSequence(counter,:) = zeros(1,noSamples);
%                             for counter_i=1:length(inputSequenceRandom(counter,:))-1
%                                 inputSequence(counter,randomSampleSize*(counter_i-1)+1:randomSampleSize*(counter_i)) = inputSequenceRandom(counter,counter_i);
%                             end
%                         end
%                         inputSequence = [inputSequence zeros(InputSignal.number_of_inputs,1)]; % adding a last term so it will match the simulation time
%                     case 2
%                         randomSampleSize=randomSampleSize; % for randomSampleSize samples, the input will be the same
%                         for counter=1: InputSignal.number_of_inputs
%                             if (round(length(time)/randomSampleSize)*InputSignalCounter > length(NormalDistribInputSequence))
%                                 InputSignalCounter=1;
%                             end
%                             inputSequenceRandom(counter,:)=NormalDistribInputSequence(round(length(time)/randomSampleSize)*(InputSignalCounter-1)+1:round(length(time)/randomSampleSize)*InputSignalCounter);
%                             InputSignalCounter=InputSignalCounter+1;
%                             inputSequence(counter,:) = zeros(1,noSamples);
%                             for counter_i=1:length(inputSequenceRandom(counter,:))-1
%                                 inputSequence(counter,randomSampleSize*(counter_i-1)+1:randomSampleSize*(counter_i)) = inputSequenceRandom(counter,counter_i);
%                             end
%                         end
%                         inputSequence = [inputSequence zeros(InputSignal.number_of_inputs,1)]; % adding a last term so it will match the simulation time
%                         
%                 end
%                 % Add an +1 and -1 input sequence at the beggining of the simulation
%                 
%                 inputSequence = [ones(InputSignal.number_of_inputs,randomSampleSize), -1*ones(InputSignal.number_of_inputs,randomSampleSize),inputSequence];
%                 inputSequence = inputSequence(:,1:length(time));
%                 InputSignal.inputSequence =  inputSequence; % the input signal for all locations.
%                 %                 Get the output signal
%                 switch SelectModel
%                     case 1
%                         [OutputStruct]=dataGeneratingSystem_Scheme2(InputSignal,SpaceProperties,time);
%                     case 2
%                         [OutputStruct]=GetExpansionCoef(InputSignal,SpaceProperties,time,PODBasis);
%                 end
%                 %     Each time matrix -> collumn array
%                 switch SelectInputOutputScenario
%                     case 1
%                         for counter_t=1:length(time)
%                             A_kl_array=[];
%                             Q_kl_array=[];
%                             for counter=1:SpaceProperties.nKx
%                                 A_kl_array=[A_kl_array; OutputStruct.A_kl{1,counter_t}(counter,:)'];
%                                 Q_kl_array=[Q_kl_array; OutputStruct.Q_kl{1,counter_t}(counter,:)'];
%                             end
%                             Data.uTrain{1,counter_datasets}(:,counter_t)=Q_kl_array;
%                             Data.yTrain{1,counter_datasets}(:,counter_t)=A_kl_array;
%                             ETrain{1,counter_datasets}(:,counter_t)=zeros(1,1);
%                         end
%                     case 2
%                         if SelectPOD==1
%                             for counter_t=1:length(time)
%                                 Data.uTrain{1,counter_datasets}(:,counter_t)=OutputStruct.Tk{:,counter_t}; %Temp
%                                 Data.yTrain{1,counter_datasets}(:,counter_t)=OutputStruct.Bk{:,counter_t}; %Deform
%                                 ETrain{1,counter_datasets}(:,counter_t)=zeros(1,1);
%                             end
%                         end
%                     case 3
%                         if SelectPOD==1
%                             for counter_t=1:length(time)
%                                 Data.uTrain{1,counter_datasets}(:,counter_t)=OutputStruct.Qk{:,counter_t}; %Heat
%                                 Data.yTrain{1,counter_datasets}(:,counter_t)=OutputStruct.Ak(:,counter_t); %Temp
%                                 ETrain{1,counter_datasets}(:,counter_t)=zeros(1,1);
%                             end
%                         end
%                     case 4
%                         if SelectPOD==1
%                             for counter_t=1:length(time)
%                                 Data.uTrain{1,counter_datasets}(:,counter_t)=OutputStruct.Qk{:,counter_t}; %Heat
%                                 Data.yTrain{1,counter_datasets}(:,counter_t)=OutputStruct.Bk{:,counter_t}; %Deform
%                                 ETrain{1,counter_datasets}(:,counter_t)=zeros(1,1);
%                             end
%                         end
%                         
%                 end
%                 
%             end
%             Data.uTest=Data.uTrain;
%             Data.yTest=Data.yTrain;
%             ETest=ETrain;
%             Data.uValid=Data.uTrain;
%             Data.yValid=Data.yTrain;
%             EValid=ETrain;
%             
%             
%             
%     end
%     [Data.nu ,~]=size(Data.uTrain{1,1})
%     [Data.ny ,~]=size(Data.yTrain{1,1})
%     Data.nE=1;
%     Data.NumberOfSamples=500;
%     Data.Ts =500;
%     Data.NETrain = 0;% Number of process noise instances to be generated for/within parameter estimation procedure
%     Data.ZeroProcessNoiseFlag = 1;% 0 / 1, 1 = the process noise will be zero; 0 = the process noise will be normal distributed random variable;
%     Data.NoiseAmplitude =6.3247e-04; % 0.3 /std dev output
%     StandardiseInputOutput
%     switch SelectInputOutputScenario
%         case 2
%             save("Input_Output_data_Temp-Deform.mat","uTest","uTrain","uValid","yTest","yTrain","yValid","ETest","ETrain","EValid","SaveuTest","SaveyTest","SaveETest","SaveuTrain","SaveyTrain","SaveETrain","SaveuValid","SaveyValid","SaveEValid","stdDeviationOutput","stdDeviationInput","meanInput","meanOutput")
%         case 3
%             save("Input_Output_data_Heat-Temp_noisy_08_12_2020_5.mat","Data")
%         case 4
%             save("Input_Output_data_Heat-Deform.mat","uTest","uTrain","uValid","yTest","yTrain","yValid","ETest","ETrain","EValid","SaveuTest","SaveyTest","SaveETest","SaveuTrain","SaveyTrain","SaveETrain","SaveuValid","SaveyValid","SaveEValid","stdDeviationOutput","stdDeviationInput","meanInput","meanOutput")
%     end
%     
%     
% else
%     switch SelectInputOutputScenario
%         case 2
%             load('Input_Output_data_Temp-Deform.mat')
%         case 3
%             load('.\Data_MirrorThermalModel\Input_Output_data_Heat-Temp_noisy_08_12_2020_5.mat')
%         case 4
%             load('Input_Output_data_Heat-Deform.mat')
%     end
%     if exist('NormalDistribInputSequence')
%         clear('NormalDistribInputSequence')
%     end
% %     Ts=500;
% %     t=Ts*500; %10 minutes
% end
% clear ans counter counter_datasets counter_i counter_t inputSequence inputSequenceRandom inputSignal InputSignalCounter N NormalDistribInputSequence noSamples
% clear nu OutputStruct PODBasis randomSampleSize SelectInputOutputScenario SelectModel SelectPOD SpaceProperties t
% clear Ts UseOneDataSet total_counter_dataset time
% clear InputSignal
%% For case 2 only, select for which output the identification is done.

%Scenario 1: input = Heat Flux, output = Temperature over X space Fourier Expansion coefficients
%Scenario 2: input = Temperature over Space Y, output = Deformation over Y space POD Expansion coefficients
%Scenario 3: input = Heat over Space X, output = Temperature over X space POD Expansion coefficients
%Scenario 4: input = Heat over Space X, output = Deformation over Y space POD Expansion coefficients

% switch SelectInputOutputScenario
%     case 2
%         %         Combine all the training data sets in a big one to apply LS param
%         %         est to a bigger data sets.
%         for counter_datasets=2:Parameters.GeneticProgramming.TrainingDataSets
%             uTrain{1,1} = [uTrain{1,1}, uTrain{1,counter_datasets}];
%         end
%         yTrain{1,1} = [yTrain{1,1}(SelectOutput,:)];
%         for counter_datasets=2:Parameters.GeneticProgramming.TrainingDataSets
%             yTrain{1,1} = [yTrain{1,1}, yTrain{1,counter_datasets}(SelectOutput,:)];
%         end
%         
%         for counter_datasets=2:Parameters.GeneticProgramming.TrainingDataSets
%             ETrain{1,1} = [ETrain{1,1}, ETrain{1,counter_datasets}];
%         end
%         
%         
%         
%         %         for counter_datasets=1:Parameters.GeneticProgramming.TrainingDataSets
%         %             yTrain{1,counter_datasets} = yTrain{1,counter_datasets}(SelectOutput,:);
%         %         end
%         
%         for counter_datasets=1:Parameters.GeneticProgramming.TestingDataSets
%             yTest{1,counter_datasets} = yTest{1,counter_datasets}(SelectOutput,:);
%         end
%         
%         for counter_datasets=1:Parameters.GeneticProgramming.ValidationDataSets
%             yValid{1,counter_datasets} = yValid{1,counter_datasets}(SelectOutput,:);
%         end
%         
%         case 3
% %                     %         Combine all the training data sets in a big one to apply LS param
% %         %         est to a bigger data sets.
% %         for counter_datasets=2:Parameters.GeneticProgramming.TrainingDataSets
% %             uTrain{1,1} = [uTrain{1,1}, uTrain{1,counter_datasets}];
% %         end
% %         yTrain{1,1} = [yTrain{1,1}];
% %         for counter_datasets=2:Parameters.GeneticProgramming.TrainingDataSets
% %             yTrain{1,1} = [yTrain{1,1}, yTrain{1,counter_datasets}];
% %         end
% %         
% %         for counter_datasets=2:Parameters.GeneticProgramming.TrainingDataSets
% %             ETrain{1,1} = [ETrain{1,1}, ETrain{1,counter_datasets}];
% %         end
% end
% 
% 

