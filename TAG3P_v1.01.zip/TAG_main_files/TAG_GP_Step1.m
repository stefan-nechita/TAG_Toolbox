% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.


% ->Step1 Generate Offsprings by Crossover and Mutation Q(t)
% This file is within the while loop
Offspring_generator=tic;
clear R_Generation
R_Generation=rmfield(Generation{1, CounterNumberGeneration},"front"); % R(t)=union(P(t), Q(t))

% Generation the Q(t) by crossover and mutation inside R Crossover

cardPOP=length(Generation{CounterNumberGeneration});
selectParent1=mod(1:2*Parameters.GeneticProgramming.MAX_POP,ceil(Parameters.GeneticProgramming.mu*Parameters.GeneticProgramming.MAX_POP)); % iteratively select parent1 to be within the first mu%
selectParent1(find(selectParent1==0))=1;
selectParent2=zeros(1,2*Parameters.GeneticProgramming.MAX_POP);

% Iterative offsporing creation
% while cardPOP < 2*Parameters.GeneticProgramming.MAX_POP % untill de cardinality of the population is reached
% selectionOK=0;
%     while selectionOK==0 % untill two parents are selected corectly
%         selectParent2(cardPOP)=randi([1,floor(mu*Parameters.GeneticProgramming.MAX_POP)],1,1);% parent2 is randomly chosen
%         if length(Generation{CounterNumberGeneration}(selectParent1(cardPOP)).DerivationTree.ElementaryArrayTypes) == 1
%             selectParent1(cardPOP) = randi([1,floor(Parameters.GeneticProgramming.MAX_POP)],1,1);
%         end
%         lenParent1=length(Generation{CounterNumberGeneration}(selectParent1(cardPOP)).DerivationTree.ElementaryArrayTypes);
%         lenParent2=length(Generation{CounterNumberGeneration}(selectParent2(cardPOP)).DerivationTree.ElementaryArrayTypes);
%         
%         if ((lenParent1==1) || (lenParent2==1)) % check for the complexity of each parent
%             disp("One has only its Head") % (cannot perform crossover with a starting initial tree)
%         end
%         if ((selectParent1(cardPOP) ~= selectParent2(cardPOP)) && (lenParent1>1) && (lenParent2>1))
%             selectionOK=1;
%         end
%     end
%     
%     
%     [Error,Offsprings,~] = TAGCrossover(Generation{CounterNumberGeneration}(selectParent1(cardPOP)).tree,Generation{CounterNumberGeneration}(selectParent2(cardPOP)).tree,ny,nu,nE,InitTreeTypes);
%     if cardPOP < 2*Parameters.GeneticProgramming.MAX_POP
%         cardPOP=cardPOP+1;
%         R_Generation(cardPOP).tree=Offsprings(1).tree;
%         R_Generation(cardPOP).time=Offsprings(1).time;
%     end
%     
%     if cardPOP < 2*Parameters.GeneticProgramming.MAX_POP
%         cardPOP=cardPOP+1;
%         R_Generation(cardPOP).tree=Offsprings(2).tree;
%         R_Generation(cardPOP).time=Offsprings(2).time;
%         
%     end
%     
% end
   
% Paralel Offspring Creation
selectParent1=1:Parameters.GeneticProgramming.MAX_POP/2;
selectParent2=zeros(1,Parameters.GeneticProgramming.MAX_POP/2);
for cardPOP=1:Parameters.GeneticProgramming.MAX_POP/2
    selectionOK=0;
    while selectionOK==0 % untill two parents are selected corectly
        selectParent2(cardPOP)=randi([1,floor(Parameters.GeneticProgramming.mu*Parameters.GeneticProgramming.MAX_POP)],1,1);% parent2 is randomly chosen
        if length(Generation{CounterNumberGeneration}(selectParent1(cardPOP)).DerivationTree.ElementaryArrayTypes) == 1
            selectParent1(cardPOP) = randi([1,floor(Parameters.GeneticProgramming.MAX_POP)],1,1);
        end
        lenParent1=length(Generation{CounterNumberGeneration}(selectParent1(cardPOP)).DerivationTree.ElementaryArrayTypes);
        lenParent2=length(Generation{CounterNumberGeneration}(selectParent2(cardPOP)).DerivationTree.ElementaryArrayTypes);
        
        if ((lenParent1==1) || (lenParent2==1)) % check for the complexity of each parent
            disp("One has only its Head") % (cannot perform crossover with a starting initial tree)
        end
        if ((selectParent1(cardPOP) ~= selectParent2(cardPOP)) && (lenParent1>1) && (lenParent2>1))
            selectionOK=1;
        end
    end
end

Offsprings=cell(1,Parameters.GeneticProgramming.MAX_POP/2);
parfor counter_Offspring=1:Parameters.GeneticProgramming.MAX_POP/2 % untill de cardinality of the population is reached
% for counter_Offspring=1:Parameters.GeneticProgramming.MAX_POP/2
selectionOK=0;
runtimework(counter_Offspring)=tic();
[Error,Offsprings{counter_Offspring},~] = TAGCrossover(Generation{CounterNumberGeneration}(selectParent1(counter_Offspring)).tree,Generation{CounterNumberGeneration}(selectParent2(counter_Offspring)).tree,InitTreeTypes,Parameters.EquationSolution);
OffspringRuntime(counter_Offspring)=toc(runtimework(counter_Offspring));
disp(strcat("Offspring pack no ", num2str(counter_Offspring)," created in ",num2str(OffspringRuntime(counter_Offspring))," seconds"));
end

cardPOP=Parameters.GeneticProgramming.MAX_POP;
counter_Offspring=1;
while cardPOP < 2*Parameters.GeneticProgramming.MAX_POP
   if cardPOP < 2*Parameters.GeneticProgramming.MAX_POP
        cardPOP=cardPOP+1;
        R_Generation(cardPOP).tree=Offsprings{counter_Offspring}(1).tree;
        R_Generation(cardPOP).time=Offsprings{counter_Offspring}(1).time;
    if cardPOP < 2*Parameters.GeneticProgramming.MAX_POP
        cardPOP=cardPOP+1;
        R_Generation(cardPOP).tree=Offsprings{counter_Offspring}(2).tree;
        R_Generation(cardPOP).time=Offsprings{counter_Offspring}(2).time;
        counter_Offspring=counter_Offspring+1;
    end
   end
end
   

parfor CounterModel=Parameters.GeneticProgramming.MAX_POP+1:1:2*Parameters.GeneticProgramming.MAX_POP
% for CounterModel=Parameters.GeneticProgramming.MAX_POP+1:1:2*Parameters.GeneticProgramming.MAX_POP
    mutationflag(CounterModel)=rand(1);
    if mutationflag(CounterModel)<=Parameters.GeneticProgramming.MutationChance
        runtimework(CounterModel)=tic();
        [Error,R_Generation(CounterModel).tree,~]=TAGMutation(R_Generation(CounterModel).tree,Parameters.GeneticProgramming.Min_Complexity,Parameters.GeneticProgramming.Max_Complexity,InitTreeTypes,AuxiliaryTreeTypes,Parameters.EquationSolution);
        OffspringRuntime(CounterModel)=toc(runtimework(CounterModel));
        disp(strcat("Mutation Crossover offspring ",num2str(CounterModel)," in ",num2str(OffspringRuntime(CounterModel))," seconds"));
    end
end


%Mutation by random selection through the old population 
%Mutation by random selection through the Crossover-generated offsprings


parfor CounterModel=1:Parameters.GeneticProgramming.MAX_POP
% for CounterModel=1:Parameters.GeneticProgramming.MAX_POP
        R_Generation_Mutation(CounterModel).tree=[];
        runtimework(CounterModel)=tic();
        [Error,R_Generation_Mutation(CounterModel).tree,~]=TAGMutation(R_Generation(CounterModel).tree,Parameters.GeneticProgramming.Min_Complexity,Parameters.GeneticProgramming.Max_Complexity,InitTreeTypes,AuxiliaryTreeTypes,Parameters.EquationSolution);
        OffspringRuntime(CounterModel)=toc(runtimework(CounterModel));
        disp(strcat("Mutation offspring ",num2str(CounterModel)," in ",num2str(OffspringRuntime(CounterModel))," seconds"))
end

for CounterModel=2*Parameters.GeneticProgramming.MAX_POP+1:3*Parameters.GeneticProgramming.MAX_POP
    R_Generation(CounterModel).tree = R_Generation_Mutation(CounterModel-2*Parameters.GeneticProgramming.MAX_POP).tree;
end


% Get the function of the new population Q(t) Q(t) = Crossover-generated
%% and Mutation-generated offsprings
parfor i=Parameters.GeneticProgramming.MAX_POP+1:3*Parameters.GeneticProgramming.MAX_POP
%     for i=Parameters.GeneticProgramming.MAX_POP+1:3*Parameters.GeneticProgramming.MAX_POP
    R_Generation(i).LabelOrderedRepresentation=GetTreeOrderedRepresentation(R_Generation(i).tree);
    R_Generation(i).physical=CreateTreeFunction(R_Generation(i).LabelOrderedRepresentation,Parameters.EquationSolution);
    R_Generation(i).DerivationTree=R_Generation(i).tree.DerivationTree;
    [R_Generation(i).DerivationTree.ElementaryTreeLinkingInfo,R_Generation(i).DerivationTree.ElemArrayParentBranchIndex,R_Generation(i).DerivationTree.ElemArrayConnectionOperation]=GetElemTreeLinkInfo(R_Generation(i).tree);
    R_Generation(i).CreationGeneration=CounterNumberGeneration;
    disp(strcat("R_Generation item ",num2str(i)," function created"));
end
time_Offspring_generator(CounterNumberGeneration)=toc(Offspring_generator);
disp(strcat("Crossover - Mutation offsprings in  ",num2str(CounterNumberGeneration),"th generation took ", num2str(time_Offspring_generator(CounterNumberGeneration))," sec."));

clear ans cardPOP counter_Offspring Crossover_generator lenParent1 lenParent2 mutationflag Offspring_generator OffspringRuntime Offsprings R_Generation_Mutation runtimework selectionOK selectParent1 selectParent2 time_Crossover_generator time_Offspring_generator