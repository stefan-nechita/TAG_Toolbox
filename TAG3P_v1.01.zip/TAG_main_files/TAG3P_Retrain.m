% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

%% Performs a new parameter estimation for any individual from the saved population
% load the indentification data with all the generations
generation=CounterNumberGeneration;
candidate=1; 


IndividualPhsysicalRetrain = Generation{1, generation}(candidate).physical;
Parameters.GeneticProgramming.CMAESParam.w_sim=1;
Parameters.GeneticProgramming.CMAESParam.w_pred=0;
Parameters.GeneticProgramming.CMAESParam.CMAES_GivenStopFitness=1e-10;
Parameters.GeneticProgramming.CMAESParam.CMAES_GivenStopCriterion=1e-15;
Parameters.GeneticProgramming.CMAESParam.CMAES_Iterations=9000;
Parameters.GeneticProgramming.CMAESParam.CMAES_watchdog=1000000;

OldParams=Generation{1, CounterNumberGeneration}(candidate).physical.paramArray;
[NewParams,FittingPerformanceRetrained]=CMAES(IndividualPhsysicalRetrain,Data,Parameters);

Generation{1, CounterNumberGeneration}(candidate).physical.paramArray =NewParams;
