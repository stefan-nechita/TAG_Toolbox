% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

%Create the set of HandleTree based on derivation tree information stored in the Generation{1,noGeneration}

oldpath = path;
path(oldpath,".\TAG_Toolbox");
oldpath = path;
path(oldpath,".\TAG_main_files");
oldpath = path;
path(oldpath,".\DataGeneratingSystem");
noGeneration = noGeneration;
clear ('poolobj')
% if isempty(gcp('nocreate')')
%     parpool;
%     poolobj = gcp;
%     pctRunOnAll warning off
%     addAttachedFiles(poolobj, myFiles);
% else
%     poolobj = gcp;
%     pctRunOnAll warning off
%     addAttachedFiles(poolobj, myFiles);
% end

if (recording == 1)
    writerObj = VideoWriter(strcat('TAG_population_evolution_',date,'_',num2str(floor(cputime)),'.avi'));
    writerObj.FrameRate=3;
    open(writerObj);
end


for counter_indiv=1:MAX_POP
    newIndivElementaryArrayTypes=[Generation{1, noGeneration}(counter_indiv).DerivationTree.ElementaryArrayTypes];
    len_newParentElementaryArray=length(newIndivElementaryArrayTypes);
    
    newIndivCreationInformation.parent=zeros(len_newParentElementaryArray,1);
    newIndivCreationInformation.parentBranchIndex=zeros(len_newParentElementaryArray,1);
    newIndivCreationInformation.TreeType=cell(len_newParentElementaryArray,1);
    newIndivCreationInformation.ConnectionOperator=cell(len_newParentElementaryArray,1);
    newIndivCreationInformation.LinkInfo=cell(len_newParentElementaryArray,1);
    
    
    for i=1:len_newParentElementaryArray
        for j=1:len_newParentElementaryArray
            if Generation{1, noGeneration}(counter_indiv).DerivationTree.AdiacentMatrix(i,j)~=0
                newIndivCreationInformation.parent(j,1)=i;
                
                newIndivCreationInformation.parentBranchIndex(j,1) = Generation{1, noGeneration}(counter_indiv).DerivationTree.ElemArrayParentBranchIndex{j,1};
                
                newIndivCreationInformation.TreeType{j,1} = Generation{1, noGeneration}(counter_indiv).DerivationTree.ElementaryArrayTypes(j,1);
                newIndivCreationInformation.ConnectionOperator{j,1}=Generation{1, noGeneration}(counter_indiv).DerivationTree.ElemArrayConnectionOperation{j,1};
                newIndivCreationInformation.LinkInfo{j,1}= Generation{1, noGeneration}(counter_indiv).DerivationTree.ElementaryTreeLinkingInfo{j,1};
            end
        end
    end
    
    RootOfnewParent = find(newIndivCreationInformation.parent==0);
    newIndivCreationInformation.TreeType{RootOfnewParent,1}=newIndivElementaryArrayTypes(RootOfnewParent,1);
    newIndivCreationInformation.ConnectionOperator{RootOfnewParent,1}="Initialisation";
    %% creating the tree after the mutation index
    
    tic ;
    [Error,newIndiv] = CreateComplexTree(newIndivCreationInformation,ny,nu,nE,InitTreeTypes,MaskLink);
    time1=toc;
    
    if Error==0
        Generation{1, noGeneration}(counter_indiv).tree = newIndiv;
        disp(strcat("Structure ",num2str(counter_indiv)," loaded "));
    end
    
    
end
for i=1:MAX_POP
    Generation{1, noGeneration}(i).LabelOrderedRepresentation=GetTreeOrderedRepresentation(Generation{1, noGeneration}(i).tree);
    Generation{1, noGeneration}(i).DerivationTree=Generation{1, noGeneration}(i).tree.DerivationTree;
    [Generation{1, noGeneration}(i).DerivationTree.ElementaryTreeLinkingInfo,Generation{1, noGeneration}(i).DerivationTree.ElemArrayParentBranchIndex,Generation{1, noGeneration}(i).DerivationTree.ElemArrayConnectionOperation]=GetElemTreeLinkInfo(Generation{1, noGeneration}(i).tree);
%     Generation{1, noGeneration}(i).CreationGeneration=noGeneration;
end