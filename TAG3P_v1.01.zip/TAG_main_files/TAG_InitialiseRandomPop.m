% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.


%% -> Step1 Generate Random Population of TAGs
OldMaxComplexity = Parameters.GeneticProgramming.Max_Complexity;
Parameters.GeneticProgramming.Max_Complexity = 40;
Parameters.GeneticProgramming.Complexity = [Parameters.GeneticProgramming.Min_Complexity, Parameters.GeneticProgramming.Max_Complexity];
CounterNumberGeneration=1;
CounterModel=1; % initialise the generation counter

tstartPopulation=tic();
Generation=cell(1,Parameters.GeneticProgramming.MAX_GEN);
CounterModelTry=0;
while CounterModel<=Parameters.GeneticProgramming.MAX_POP
    CounterModelTry=CounterModelTry+1;
    WorkVariables.ComplexityOrder=randi(Parameters.GeneticProgramming.Complexity,1,1);
    % Generating Random Tree
    tstartIndividual=tic;
    

     %
    % Random Tree generator
    [Population(CounterModel).tree,constrDebug]=CreateRandomTree(WorkVariables.ComplexityOrder,InitTreeTypes,AuxiliaryTreeTypes,Parameters.EquationSolution);
    
    time_pop=toc(tstartIndividual);
    Population(CounterModel).time=time_pop;
    Population(CounterModel).LabelOrderedRepresentation=GetTreeOrderedRepresentation(Population(CounterModel).tree); % Create List of ordered labels
    
        % Debug latex
      Population(CounterModel).LatexTree=[];
      Population(CounterModel).LatexTree=LatexDrawTree( Population(CounterModel).tree.root, Population(CounterModel).LatexTree);
  %%
    Population(CounterModel).physical=CreateTreeFunction( Population(CounterModel).LabelOrderedRepresentation,Parameters.EquationSolution); % Create The funtion handle
    Population(CounterModel).physical.paramArray=zeros(1,Population(CounterModel).physical.noParams); % initialise the parameter array with 0
    Population(CounterModel).DerivationTree=Population(CounterModel).tree.DerivationTree;
    [Population(CounterModel).DerivationTree.ElementaryTreeLinkingInfo,Population(CounterModel).DerivationTree.ElemArrayParentBranchIndex, Population(CounterModel).DerivationTree.ElemArrayConnectionOperation]=GetElemTreeLinkInfo(Population(CounterModel).tree);
    % to add the parameters fitting CMA-Es function here too!! instead of
    % the next line of code  CMAES(individual,u,y,t,w_sim,w_pred)
    Population(CounterModel).CreationGeneration=0;
    
    % Parameter Estimation
    ModelPhysical(CounterModel)=Population(CounterModel).physical; % ModelPhysical = WorkingVariable for parallel computing
    param_fitting_indiv(CounterModel)=tic();  % Profiling
    switch Parameters.GeneticProgramming.ParemeterEstimationSwitch
        case 1
            [IndividualParametrisationResults{CounterModel},FittingPerformance(CounterModel),Runtime_ThisCMAES]=CMAES(ModelPhysical(CounterModel),Data,Parameters);
        case 2
            [IndividualParametrisationResults{CounterModel},FittingPerformance(CounterModel),Runtime_ThisFMINUNC]=ParEst_fminunc(ModelPhysical(CounterModel),Data,Parameters);
        case 3
            [IndividualParametrisationResults{CounterModel},FittingPerformance(CounterModel),Runtime_ThisLS]  = ParEst_LS(ModelPhysical(CounterModel),Data);
    end
    time_param_fitting_indiv(CounterModel)=toc(param_fitting_indiv(CounterModel));
    
    if Parameters.Program.DisplayMessages == 1
        disp(strcat("Parameter estimation of the ",num2str(CounterModel),"th individual N = ",num2str(ModelPhysical(CounterModel).noParams),", took ", num2str(time_param_fitting_indiv(CounterModel))," sec. error: ",num2str(FittingPerformance(CounterModel))));
    end
    
    Population(CounterModel).physical.paramArray=IndividualParametrisationResults{CounterModel};
    
    % asses the performance of each individual
    DataSetIdentifier.uCellIndex =1;
    DataSetIdentifier.yCellIndex =1;
    DataSetIdentifier.Train =0;
    DataSetIdentifier.Test =1;
    DataSetIdentifier.Valid =0;
    
    [Population(CounterModel).performance.SimulationError,Population(CounterModel).performance.y_hat_sim]=SimulationError(Population(CounterModel).physical,Data,DataSetIdentifier);
    [Population(CounterModel).performance.PredictionError,Population(CounterModel).performance.y_hat_pred]=PredictionError(Population(CounterModel).physical,Data,DataSetIdentifier);
    
    if ~(Population(CounterModel).performance.SimulationError==inf || Population(CounterModel).performance.PredictionError==inf)
        CounterModel=CounterModel+1;
    end
    

end
Generation{1}=Population;

clear Runtime_ThisLS Runtime_ThisFMINUNC Runtime_ThisCMAES param_fitting_indiv time_param_fitting_indiv


clear DataSetIdentifier
for CounterModel=1:Parameters.GeneticProgramming.MAX_POP
    Generation{1}(CounterModel).performance.NonPenaltySimulationError=Generation{1}(CounterModel).performance.SimulationError;
    Generation{1}(CounterModel).performance.NonPenaltyPredictionError=Generation{1}(CounterModel).performance.PredictionError;
    Generation{1}(CounterModel).performance.SimulationError = Generation{1}(CounterModel).performance.SimulationError *(1+Parameters.GeneticProgramming.ParameterRegularisation*length(Generation{1}(CounterModel).physical.paramArray));
    Generation{1}(CounterModel).performance.PredictionError = Generation{1}(CounterModel).performance.PredictionError *(1+Parameters.GeneticProgramming.ParameterRegularisation*length(Generation{1}(CounterModel).physical.paramArray));
    Generation{1}(CounterModel).front=1;
end

tme=toc(tstartPopulation);
if Parameters.Program.DisplayMessages == 1
    disp(strcat("The time initialising a population of= ",num2str(Parameters.GeneticProgramming.MAX_POP)," took ", num2str(tme)," seconds and ", num2str(CounterModelTry)," random initialisations"));
end

% END OF PARAMETRISATION PROCEDURE
clear tme population_for_start tstartIndividual ModelPhysical IndividualParametrisationResults FittingPerformance

clear CounterModel CounterModelTry

Parameters.GeneticProgramming.Max_Complexity = OldMaxComplexity;
Parameters.GeneticProgramming.Complexity = [Parameters.GeneticProgramming.Min_Complexity, Parameters.GeneticProgramming.Max_Complexity];
clear OldMaxComplexity OldParamSwitch


