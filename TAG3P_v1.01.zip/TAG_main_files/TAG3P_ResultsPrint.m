% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to
% SysId 2021 conference.


%% Test the solution against the data generating system and print de results.
close all
candidate=1;
CompareOutputChannels =1:1; % the first two output channels are compare -> 1st the mean, 2nd the first harmonic mean
CompareChannelInput=1:Data.nu; % what inputs to show on camparison: 1st = the input that affects the mean, 2nd the input that affects the second harmonic
LineWidth=1;
NumberSubPlotsOutput=length(CompareOutputChannels);
NumberSubPlotsInput=length(CompareChannelInput);
%% Derivation and Derived Tree
% TextRandomTreeDraw=[];
% TextRandomTreeDraw=LatexDrawTree(Generation{noGeneration}(candidate).tree.root,TextRandomTreeDraw);
 ValidationMetrics.Value.BFRs=cell(1,Parameters.GeneticProgramming.ValidationDataSets);
    ValidationMetrics.Value.BFRp=cell(1,Parameters.GeneticProgramming.ValidationDataSets);
   
PlotDerivationTree(Generation{CounterNumberGeneration}(candidate).tree,"")
%
% for ValidDataSetToBeUsed=1:Parameters.GeneticProgramming.ValidationDataSets
for ValidDataSetToBeUsed=1:1
    %
    % tau_final_test=noSamples;
    
    StandardizedData = isfield(Data, 'stdDeviationInput');
    
    switch StandardizedData
        case 0
            % ValidDataSetToBeUsed =1;
            % uvalid=Data.uTrain{1,ValidDataSetToBeUsed};
            % yvalid=Data.yTrain{1,ValidDataSetToBeUsed};
            % DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
            % DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
            % DataSetIdentifier.Train =1;
            % DataSetIdentifier.Test =0;
            % DataSetIdentifier.Valid =0;
            
            
            % uvalid=Data.uTest{1,ValidDataSetToBeUsed};
            % yvalid=Data.yTest{1,ValidDataSetToBeUsed};
            % DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
            % DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
            % DataSetIdentifier.Train =0;
            % DataSetIdentifier.Test =1;
            % DataSetIdentifier.Valid =0;
            
            uvalid=Data.uValid{1,ValidDataSetToBeUsed};
            yvalid=Data.yValid{1,ValidDataSetToBeUsed};
            DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
            DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
            DataSetIdentifier.Train =0;
            DataSetIdentifier.Test =0;
            DataSetIdentifier.Valid =1;
            
            tau_final_test=length(uvalid);
            t=0:Data.Ts:tau_final_test*Data.Ts;
            
            [~,sim_y]=SimulationError(Generation{1, CounterNumberGeneration}(candidate).physical,Data,DataSetIdentifier);
            [~,pred_y]=PredictionError(Generation{1, CounterNumberGeneration}(candidate).physical,Data,DataSetIdentifier);
            
        case 1
            % ValidDataSetToBeUsed =1;
            % uvalid=Data.uTrain{1,ValidDataSetToBeUsed};
            % yvalid=Data.yTrain{1,ValidDataSetToBeUsed};
            % DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
            % DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
            % DataSetIdentifier.Train =1;
            % DataSetIdentifier.Test =0;
            % DataSetIdentifier.Valid =0;
            
            
            % uvalid=Data.uTest{1,ValidDataSetToBeUsed};
            % yvalid=Data.yTest{1,ValidDataSetToBeUsed};
            % DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
            % DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
            % DataSetIdentifier.Train =0;
            % DataSetIdentifier.Test =1;
            % DataSetIdentifier.Valid =0;
            
            uvalid=Data.uValid{1,ValidDataSetToBeUsed}; % The standardized input data
            yvalid=Data.NonStd_yValid{1,ValidDataSetToBeUsed}; % Compare the model output with the non-standardized output data
            DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
            DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
            DataSetIdentifier.Train =0;
            DataSetIdentifier.Test =0;
            DataSetIdentifier.Valid =1;
            
            tau_final_test=length(uvalid);
            t=0:Data.Ts:tau_final_test*Data.Ts;
            
            [~,sim_y]=SimulationError(Generation{1, CounterNumberGeneration}(candidate).physical,Data,DataSetIdentifier);
            [~,pred_y]=PredictionError(Generation{1, CounterNumberGeneration}(candidate).physical,Data,DataSetIdentifier);
            %             unstandardize the model output
            sim_y = sim_y*Data.stdDeviationOutput + Data.meanOutput;
            pred_y = pred_y*Data.stdDeviationOutput + Data.meanOutput;
    end
    %% Computing Best Fit Ratio
    ValidationMetrics.Value.BFRs{1,ValidDataSetToBeUsed} = 100*max(1-(norm(yvalid-sim_y,2)/norm(yvalid-mean(sim_y')',2)),0);
    ValidationMetrics.Value.BFRp{1,ValidDataSetToBeUsed} = 100*max(1-(norm(yvalid-pred_y,2)/norm(yvalid-mean(pred_y')',2)),0);
    for counter_output=1:Data.ny
        WorkVariableSimulation = MetricCompute(yvalid(counter_output,:),sim_y(counter_output,:),0);
        WorkVariablePrediction = MetricCompute(yvalid(counter_output,:),pred_y(counter_output,:),0);
        
        ValidationMetrics.Value.RMSs(counter_output,1) = WorkVariableSimulation.RMS;
        ValidationMetrics.Value.AMSs(counter_output,1) = WorkVariableSimulation.AMS;
        ValidationMetrics.Value.STDRMSs(counter_output,1) = WorkVariableSimulation.STDRMS;
        
        ValidationMetrics.Value.RMSp(counter_output,1) = WorkVariablePrediction.RMS;
        ValidationMetrics.Value.AMSp(counter_output,1) = WorkVariablePrediction.AMS;
        ValidationMetrics.Value.STDRMSp(counter_output,1) = WorkVariablePrediction.STDRMS;
        
        ValidationMetrics.dBValue.RMSs(counter_output,1) =mag2db(ValidationMetrics.Value.RMSs(counter_output,1));
        ValidationMetrics.dBValue.RMSp(counter_output,1) =mag2db(ValidationMetrics.Value.RMSp(counter_output,1));
        ValidationMetrics.dBValue.AMSs(counter_output,1) = mag2db(ValidationMetrics.Value.AMSs(counter_output,1));
        ValidationMetrics.dBValue.AMSp(counter_output,1) = mag2db(ValidationMetrics.Value.AMSp(counter_output,1));
        ValidationMetrics.dBValue.STDRMSs(counter_output,1) = mag2db(ValidationMetrics.Value.STDRMSs(counter_output,1));
        ValidationMetrics.dBValue.STDRMSp(counter_output,1) = mag2db(ValidationMetrics.Value.STDRMSp(counter_output,1));
    end
    
    
    
    for counter_output=1:Data.ny
        for counter_quarter=1:4
            WorkVariableSimulation = MetricCompute(yvalid(counter_output,:),sim_y(counter_output,:),counter_quarter);
            WorkVariablePrediction = MetricCompute(yvalid(counter_output,:),pred_y(counter_output,:),counter_quarter);
            ValidationMetrics.Value.RMSs(counter_output,counter_quarter+1) = WorkVariableSimulation.RMS;
            ValidationMetrics.Value.AMSs(counter_output,counter_quarter+1) = WorkVariableSimulation.AMS;
            ValidationMetrics.Value.STDRMSs(counter_output,counter_quarter+1) = WorkVariableSimulation.STDRMS;
            
            ValidationMetrics.Value.RMSp(counter_output,counter_quarter+1) = WorkVariablePrediction.RMS;
            ValidationMetrics.Value.AMSp(counter_output,counter_quarter+1) = WorkVariablePrediction.AMS;
            ValidationMetrics.Value.STDRMSp(counter_output,counter_quarter+1) = WorkVariablePrediction.STDRMS;
            
            
            ValidationMetrics.dBValue.RMSs(counter_output,counter_quarter+1) =mag2db(ValidationMetrics.Value.RMSs(counter_output,counter_quarter+1));
            ValidationMetrics.dBValue.RMSp(counter_output,counter_quarter+1) =mag2db(ValidationMetrics.Value.RMSp(counter_output,counter_quarter+1));
            ValidationMetrics.dBValue.AMSs(counter_output,counter_quarter+1) = mag2db(ValidationMetrics.Value.AMSs(counter_output,counter_quarter+1));
            ValidationMetrics.dBValue.AMSp(counter_output,counter_quarter+1) = mag2db(ValidationMetrics.Value.AMSp(counter_output,counter_quarter+1));
            ValidationMetrics.dBValue.STDRMSs(counter_output,counter_quarter+1) = mag2db(ValidationMetrics.Value.STDRMSs(counter_output,counter_quarter+1));
            ValidationMetrics.dBValue.STDRMSp(counter_output,counter_quarter+1) = mag2db(ValidationMetrics.Value.STDRMSp(counter_output,counter_quarter+1));
        end
    end
    
    
    % Plot the best from each generation
    
    final_time=t';
    counterPlot=1;
    figure(10*ValidDataSetToBeUsed+1)
    for counter_output=min(CompareOutputChannels):max(CompareOutputChannels)
        subplot(NumberSubPlotsOutput,1,counterPlot)
        plot(t(1:tau_final_test),yvalid(counter_output,(1:tau_final_test)),"linewidth",LineWidth)
        hold on
        plot(t(1:tau_final_test),sim_y(counter_output,(1:tau_final_test)),"linewidth",LineWidth)
        plot(t(1:tau_final_test),pred_y(counter_output,(1:tau_final_test)),"linewidth",LineWidth)
%                                 Error_sim=yvalid(counter_output,1:tau_final_test)-sim_y(counter_output,1:tau_final_test);
%                                 Error_pred=yvalid(counter_output,1:tau_final_test)-pred_y(counter_output,1:tau_final_test);
%                                 plot(t(1:tau_final_test),Error_sim,"linewidth",LineWidth);
%                                 plot(t(1:tau_final_test),Error_pred,"linewidth",LineWidth);
        
                        string1legend = strcat("Simulation output: RMSs =",num2str(ValidationMetrics.Value.RMSs(counter_output,1)), " AMSs =",num2str(ValidationMetrics.Value.AMSs(counter_output,1))," STDRMSs =",num2str(ValidationMetrics.Value.STDRMSs(counter_output,1)));
                        string2legend = strcat("Prediction output: RMSp =",num2str(ValidationMetrics.Value.RMSp(counter_output,1)), " AMSp =",num2str(ValidationMetrics.Value.AMSp(counter_output,1))," STDRMSp =",num2str(ValidationMetrics.Value.STDRMSp(counter_output,1)));
        
        
%         string1legend = strcat("Simulation output: RMSs =",num2str(ValidationMetrics.Value.RMSs(counter_output,1)));
%         string2legend = strcat("Prediction output: RMSp =",num2str(ValidationMetrics.Value.RMSp(counter_output,1)));
        
        legend("yTest", string1legend, string2legend,"Simulation Error","Prediction Error");
%         legend("yTest", string1legend,"Simulation Error","Prediction Error");
        xlabel("time [s]");
        ylabel_String = strcat("$y_",num2str(counter_output),"$",", $ \hat{y}_{",num2str(counter_output),"Sim}$ ",", $ \hat{y}_{",num2str(counter_output),"Pred}$");
        ylabel(ylabel_String,'Interpreter','latex')
        counterPlot=counterPlot+1;
        title(strcat("Candidate: ",num2str(candidate),"Validation data set :",num2str(ValidDataSetToBeUsed)));
    end
    
    figure(10*ValidDataSetToBeUsed+2)
    counterPlot=1;
    for counter_output=min(CompareOutputChannels):max(CompareOutputChannels)
        subplot(NumberSubPlotsOutput,1,counterPlot)
        plot(t(1:tau_final_test),(yvalid(counter_output,1:tau_final_test)-sim_y(counter_output,1:tau_final_test)),"linewidth",LineWidth);
        hold on
        plot(t(1:tau_final_test),(yvalid(counter_output,1:tau_final_test)-pred_y(counter_output,1:tau_final_test)),"linewidth",LineWidth);
        
        string1legend = strcat("Simulation Error RMSs =",num2str(ValidationMetrics.Value.RMSs(1,1)));
        string2legend = strcat("1-step Prediction Error RMSp =",num2str(ValidationMetrics.Value.RMSp(1,1)));
        legend(string1legend,string2legend);
        xlabel("time [s]");
        ylabel_String = strcat("Error $\hat{y}_{",num2str(counter_output),"Sim}",", \hat{y}_{",num2str(counter_output),"Pred}$");
        ylabel(ylabel_String,'Interpreter','latex')
        %         ylabel(strcat("Error y_",num2str(counter_output)))
        counterPlot=counterPlot+1;
        title(strcat("Candidate: ",num2str(candidate),"Validation data set :",num2str(ValidDataSetToBeUsed)));
    end
    %
    figure(10*ValidDataSetToBeUsed+3)
    counterPlot=1;
    for counter_output=min(CompareOutputChannels):max(CompareOutputChannels)
        subplot(NumberSubPlotsOutput,1,counterPlot)
        Error_sim=yvalid(counter_output,1:tau_final_test)-sim_y(counter_output,1:tau_final_test);
        Error_pred=yvalid(counter_output,1:tau_final_test)-pred_y(counter_output,1:tau_final_test);
        Error_proc_sim =( abs(Error_sim) ./ abs(yvalid(counter_output,1:tau_final_test)))*100;
        Error_proc_pred = ( abs(Error_pred) ./ abs(yvalid(counter_output,1:tau_final_test)))*100;
        plot(t(1:tau_final_test),Error_proc_sim,"linewidth",2);
        hold on
        plot(t(1:tau_final_test),Error_proc_pred,"linewidth",2);
        string1legend = strcat("Simulation Error RMSs =",num2str(ValidationMetrics.Value.RMSs(1,1)));
        string2legend = strcat("1-step Prediction Error RMSp =",num2str(ValidationMetrics.Value.RMSp(1,1)));
        legend(string1legend,string2legend);
        title(strcat("Candidate: ",num2str(candidate),"Validation data set :",num2str(ValidDataSetToBeUsed)));
        xlabel("time [s]");
        ylabel_String = strcat("Error $\hat{y}_{",num2str(counter_output),"Sim}",", \hat{y}_{",num2str(counter_output),"Pred} \%$");
        ylabel(ylabel_String,'Interpreter','latex')
        %         ylabel(strcat("Error y_",num2str(counter_output)))
        counterPlot=counterPlot+1;
    end
    drawnow
end
clear counter_output candidate constrDebug counter counterPlot Error_pred Error_porc_pred Error_proc_sim final_time N NormalDistribInputSequence
clear string1legend string2legend uvalid RMSs RMSp  WorkVariablePrediction WorkVariableSimulation
clear plot_generation_counter sim_y pred_y t tau_final_test yvalid ylabel_String workvector uvalid ValidDataSetToBeUsed
clear NumberSubPlotsOutput NumberSubPlotsInput noSamples Error_proc_pred Error_sim CompareOutputChannels CompareChannelInput



% %% Print special for Stir tank
% %% PLOTS FOR SIMULATION OUTPUT + True output
% candidate=1;
% CompareOutputChannels =1:Data.ny; % the first two output channels are compare -> 1st the mean, 2nd the first harmonic mean
% CompareChannelInput=1:Data.nu; % what inputs to show on camparison: 1st = the input that affects the mean, 2nd the input that affects the second harmonic
%
% NumberSubPlotsOutput=length(CompareOutputChannels);
% NumberSubPlotsInput=length(CompareChannelInput);
% for ValidDataSetToBeUsed=13:Parameters.GeneticProgramming.ValidationDataSets
%
%     %
%     % tau_final_test=noSamples;
%
%     StandardizedData = isfield(Data, 'stdDeviationInput');
%
%     switch StandardizedData
%         case 0
%             % ValidDataSetToBeUsed =1;
%             % uvalid=Data.uTrain{1,ValidDataSetToBeUsed};
%             % yvalid=Data.yTrain{1,ValidDataSetToBeUsed};
%             % DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
%             % DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
%             % DataSetIdentifier.Train =1;
%             % DataSetIdentifier.Test =0;
%             % DataSetIdentifier.Valid =0;
%
%
%             % uvalid=Data.uTest{1,ValidDataSetToBeUsed};
%             % yvalid=Data.yTest{1,ValidDataSetToBeUsed};
%             % DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
%             % DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
%             % DataSetIdentifier.Train =0;
%             % DataSetIdentifier.Test =1;
%             % DataSetIdentifier.Valid =0;
%
%             uvalid=Data.uValid{1,ValidDataSetToBeUsed};
%             yvalid=Data.yValid{1,ValidDataSetToBeUsed};
%             DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
%             DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
%             DataSetIdentifier.Train =0;
%             DataSetIdentifier.Test =0;
%             DataSetIdentifier.Valid =1;
%
%             tau_final_test=length(uvalid);
%             t=0:Data.Ts:tau_final_test*Data.Ts;
%
%             [~,sim_y]=SimulationError(Generation{1, CounterNumberGeneration}(candidate).physical,Data,DataSetIdentifier,tau_final_test);
%             [~,pred_y]=PredictionError(Generation{1, CounterNumberGeneration}(candidate).physical,Data,DataSetIdentifier);
%
%         case 1
%             % ValidDataSetToBeUsed =1;
%             % uvalid=Data.uTrain{1,ValidDataSetToBeUsed};
%             % yvalid=Data.yTrain{1,ValidDataSetToBeUsed};
%             % DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
%             % DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
%             % DataSetIdentifier.Train =1;
%             % DataSetIdentifier.Test =0;
%             % DataSetIdentifier.Valid =0;
%
%
%             % uvalid=Data.uTest{1,ValidDataSetToBeUsed};
%             % yvalid=Data.yTest{1,ValidDataSetToBeUsed};
%             % DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
%             % DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
%             % DataSetIdentifier.Train =0;
%             % DataSetIdentifier.Test =1;
%             % DataSetIdentifier.Valid =0;
%
%             uvalid=Data.uValid{1,ValidDataSetToBeUsed}; % The standardized input data
%             yvalid=Data.NonStd_yValid{1,ValidDataSetToBeUsed}; % Compare the model output with the non-standardized output data
%             DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
%             DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
%             DataSetIdentifier.Train =0;
%             DataSetIdentifier.Test =0;
%             DataSetIdentifier.Valid =1;
%
%             tau_final_test=length(uvalid);
%             t=0:Data.Ts:tau_final_test*Data.Ts;
%
%             [~,sim_y]=SimulationError(Generation{1, CounterNumberGeneration}(candidate).physical,Data,DataSetIdentifier,tau_final_test);
%             [~,pred_y]=PredictionError(Generation{1, CounterNumberGeneration}(candidate).physical,Data,DataSetIdentifier);
%             %             unstandardize the model output
%             sim_y = sim_y*Data.stdDeviationOutput + Data.meanOutput;
%             pred_y = pred_y*Data.stdDeviationOutput + Data.meanOutput;
%     end
%
%     for counter_output=1:Data.ny
%         WorkVariableSimulation = MetricCompute(yvalid(counter_output,:),sim_y(counter_output,:),0);
%         WorkVariablePrediction = MetricCompute(yvalid(counter_output,:),pred_y(counter_output,:),0);
%
%         ValidationMetrics.Value.RMSs(counter_output,1) = WorkVariableSimulation.RMS;
%         ValidationMetrics.Value.AMSs(counter_output,1) = WorkVariableSimulation.AMS;
%         ValidationMetrics.Value.STDRMSs(counter_output,1) = WorkVariableSimulation.STDRMS;
%
%         ValidationMetrics.Value.RMSp(counter_output,1) = WorkVariablePrediction.RMS;
%         ValidationMetrics.Value.AMSp(counter_output,1) = WorkVariablePrediction.AMS;
%         ValidationMetrics.Value.STDRMSp(counter_output,1) = WorkVariablePrediction.STDRMS;
%
%         ValidationMetrics.dBValue.RMSs(counter_output,1) =mag2db(ValidationMetrics.Value.RMSs(counter_output,1));
%         ValidationMetrics.dBValue.RMSp(counter_output,1) =mag2db(ValidationMetrics.Value.RMSp(counter_output,1));
%         ValidationMetrics.dBValue.AMSs(counter_output,1) = mag2db(ValidationMetrics.Value.AMSs(counter_output,1));
%         ValidationMetrics.dBValue.AMSp(counter_output,1) = mag2db(ValidationMetrics.Value.AMSp(counter_output,1));
%         ValidationMetrics.dBValue.STDRMSs(counter_output,1) = mag2db(ValidationMetrics.Value.STDRMSs(counter_output,1));
%         ValidationMetrics.dBValue.STDRMSp(counter_output,1) = mag2db(ValidationMetrics.Value.STDRMSp(counter_output,1));
%     end
%
%
%
%     for counter_output=1:Data.ny
%         for counter_quarter=1:4
%             WorkVariableSimulation = MetricCompute(yvalid(counter_output,:),sim_y(counter_output,:),counter_quarter);
%             WorkVariablePrediction = MetricCompute(yvalid(counter_output,:),pred_y(counter_output,:),counter_quarter);
%             ValidationMetrics.Value.RMSs(counter_output,counter_quarter+1) = WorkVariableSimulation.RMS;
%             ValidationMetrics.Value.AMSs(counter_output,counter_quarter+1) = WorkVariableSimulation.AMS;
%             ValidationMetrics.Value.STDRMSs(counter_output,counter_quarter+1) = WorkVariableSimulation.STDRMS;
%
%             ValidationMetrics.Value.RMSp(counter_output,counter_quarter+1) = WorkVariablePrediction.RMS;
%             ValidationMetrics.Value.AMSp(counter_output,counter_quarter+1) = WorkVariablePrediction.AMS;
%             ValidationMetrics.Value.STDRMSp(counter_output,counter_quarter+1) = WorkVariablePrediction.STDRMS;
%
%
%             ValidationMetrics.dBValue.RMSs(counter_output,counter_quarter+1) =mag2db(ValidationMetrics.Value.RMSs(counter_output,counter_quarter+1));
%             ValidationMetrics.dBValue.RMSp(counter_output,counter_quarter+1) =mag2db(ValidationMetrics.Value.RMSp(counter_output,counter_quarter+1));
%             ValidationMetrics.dBValue.AMSs(counter_output,counter_quarter+1) = mag2db(ValidationMetrics.Value.AMSs(counter_output,counter_quarter+1));
%             ValidationMetrics.dBValue.AMSp(counter_output,counter_quarter+1) = mag2db(ValidationMetrics.Value.AMSp(counter_output,counter_quarter+1));
%             ValidationMetrics.dBValue.STDRMSs(counter_output,counter_quarter+1) = mag2db(ValidationMetrics.Value.STDRMSs(counter_output,counter_quarter+1));
%             ValidationMetrics.dBValue.STDRMSp(counter_output,counter_quarter+1) = mag2db(ValidationMetrics.Value.STDRMSp(counter_output,counter_quarter+1));
%         end
%     end
%
%
%     % Plot the best from each generation
%
%     final_time=t';
%     counterPlot=1;
%     figure(10*ValidDataSetToBeUsed+1)
%     for counter_output=min(CompareOutputChannels):max(CompareOutputChannels)
%         subplot(NumberSubPlotsOutput,1,counterPlot)
%         plot(t(1:tau_final_test),yvalid(counter_output,(1:tau_final_test)),"linewidth",2)
%         hold on
%         plot(t(1:tau_final_test),sim_y(counter_output,(1:tau_final_test)),"linewidth",2)
%         %         plot(t(1:tau_final_test),pred_y(counter_output,(1:tau_final_test)),"linewidth",2)
%         Error_sim=yvalid(counter_output,1:tau_final_test)-sim_y(counter_output,1:tau_final_test);
%         switch counter_output
%             case 1
%                 Error_sim=Error_sim+[420].*ones(1,tau_final_test);
%             case 2
%                 Error_sim=Error_sim+[200].*ones(1,tau_final_test);
%         end
%         %                 Error_pred=yvalid(counter_output,1:tau_final_test)-pred_y(counter_output,1:tau_final_test);
%         plot(t(1:tau_final_test),Error_sim,"linewidth",2);
%         %                 plot(t(1:tau_final_test),Error_pred,"linewidth",2);
%
%         %         string1legend = strcat("Simulation output: RMSs =",num2str(ValidationMetrics.Value.RMSs(counter_output,1)), " AMSs =",num2str(ValidationMetrics.Value.AMSs(counter_output,1))," STDRMSs =",num2str(ValidationMetrics.Value.STDRMSs(counter_output,1)));
%         %         string2legend = strcat("Prediction output: RMSp =",num2str(ValidationMetrics.Value.RMSp(counter_output,1)), " AMSp =",num2str(ValidationMetrics.Value.AMSp(counter_output,1))," STDRMSp =",num2str(ValidationMetrics.Value.STDRMSp(counter_output,1)));
%
%
%         string1legend = strcat("Simulation output: RMSs =",num2str(ValidationMetrics.Value.RMSs(counter_output,1)));
%         %                 string2legend = strcat("Prediction output: RMSp =",num2str(ValidationMetrics.Value.RMSp(counter_output,1)));
%         %
%         %         legend("yTest", string1legend, string2legend,"Simulation Error","Prediction Error");
%         switch counter_output
%             case 1
%                 legend("yTest true", string1legend,"Simulation Error + 420")
%             case 2
%                 legend("yTest true", string1legend,"Simulation Error + 200")
%         end
%         %         legend("yTest", string1legend,"Simulation Error")
%         xlabel("time [s]");
%         ylabel_String = strcat("$y_",num2str(counter_output),"$",", $ \hat{y}_{",num2str(counter_output),"Sim}$ ");
%         ylabel(ylabel_String,'Interpreter','latex')
%         counterPlot=counterPlot+1;
%         title(strcat("Candidate: ",num2str(candidate),"Validation data set :",num2str(ValidDataSetToBeUsed)));
%         grid on
%
%     end
%
%         figure(10*ValidDataSetToBeUsed+2)
%     drawnow
% end
%
%
% %% PLOTS FOR SIMULATION OUTPUT + True output
% candidate=1;
% CompareOutputChannels =1:Data.ny; % the first two output channels are compare -> 1st the mean, 2nd the first harmonic mean
% CompareChannelInput=1:Data.nu; % what inputs to show on camparison: 1st = the input that affects the mean, 2nd the input that affects the second harmonic
%
% NumberSubPlotsOutput=length(CompareOutputChannels);
% NumberSubPlotsInput=length(CompareChannelInput);
% for ValidDataSetToBeUsed=12:12
%
%     %
%     % tau_final_test=noSamples;
%
%     StandardizedData = isfield(Data, 'stdDeviationInput');
%
%     switch StandardizedData
%         case 0
%             % ValidDataSetToBeUsed =1;
%             % uvalid=Data.uTrain{1,ValidDataSetToBeUsed};
%             % yvalid=Data.yTrain{1,ValidDataSetToBeUsed};
%             % DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
%             % DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
%             % DataSetIdentifier.Train =1;
%             % DataSetIdentifier.Test =0;
%             % DataSetIdentifier.Valid =0;
%
%
%             % uvalid=Data.uTest{1,ValidDataSetToBeUsed};
%             % yvalid=Data.yTest{1,ValidDataSetToBeUsed};
%             % DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
%             % DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
%             % DataSetIdentifier.Train =0;
%             % DataSetIdentifier.Test =1;
%             % DataSetIdentifier.Valid =0;
%
%             uvalid=Data.uValid{1,ValidDataSetToBeUsed};
%             yvalid=Data.yValid{1,ValidDataSetToBeUsed};
%             DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
%             DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
%             DataSetIdentifier.Train =0;
%             DataSetIdentifier.Test =0;
%             DataSetIdentifier.Valid =1;
%
%             tau_final_test=length(uvalid);
%             t=0:Data.Ts:tau_final_test*Data.Ts;
%
%             [~,sim_y]=SimulationError(Generation{1, CounterNumberGeneration}(candidate).physical,Data,DataSetIdentifier,tau_final_test);
%             [~,pred_y]=PredictionError(Generation{1, CounterNumberGeneration}(candidate).physical,Data,DataSetIdentifier);
%
%         case 1
%             % ValidDataSetToBeUsed =1;
%             % uvalid=Data.uTrain{1,ValidDataSetToBeUsed};
%             % yvalid=Data.yTrain{1,ValidDataSetToBeUsed};
%             % DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
%             % DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
%             % DataSetIdentifier.Train =1;
%             % DataSetIdentifier.Test =0;
%             % DataSetIdentifier.Valid =0;
%
%
%             % uvalid=Data.uTest{1,ValidDataSetToBeUsed};
%             % yvalid=Data.yTest{1,ValidDataSetToBeUsed};
%             % DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
%             % DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
%             % DataSetIdentifier.Train =0;
%             % DataSetIdentifier.Test =1;
%             % DataSetIdentifier.Valid =0;
%
%             uvalid=Data.uValid{1,ValidDataSetToBeUsed}; % The standardized input data
%             yvalid=Data.NonStd_yValid{1,ValidDataSetToBeUsed}; % Compare the model output with the non-standardized output data
%             DataSetIdentifier.uCellIndex =ValidDataSetToBeUsed;
%             DataSetIdentifier.yCellIndex =ValidDataSetToBeUsed;
%             DataSetIdentifier.Train =0;
%             DataSetIdentifier.Test =0;
%             DataSetIdentifier.Valid =1;
%
%             tau_final_test=length(uvalid);
%             t=0:Data.Ts:tau_final_test*Data.Ts;
%
%             [~,sim_y]=SimulationError(Generation{1, CounterNumberGeneration}(candidate).physical,Data,DataSetIdentifier,tau_final_test);
%             [~,pred_y]=PredictionError(Generation{1, CounterNumberGeneration}(candidate).physical,Data,DataSetIdentifier);
%             %             unstandardize the model output
%             sim_y = sim_y*Data.stdDeviationOutput + Data.meanOutput;
%             pred_y = pred_y*Data.stdDeviationOutput + Data.meanOutput;
%     end
%
%     for counter_output=1:Data.ny
%         WorkVariableSimulation = MetricCompute(yvalid(counter_output,:),sim_y(counter_output,:),0);
%         WorkVariablePrediction = MetricCompute(yvalid(counter_output,:),pred_y(counter_output,:),0);
%
%         ValidationMetrics.Value.RMSs(counter_output,1) = WorkVariableSimulation.RMS;
%         ValidationMetrics.Value.AMSs(counter_output,1) = WorkVariableSimulation.AMS;
%         ValidationMetrics.Value.STDRMSs(counter_output,1) = WorkVariableSimulation.STDRMS;
%
%         ValidationMetrics.Value.RMSp(counter_output,1) = WorkVariablePrediction.RMS;
%         ValidationMetrics.Value.AMSp(counter_output,1) = WorkVariablePrediction.AMS;
%         ValidationMetrics.Value.STDRMSp(counter_output,1) = WorkVariablePrediction.STDRMS;
%
%         ValidationMetrics.dBValue.RMSs(counter_output,1) =mag2db(ValidationMetrics.Value.RMSs(counter_output,1));
%         ValidationMetrics.dBValue.RMSp(counter_output,1) =mag2db(ValidationMetrics.Value.RMSp(counter_output,1));
%         ValidationMetrics.dBValue.AMSs(counter_output,1) = mag2db(ValidationMetrics.Value.AMSs(counter_output,1));
%         ValidationMetrics.dBValue.AMSp(counter_output,1) = mag2db(ValidationMetrics.Value.AMSp(counter_output,1));
%         ValidationMetrics.dBValue.STDRMSs(counter_output,1) = mag2db(ValidationMetrics.Value.STDRMSs(counter_output,1));
%         ValidationMetrics.dBValue.STDRMSp(counter_output,1) = mag2db(ValidationMetrics.Value.STDRMSp(counter_output,1));
%     end
%
%
%
%     for counter_output=1:Data.ny
%         for counter_quarter=1:4
%             WorkVariableSimulation = MetricCompute(yvalid(counter_output,:),sim_y(counter_output,:),counter_quarter);
%             WorkVariablePrediction = MetricCompute(yvalid(counter_output,:),pred_y(counter_output,:),counter_quarter);
%             ValidationMetrics.Value.RMSs(counter_output,counter_quarter+1) = WorkVariableSimulation.RMS;
%             ValidationMetrics.Value.AMSs(counter_output,counter_quarter+1) = WorkVariableSimulation.AMS;
%             ValidationMetrics.Value.STDRMSs(counter_output,counter_quarter+1) = WorkVariableSimulation.STDRMS;
%
%             ValidationMetrics.Value.RMSp(counter_output,counter_quarter+1) = WorkVariablePrediction.RMS;
%             ValidationMetrics.Value.AMSp(counter_output,counter_quarter+1) = WorkVariablePrediction.AMS;
%             ValidationMetrics.Value.STDRMSp(counter_output,counter_quarter+1) = WorkVariablePrediction.STDRMS;
%
%
%             ValidationMetrics.dBValue.RMSs(counter_output,counter_quarter+1) =mag2db(ValidationMetrics.Value.RMSs(counter_output,counter_quarter+1));
%             ValidationMetrics.dBValue.RMSp(counter_output,counter_quarter+1) =mag2db(ValidationMetrics.Value.RMSp(counter_output,counter_quarter+1));
%             ValidationMetrics.dBValue.AMSs(counter_output,counter_quarter+1) = mag2db(ValidationMetrics.Value.AMSs(counter_output,counter_quarter+1));
%             ValidationMetrics.dBValue.AMSp(counter_output,counter_quarter+1) = mag2db(ValidationMetrics.Value.AMSp(counter_output,counter_quarter+1));
%             ValidationMetrics.dBValue.STDRMSs(counter_output,counter_quarter+1) = mag2db(ValidationMetrics.Value.STDRMSs(counter_output,counter_quarter+1));
%             ValidationMetrics.dBValue.STDRMSp(counter_output,counter_quarter+1) = mag2db(ValidationMetrics.Value.STDRMSp(counter_output,counter_quarter+1));
%         end
%     end
%
%
%     % Plot the best from each generation
%
%     final_time=t';
%     counterPlot=1;
%     figure(10*ValidDataSetToBeUsed+1)
%     for counter_output=min(CompareOutputChannels):max(CompareOutputChannels)
%         subplot(NumberSubPlotsOutput,1,counterPlot)
%         plot(t(1:tau_final_test),yvalid(counter_output,(1:tau_final_test)),"linewidth",2)
%         hold on
% %         plot(t(1:tau_final_test),sim_y(counter_output,(1:tau_final_test)),"linewidth",2)
%                 plot(t(1:tau_final_test),pred_y(counter_output,(1:tau_final_test)),"linewidth",2)
%         Error_pred=yvalid(counter_output,1:tau_final_test)-pred_y(counter_output,1:tau_final_test);
%         switch counter_output
%             case 1
%                 Error_pred=Error_pred+[420].*ones(1,tau_final_test);
%             case 2
%                 Error_pred=Error_pred+[200].*ones(1,tau_final_test);
%         end
%         %
% %         plot(t(1:tau_final_test),Error_sim,"linewidth",2);
%                         plot(t(1:tau_final_test),Error_pred,"linewidth",2);
%
%         %         string1legend = strcat("Simulation output: RMSs =",num2str(ValidationMetrics.Value.RMSs(counter_output,1)), " AMSs =",num2str(ValidationMetrics.Value.AMSs(counter_output,1))," STDRMSs =",num2str(ValidationMetrics.Value.STDRMSs(counter_output,1)));
%         %         string2legend = strcat("Prediction output: RMSp =",num2str(ValidationMetrics.Value.RMSp(counter_output,1)), " AMSp =",num2str(ValidationMetrics.Value.AMSp(counter_output,1))," STDRMSp =",num2str(ValidationMetrics.Value.STDRMSp(counter_output,1)));
%
%
%         string1legend = strcat("Prediction output: RMSp =",num2str(ValidationMetrics.Value.RMSp(counter_output,1)));
%         %                 string2legend = strcat("Prediction output: RMSp =",num2str(ValidationMetrics.Value.RMSp(counter_output,1)));
%         %
%         %         legend("yTest", string1legend, string2legend,"Simulation Error","Prediction Error");
%         switch counter_output
%             case 1
%                 legend("yTest noisy", string1legend,"Prediction Error + 420")
%             case 2
%                 legend("yTest noisy", string1legend,"Prediction Error + 200")
%         end
%         %         legend("yTest", string1legend,"Simulation Error")
%         xlabel("time [s]");
%         ylabel_String = strcat("$y_",num2str(counter_output),"$",", $ \hat{y}_{",num2str(counter_output),"Pred}$ ");
%         ylabel(ylabel_String,'Interpreter','latex')
%         counterPlot=counterPlot+1;
%         title(strcat("Candidate: ",num2str(candidate),"Validation data set :",num2str(ValidDataSetToBeUsed)));
%         grid on
%
%     end
%
%         figure(10*ValidDataSetToBeUsed+2)
%     drawnow
% end

function [Value]= MetricCompute(RealData,ModeledData,Quarter)
lengthData=length(RealData);
if Quarter == 0
    Value.RMS=sqrt(sum((ModeledData(1,(1:lengthData))-RealData(1,(1:lengthData))).^2)/lengthData);
    Value.AMS=abs(sum((ModeledData(1,(1:lengthData))-RealData(1,(1:lengthData))).^2)/lengthData);
    Value.STDRMS= sqrt(sum((RealData(1,(1:lengthData))-ModeledData(1,(1:lengthData))-Value.AMS).^2)/(lengthData-1));
    %     Value.RMS=sqrt(sum((ModeledData(1,(1:lengthData))-RealData(1,(1:lengthData))).^2));
    %     Value.AMS=abs(sum((ModeledData(1,(1:lengthData))-RealData(1,(1:lengthData))).^2));
    %     Value.STDRMS= sqrt(sum((RealData(1,(1:lengthData))-ModeledData(1,(1:lengthData))-Value.AMS).^2));
else
    Value.RMS=sqrt(sum((ModeledData(1,(round((Quarter-1)*(lengthData/4))+1:round(Quarter*(lengthData/4))))-RealData(1,(round((Quarter-1)*(lengthData/4))+1:round(Quarter*(lengthData/4))))).^2)/round((lengthData/4)));
    Value.AMS=abs(sum((ModeledData(1,(round((Quarter-1)*(lengthData/4))+1:round(Quarter*(lengthData/4))))-RealData(1,(round((Quarter-1)*(lengthData/4))+1:round(Quarter*(lengthData/4))))).^2)/round((lengthData/4)));
    Value.STDRMS=sqrt(sum((RealData(1,(round((Quarter-1)*(lengthData/4))+1:round(Quarter*(lengthData/4))))-ModeledData(1,(round((Quarter-1)*(lengthData/4))+1:round(Quarter*(lengthData/4))))-Value.AMS).^2)/round((lengthData/4)));
end
end
