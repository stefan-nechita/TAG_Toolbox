% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.


%     %% -> Step4 Perform a sorting based on prediction fitness
%     function sorting=tic;
%     R_Generation_simulation_error=zeros(1,2*MAX_POP); for
%     counter=1:2*MAX_POP
%         R_Generation_simulation_error(counter)=R_Generation(counter).performance.SimulationError;
%
%     end [R_Generation_simulation_error_sorted,
%     R_Generation_simulation_error_index] =
%     sort(R_Generation_simulation_error); % minimization
%
%     for counter=1:MAX_POP
%         Generation{CounterNumberGeneration+1}(counter) =
%         R_Generation(R_Generation_simulation_error_index(counter));
%     end time_sorting(CounterNumberGeneration)=toc(sorting); string1=strcat("The
%     time for sorting the ",num2str(CounterNumberGeneration),"th generation took
%     ", num2str(time_sorting(CounterNumberGeneration))," seconds.");
%     disp(string1);


%     %-> Step4 Perform non-dominated sorting of population and propose
%     new population (NSGA-II)

sorting=tic;
R_Generation_Front = NSGAII(R_Generation);

%Collect the Performance of the pareto solution front

GeneticEvolutionData.PerformanceFitnessParetoSolution{1, 1} =[GeneticEvolutionData.PerformanceFitnessParetoSolution{1, 1}  ,0];
GeneticEvolutionData.PerformanceFitnessParetoSolution{1, 2} =[GeneticEvolutionData.PerformanceFitnessParetoSolution{1, 2}  ,0];
for CounterModel = 1:length(R_Generation_Front(1).Set)
    GeneticEvolutionData.PerformanceFitnessParetoSolution{1,1}(CounterNumberGeneration) = GeneticEvolutionData.PerformanceFitnessParetoSolution{1,1}(CounterNumberGeneration)+ R_Generation_Front(1).Set(1, CounterModel).fitness(1);
end
GeneticEvolutionData.PerformanceFitnessParetoSolution{1,1}(CounterNumberGeneration) =GeneticEvolutionData.PerformanceFitnessParetoSolution{1,1}(CounterNumberGeneration)/length(R_Generation_Front(1).Set);

for CounterModel = 1:length(R_Generation_Front(1).Set)
    GeneticEvolutionData.PerformanceFitnessParetoSolution{1,2}(CounterNumberGeneration) = GeneticEvolutionData.PerformanceFitnessParetoSolution{1,2}(CounterNumberGeneration)+ R_Generation_Front(1).Set(1, CounterModel).fitness(2);
end
GeneticEvolutionData.PerformanceFitnessParetoSolution{1,2}(CounterNumberGeneration) = GeneticEvolutionData.PerformanceFitnessParetoSolution{1,2}(CounterNumberGeneration)/length(R_Generation_Front(1).Set);

%Colect the information and compose the next generation
counter_front=1;
population_counter=0;
len_Front=0;
overflow=0;
while (~isempty(R_Generation_Front(counter_front).Set) && overflow~=1 && population_counter~=Parameters.GeneticProgramming.MAX_POP)
    len_Front=length(R_Generation_Front(counter_front).Set);
    
    if ((population_counter+len_Front)>Parameters.GeneticProgramming.MAX_POP)
        overflow=1;
    else
        for counter_indivWithinFront=1:len_Front
            population_counter=population_counter+1;
            Generation{CounterNumberGeneration+1}(population_counter)=R_Generation(R_Generation_Front(counter_front).Set(counter_indivWithinFront).index);
        end
        counter_front=counter_front+1;
    end
end

if (population_counter<Parameters.GeneticProgramming.MAX_POP && overflow==1)
    counter_indivWithinFront=1;
    while population_counter<Parameters.GeneticProgramming.MAX_POP
        population_counter=population_counter+1;
        Generation{CounterNumberGeneration+1}(population_counter)=R_Generation(R_Generation_Front(counter_front).Set(counter_indivWithinFront).index);
        counter_indivWithinFront=counter_indivWithinFront+1;
    end
end


counter_front=1;
population_counter=0;
len_Front=0;
overflow=0;
while (~isempty(R_Generation_Front(counter_front).Set) && overflow~=1 && population_counter~=Parameters.GeneticProgramming.MAX_POP)
    len_Front=length(R_Generation_Front(counter_front).Set);
    
    if ((population_counter+len_Front)>Parameters.GeneticProgramming.MAX_POP)
        overflow=1;
    else
        for counter_indivWithinFront=1:len_Front
            population_counter=population_counter+1;
            Generation{CounterNumberGeneration+1}(population_counter).front=counter_front;
        end
        counter_front=counter_front+1;
    end
end

if (population_counter<Parameters.GeneticProgramming.MAX_POP && overflow==1)
    counter_indivWithinFront=1;
    while population_counter<Parameters.GeneticProgramming.MAX_POP
        population_counter=population_counter+1;
       Generation{CounterNumberGeneration+1}(population_counter).front=counter_front;
        counter_indivWithinFront=counter_indivWithinFront+1;
    end
end





time_sorting(CounterNumberGeneration)=toc(sorting);
if Parameters.Program.DisplayMessages ==1
    disp(strcat("The time for sorting the ",num2str(CounterNumberGeneration),"th generation took ", num2str(time_sorting(CounterNumberGeneration))," seconds."));
    
end
%
% Compute the performance of the new generation and compare it with the
% last one in order to determine if the performance error has a
% significance change

clear sorting R_Generation_Front counter_indivWithinFront overflow Validation_runtime_start WorkVariables time_param_fitting SimulationErrorMatrix PredictionErrorMatrix param_fitting OffspringSetLength
clear IndividualPhysical  population_counter time_sorting len_Front counter_front