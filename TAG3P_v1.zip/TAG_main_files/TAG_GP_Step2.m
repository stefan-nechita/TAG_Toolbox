% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

%% -> Step2 Estimate the parameters of each TAG (CMA-ES) only on the
% second half of R(t), because the first half was aleardy fitted with
% the best parameters last iteration or right after the initialisation
% This file is within the while loop
param_fitting=tic;
LengthRGen=length(R_Generation);
IndividualParametrisationResults=cell(1,LengthRGen);
FittingPerformance=zeros(1,LengthRGen);
for  CounterModel= Parameters.GeneticProgramming.MAX_POP+1:LengthRGen
    R_Generation(CounterModel).physical.paramArray=zeros(1,R_Generation(CounterModel).physical.noParams);
end


for  CounterModel= Parameters.GeneticProgramming.MAX_POP+1:1:LengthRGen
    IndividualPhysical( CounterModel)=R_Generation( CounterModel).physical;
end

parfor CounterModel= Parameters.GeneticProgramming.MAX_POP+1:LengthRGen
    %     for  CounterModel= Parameters.GeneticProgramming.MAX_POP+1:1:2* Parameters.GeneticProgramming.MAX_POP
    % Parameter Estimation to be added.
    param_fitting_indiv=tic;
    switch Parameters.GeneticProgramming.ParemeterEstimationSwitch
        case 1
            [IndividualParametrisationResults{ CounterModel},FittingPerformance( CounterModel),~]=CMAES(IndividualPhysical( CounterModel),Data,Parameters);
        case 2
            [IndividualParametrisationResults{ CounterModel},FittingPerformance( CounterModel),~]=ParEst_fminunc(IndividualPhysical( CounterModel),Data.uTrain{1,1},Data.yTrain{1,1},Data.ETrain{1,1},t,w_sim,w_pred,tau_param_fitting,FminuncParam);
        case 3
            [IndividualParametrisationResults{ CounterModel},FittingPerformance( CounterModel),~]=ParEst_LS(IndividualPhysical( CounterModel),Data);  
    end
    time_param_fitting_indiv=toc(param_fitting_indiv);
    if CounterNumberGeneration>=2
        %         if FittingPerformance( CounterModel)<=PerformancePrediction_pareto_sol(noGeneration-1)
        if FittingPerformance(CounterModel)<=inf
            if Parameters.Program.DisplayMessages == 1
                disp(strcat("Param. est. for the ",num2str( CounterModel),"th individual N = ",num2str(IndividualPhysical( CounterModel).noParams),", took ", num2str(time_param_fitting_indiv)," sec. with error: ",num2str(FittingPerformance( CounterModel))));
            end
        end
    end
    
end
GenerationParameterEstimation(CounterNumberGeneration)=toc(param_fitting);
if Parameters.Program.DisplayMessages == 1
    disp(strcat("Parameter estimation for the ",num2str(CounterNumberGeneration),"generation took ", num2str(GenerationParameterEstimation(CounterNumberGeneration))," seconds."));
end
for  CounterModel= Parameters.GeneticProgramming.MAX_POP+1:1:LengthRGen
    R_Generation(CounterModel).physical.paramArray=IndividualParametrisationResults{CounterModel};
end

clear IndividualParametrisationResults LengthRGen time_param_fitting_indiv param_fitting_indiv
