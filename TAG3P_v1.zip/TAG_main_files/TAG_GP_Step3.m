% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

% -> Step3 Compute the multi-objective fitness of each TAG Simulation
%Error and Prediction Error only for the second half of the R(t) set,
%the first half was evaluated last iteration or at the initialisation
% Propose a different set of data in order to validate the models

LengthRGen=length(R_Generation);
OffspringSetLength=LengthRGen-Parameters.GeneticProgramming.MAX_POP;
Validation_runtime_start = tic();
SimulationErrorMatrix = zeros(LengthRGen,Parameters.GeneticProgramming.TestingDataSets);
PredictionErrorMatrix = zeros(LengthRGen,Parameters.GeneticProgramming.TestingDataSets);
Average_SimulationError=zeros(1,LengthRGen);
Average_PredictionError=zeros(1,LengthRGen);
if Parameters.GeneticProgramming.TestingDataSets>1
    DataSetIdentifier.uCellIndex =1;
    DataSetIdentifier.yCellIndex =1;
    DataSetIdentifier.Train =0;
    DataSetIdentifier.Test =1;
    DataSetIdentifier.Valid =0;
    for CounterDataSet=1:Parameters.GeneticProgramming.TestingDataSets
        DataSetIdentifier.uCellIndex =CounterDataSet;
        DataSetIdentifier.yCellIndex =CounterDataSet;
        disp(strcat("Validate Data Set ",num2str(CounterDataSet)));
%         parfor CounterModel=1:LengthRGen
        for CounterModel=1:LengthRGen
            [SimulationErrorMatrix(CounterModel,CounterDataSet),~]=SimulationError(R_Generation(CounterModel).physical,Data,DataSetIdentifier,Parameters.EquationSolution.tau_structure_sorting);
            [PredictionErrorMatrix(CounterModel,CounterDataSet),~]=PredictionError(R_Generation(CounterModel).physical,Data,DataSetIdentifier);
            if Parameters.Program.DisplayMessages ==1
                disp(strcat("Validate indiv ",num2str(CounterModel), " Data set ",num2str(CounterDataSet)));
            end
        end
        if Parameters.Program.DisplayMessages ==1
            disp(strcat("Validate Data Set ",num2str(CounterDataSet), " --Done"));
        end
    end
    clear DataSetIdentifier
    
    
    for CounterModel=1:LengthRGen
        Average_SimulationError(CounterModel)=mean(SimulationErrorMatrix(CounterModel,:));
        Average_PredictionError(CounterModel)=mean(PredictionErrorMatrix(CounterModel,:));
        if isnumeric(R_Generation(CounterModel).physical.paramArray)
            [R_Generation(CounterModel).performance.SimulationError]=Average_SimulationError(CounterModel)*(1+Parameters.GeneticProgramming.ParameterRegularisation*norm(R_Generation(CounterModel).physical.paramArray,1));
            [R_Generation(CounterModel).performance.PredictionError]=Average_PredictionError(CounterModel)*(1+Parameters.GeneticProgramming.ParameterRegularisation*norm(R_Generation(CounterModel).physical.paramArray,1));
        else
            R_Generation(CounterModel).performance.SimulationError=inf;
            R_Generation(CounterModel).performance.PredictionError=inf;
        end
        R_Generation(CounterModel).performance.NonPenaltySimulationError=Average_SimulationError(CounterModel);
        R_Generation(CounterModel).performance.NonPenaltyPredictionError=Average_PredictionError(CounterModel);
        % add complexity penalty
        len_individual=0;
        for CounterLength=1:length(R_Generation(CounterModel).tree.DerivationTree.ElementaryArrayTypes)
            if ~isempty(R_Generation(CounterModel).DerivationTree.ElemArrayConnectionOperation{CounterLength})
                if R_Generation(CounterModel).DerivationTree.ElemArrayConnectionOperation{CounterLength}=="Adjunction"
                    len_individual=len_individual+1;
                end
            end
        end
        if len_individual > Parameters.GeneticProgramming.Max_Complexity
            total_penalty = (len_individual - Parameters.GeneticProgramming.Max_Complexity)*Parameters.GeneticProgramming.ComplexityPenalty;
            R_Generation(CounterModel).performance.SimulationError=R_Generation(CounterModel).performance.SimulationError+total_penalty;
            R_Generation(CounterModel).performance.PredictionError=R_Generation(CounterModel).performance.PredictionError+total_penalty;
        end
        % add parameter penalty
        %         param_indiv = R_Generation(CounterModel).physical.noParams;
        %         R_Generation(CounterModel).performance.SimulationError=R_Generation(CounterModel).performance.SimulationError+param_indiv*Parameters.GeneticProgramming.ParameterPenalty;
        %         R_Generation(CounterModel).performance.PredictionError=R_Generation(CounterModel).performance.PredictionError+param_indiv*Parameters.GeneticProgramming.ParameterPenalty;
        if Parameters.GeneticProgramming.NoStructurePenalty ==1
            if len_individual ==1
                R_Generation(CounterModel).performance.SimulationError = inf;
                R_Generation(CounterModel).performance.PredictionError = inf;
            end
        end
    end
    
    
else
    DataSetIdentifier.uCellIndex =1;
    DataSetIdentifier.yCellIndex =1;
    DataSetIdentifier.Train =0;
    DataSetIdentifier.Test =1;
    DataSetIdentifier.Valid =0;
    for CounterModel=Parameters.GeneticProgramming.MAX_POP:LengthRGen
        [SimulationErrorWorkVariable,~]=SimulationError(R_Generation(CounterModel).physical,Data,DataSetIdentifier,Parameters.EquationSolution.tau_structure_sorting);
        [PredictionErrorWorkVariable,~]=PredictionError(R_Generation(CounterModel).physical,Data,DataSetIdentifier);
        Average_SimulationError(CounterModel)=SimulationErrorWorkVariable;
        Average_PredictionError(CounterModel)=PredictionErrorWorkVariable;
        [R_Generation(CounterModel).performance.SimulationError]=Average_SimulationError(CounterModel)*(1+Parameters.GeneticProgramming.ParameterRegularisation*length(R_Generation(CounterModel).physical.paramArray));
        [R_Generation(CounterModel).performance.PredictionError]=Average_PredictionError(CounterModel)*(1+Parameters.GeneticProgramming.ParameterRegularisation*length(R_Generation(CounterModel).physical.paramArray));
        R_Generation(CounterModel).performance.NonPenaltySimulationError=Average_SimulationError(CounterModel);
        R_Generation(CounterModel).performance.NonPenaltyPredictionError=Average_PredictionError(CounterModel);
        %
        %         param_indiv = R_Generation(CounterModel).physical.noParams;
        %         R_Generation(CounterModel).performance.SimulationError=R_Generation(CounterModel).performance.SimulationError+param_indiv*Parameters.GeneticProgramming.ParameterPenalty;
        %         R_Generation(CounterModel).performance.PredictionError=R_Generation(CounterModel).performance.PredictionError+param_indiv*Parameters.GeneticProgramming.ParameterPenalty;
        %         if Parameters.Program.DisplayMessages ==1
        %             disp(strcat("Validate item ",num2str(CounterModel)));
        %         end
    end
    for CounterModel=Parameters.GeneticProgramming.MAX_POP:LengthRGen
        % add complexity penalty
        len_individual=0;
        for CounterLength=1:length(R_Generation(CounterModel).tree.DerivationTree.ElementaryArrayTypes)
            if ~isempty(R_Generation(CounterModel).DerivationTree.ElemArrayConnectionOperation{CounterLength})
                if R_Generation(CounterModel).DerivationTree.ElemArrayConnectionOperation{CounterLength}=="Adjunction"
                    len_individual=len_individual+1;
                end
            end
        end
        if len_individual > Parameters.GeneticProgramming.Max_Complexity
            total_penalty = (len_individual - Parameters.GeneticProgramming.Max_Complexity)*Parameters.GeneticProgramming.ComplexityPenalty;
            R_Generation(CounterModel).performance.SimulationError=R_Generation(CounterModel).performance.SimulationError+total_penalty;
            R_Generation(CounterModel).performance.PredictionError=R_Generation(CounterModel).performance.PredictionError+total_penalty;
        end
        % add parameter penalty
        %         param_indiv = R_Generation(CounterModel).physical.noParams;
        %         R_Generation(CounterModel).performance.SimulationError=R_Generation(CounterModel).performance.SimulationError+param_indiv*Parameters.GeneticProgramming.ParameterPenalty;
        %         R_Generation(CounterModel).performance.PredictionError=R_Generation(CounterModel).performance.PredictionError+param_indiv*Parameters.GeneticProgramming.ParameterPenalty;
        if Parameters.GeneticProgramming.NoStructurePenalty ==1
            if len_individual ==1
                R_Generation(CounterModel).performance.SimulationError = inf;
                R_Generation(CounterModel).performance.PredictionError = inf;
            end
        end
    end
    
end
Validation_runtime_finish = toc(Validation_runtime_start);
if Parameters.Program.DisplayMessages ==1
    disp(strcat("Validating the ",num2str(CounterNumberGeneration),"th gen. took ", num2str(Validation_runtime_finish)," seconds."));
end


clear Validation_runtime_finish len_individual total_penalty LengthRGen Average_PredictionError Average_SimulationError PredictionErrorWorkVariable SimulationErrorWorkVariable