% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.


Parameters.GeneticProgramming.NumberOfFitnessCriterions = 2; % Number of Fitness Criterions considered for the Pareto non-dominating sorting
GeneticEvolutionData.PerformanceFitnessParetoSolution = cell(1,Parameters.GeneticProgramming.NumberOfFitnessCriterions );


Parameters.GeneticProgramming.MAX_GEN = 350; % Maximum number of generations
Parameters.GeneticProgramming.MAX_POP = 60; % Use even number! you can try up to 100, best work with 80
Parameters.GeneticProgramming.Min_Complexity=3; % Minimum number of auxiliary trees used in the solution
Parameters.GeneticProgramming.Max_Complexity=70;% Minimum number of auxiliary trees used in the solution
Parameters.GeneticProgramming.Max_Complexity_UpperBound=150;
Parameters.GeneticProgramming.ParameterRegularisation=1e-4;
Parameters.GeneticProgramming.ParemeterEstimationSwitch = 3; % 1=CMAES(), 2 =Fminunc(), 3 LeastSquares() with PredictionError only
Parameters.GeneticProgramming.MutationChance=0.1; % for the newly crossover-generated offsprings
Parameters.GeneticProgramming.mu=0.4;% procentage of the first x% performant parent that will be used fo crossover
Parameters.GeneticProgramming.ComplexityPenalty = 0.5e-2; % penalty for trees with more complexity than max complexity.
Parameters.GeneticProgramming.ParameterPenalty = 0.2e-4;% penalty for each parameter that has to be estimated.
Parameters.GeneticProgramming.NoStructurePenalty =1; % 1 / 0; 1 = If the tree structure has no auxiliary trees (Complexity = 1) then the fitness function is set to inf
Parameters.GeneticProgramming.Complexity=[Parameters.GeneticProgramming.Min_Complexity Parameters.GeneticProgramming.Max_Complexity];

Parameters.EquationSolution.UseConstantTermInFunction=0; % Indicate if the Equation solution contains the constant term 1
Parameters.EquationSolution.Maximum_expected_delay = Parameters.GeneticProgramming.Max_Complexity; % The maximum expected delay is between 0 and Max_Complexity, since a tree cannot have more time-shift operators than Max_Complexity.
% tau_param_fitting = floor(Max_Complexity*10);
% tau_param_fitting = floor(length(uTrain{1,1})*1/10); % to speed up the CMA-ES simulation error.
% tau_param_fitting = floor(length(uTrain{1,1})*1/2); %tau-step-ahead prediction used for simulation error Used in CMA-Es
Parameters.EquationSolution.tau_param_fitting = Data.NumberOfSamples; % The number of data samples that are used for parameter approximation
% Lower this value to make CMA-ES faster; rule of thumb: tau_param_fitting >= 2->10* highest time delay
% Parameters.EquationSolution.tau_structure_sorting = floor(length(uTrain{1,1})/3); % used in Multi-Obj. sorting
Parameters.EquationSolution.tau_structure_sorting=Data.NumberOfSamples; % The number of data samples that are used for sorting the candidate models


% CMA-ES running parameters
Parameters.GeneticProgramming.CMAESParam.w_sim= 0.5; % CMA-ES cost function weights
Parameters.GeneticProgramming.CMAESParam.w_pred = 0.5;
Parameters.GeneticProgramming.CMAESParam.ParamFittingCriterionUpdate=10; % each ParamFittingCriterionUpdate generation, the CMA-ES stop criterion changes:
% CMAES_GivenStopFitness=CMAES_GivenStopFitness/10;
% CMAES_GivenStopCriterion = CMAES_GivenStopCriterion/10; CMAES_watchdog=
% CMAES_watchdog+2; for evolved generations, the parameter estimation
% program performs more fine parameter tunning
% ParemeterEstimationSwitch = 3; % 1=CMAES(), 2 =Fminunc(), 3 LeastSquares() with PredictionError only

Parameters.GeneticProgramming.CMAESParam.CMAES_ParametersInitialScale =1; % The initial scale of the parameters:
% User guess A good hinch is to see the ratio between input and output:
% If the output is several magnitudes higher than the input, try a small
% value for CMAES_ParametersInitialScale

Parameters.GeneticProgramming.CMAESParam.CMAES_GivenStopFitness=1e-8; % CMA-ES fitness limit
Parameters.GeneticProgramming.CMAESParam.CMAES_GivenStopCriterion=1e-12;% CMA-ES fitness gradient limit
Parameters.GeneticProgramming.CMAESParam.CMAES_Iterations=10;
Parameters.GeneticProgramming.CMAESParam.MAX_CMAES_Iterations=300;
Parameters.GeneticProgramming.CMAESParam.CMAES_watchdog=min(120,2*(Parameters.EquationSolution.nu+Parameters.EquationSolution.ny)); % after "CMAES_watchdog" seconds the CMAES stops and return the best set of parameters
Parameters.GeneticProgramming.CMAESParam.MAX_CMAES_watchdog = 5*60; % 5 mins per each candidate;

Parameters.GeneticProgramming.FminuncParam.Step_Tolerance = 1e-15;
Parameters.GeneticProgramming.FminuncParam.Function_Tolerance=1e-5;
Parameters.GeneticProgramming.FminuncParam.Max_iterations=2000;
Parameters.GeneticProgramming.FminuncParam.Max_function_evaluation=400;
Parameters.GeneticProgramming.FminuncParam.Display_option='off';
% Level of display (see Iterative Display):
% 'off' or 'none' displays no output.
% 'iter' displays output at each iteration, and gives the default exit message.
% 'iter-detailed' displays output at each iteration, and gives the technical exit message.
% 'notify' displays output only if the function does not converge, and gives the default exit message.
% 'notify-detailed' displays output only if the function does not converge, and gives the technical exit message.
% 'final' (default) displays only the final output, and gives the default exit message.
% 'final-detailed' displays only the final output, and gives the technical exit message.
Parameters.GeneticProgramming.FminuncParam.Algorithm='quasi-newton';
% The 'trust-region' algorithm requires you to provide the gradient (see the description of fun), or else fminunc uses the 'quasi-newton' algorithm. For information on choosing the algorithm


%% TAG3P variables
IndividualParametrisationResults=cell(1,2*Parameters.GeneticProgramming.MAX_POP); % Parameter Results in CMA-ES (Variable used for parallel computing)

%% Others
Runtime.GenerationTimerArray=zeros(1,Parameters.GeneticProgramming.MAX_GEN);
for CounterFitnessCriterions = 1: Parameters.GeneticProgramming.NumberOfFitnessCriterions
    GeneticEvolutionData.PerformanceFitnessParetoSolution{1,CounterFitnessCriterions} =zeros (1, Parameters.GeneticProgramming.MAX_GEN);
    GeneticEvolutionData.PerformanceBestFitnessCriterionSolution{1,CounterFitnessCriterions}= zeros (1, Parameters.GeneticProgramming.MAX_GEN);
    GeneticEvolutionData.PerformanceBestFitnessCriterionSolution_dB{1,CounterFitnessCriterions} = zeros (1, Parameters.GeneticProgramming.MAX_GEN);
end
    GeneticEvolutionData.PerformanceBestSimulationErrorCandidate = zeros(1,Parameters.GeneticProgramming.MAX_GEN);
clear CounterFitnessCriterions
GeneticEvolutionData.BestSimulationCandidate =0;
GeneticEvolutionData.GenerationTimerArray =  zeros(1,Parameters.GeneticProgramming.MAX_GEN);