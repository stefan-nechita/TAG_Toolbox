% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

%Initialise Input - Output data.
%% Step1 - load your data file
% load('.\Data_ParralelWienerHammerstein\ParWHData.mat')

%% Step2 - assign the number of Training, testing and validation data sets
 Parameters.GeneticProgramming.GenerateNewDataSets = 1; % 0 / 1 Generate or not a new data set trigger for an external data generating function
 Parameters.GeneticProgramming.TrainingDataSets = 5; % Number of Training Data Sets
 Parameters.GeneticProgramming.TestingDataSets  = 3; % Number of Testing Data Sets
 Parameters.GeneticProgramming.ValidationDataSets = 2; % Number of Validation Data Sets


%Initialising Data containers
 Data.uTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
 Data.uTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
 Data.uValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);

 Data.yTrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
 Data.yTest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
 Data.yValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);


 Data.ETrain= cell(1,Parameters.GeneticProgramming.TrainingDataSets);
 Data.ETest= cell(1,Parameters.GeneticProgramming.TestingDataSets);
 Data.EValid= cell(1,Parameters.GeneticProgramming.ValidationDataSets);


%% Step3 - manual input the number of data samples per data set for Training and testing
%	   time sample, number of input, output and process noice channels

 Data.NumberOfSamples=16384; %% example
 Data.Ts = ...; % used only for plotting
 Data.nu = ...; % Number of Input channels
 Data.ny = ...; % Number of Output channels
 Data.nE = ...; % Number of Process noise channels
 Data.NETrain = 2;% Number of process noise instances to be generated for/within parameter estimation procedure
 Data.ZeroProcessNoiseFlag = 0;% 0 / 1, 1 = the process noise will be zero; 0 = the process noise will be normal distributed random variable;
% if you set Data.ZeroProcessNoiseflag = 0, you have to set up the initial amplitude of the gaussian noise generator by 
% setting up Data.NoiseAmplitude - WARNING! if you are using model sets that include the process noise, setting a high amplitude will 
% make the identification procedure not to converge.
% Rule of thumb: Set the NoiseAmplitude = standard deviation of your senzor noise.

% Data.NoiseAmplitude = whitenoisestd;


%% Step3 - generate or load the data.
if Parameters.GeneticProgramming.GenerateNewDataSets==1

%% Here generate new data using your own data-generating function
else
%% Here collect the data from files
    for CounterDataSet=1:Parameters.GeneticProgramming.TrainingDataSets
        
            load("---data file---")
%	one input data set is represented by a matrix of dimension: nu x Data.NumberOfSamples,
%	one output data set is represented by a matrix of dimension: ny x Data.NumberOfSamples,	

        Data.uTrain{1,CounterDataSet} = %Data ...
        Data.yTrain{1,CounterDataSet} = %Data ...

        % advise: to keep the workspace clean, clear out all useless variables after loading the data, including the old input/output variables - all input output data are stored in Data structure.
        % Example : clear C1 C2 C2_noisy C2_true C2pv DC1 Finpv L_C1 L_Q1 L_Tc Q1 snrC smrT T T1 T2 T2_noisy T2_true T2pv Tcinpv Td
    end
    
    for CounterDataSet=1:Parameters.GeneticProgramming.TestingDataSets
        Data.uTest{1,CounterDataSet}(1,:)=%Data ...;
        Data.uTest{1,CounterDataSet}(2,:)=%Data ...;
    end
    
    for CounterDataSet=1:Parameters.GeneticProgramming.ValidationDataSets
        Data.uValid{1,CounterDataSet}(1,:)=%Data ...;
        Data.yValid{1,CounterDataSet}(1,:)=%Data ...;
    end
end
 Parameters.GeneticProgramming.TrainingDataSets = length(Data.uTrain); % Number of Training Data Sets
 Parameters.GeneticProgramming.TestingDataSets  =  length(Data.uTest); % Number of Testing Data Sets
 Parameters.GeneticProgramming.ValidationDataSets = length(Data.uValid); % Number of Validation Data Sets
%
%
%  StandardiseInputOutput % - WARNING! if your data signals have considerable different amplitudes, use this file to standardise your data
% if you have standardised your data, you have to use the generated models in standardise values. 
% Ex: input data ->>standardise input data fcn>>> standardized input data -> model -> standardized output data ->>unstdandardised output data()>>> output data
 clear amp ans uEst uVal whitenoisemean MeasuredNoise whitenoisestd uValArr yEst yVal yValArr lines fs WorkVariableY WorkVariableU NAmps NMultisine MultisineToChoose CounterMultisine CounterDataSet CounterAMps
