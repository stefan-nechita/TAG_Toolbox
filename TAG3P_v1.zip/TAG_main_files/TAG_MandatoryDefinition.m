% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

% Within this file, the structural search space can be modified by two methods:
% 1. choosing the initial and auxiliary trees that are used for composing a tree.
% 2. defining linking MASKS for Lu,Ly and LE linking arrays. in this way,
% only some input, output or proccess noise channels are contributing in
% the temporal basis.
%%----------Taken from MIMONARMAXAuxAndInitTrees.m file ----------------



% % %MIMO ARX:
% Define AuxiliaryTreeTypes:
% AuxiliaryTreeTypes.typesArray={"Beta1","Beta2","Beta7"};
% AuxiliaryTreeTypes.typeRootNode={"expr0","expr0","expr2"};
% AuxiliaryTreeTypes.Labels={"expr0","expr1","expr2"};
% [~,AuxiliaryTreeTypes.noAuxTrees]=size(AuxiliaryTreeTypes.typesArray);

% % %MIMO NARX
% InitTreeTypes.typesArray={"alfa1"};
% InitTreeTypes.typeRootNode={"expr0"};
% InitTreeTypes.Labels={"expr0"};
% InitTreeTypes.starterIndex=1;
% [~,InitTreeTypes.noInitTrees]=size(InitTreeTypes.typesArray);
% % Define AuxiliaryTreeTypes:
% AuxiliaryTreeTypes.typesArray={"Beta1","Beta2","Beta4","Beta5","Beta7"};
% AuxiliaryTreeTypes.typeRootNode={"expr0","expr0","expr1","expr1","expr2"};
% AuxiliaryTreeTypes.Labels={"expr0","expr1","expr2"};
% [~,AuxiliaryTreeTypes.noAuxTrees]=size(AuxiliaryTreeTypes.typesArray);

% %MIMO NARMAX
% InitTreeTypes.typesArray={"alfa1"};
% InitTreeTypes.typeRootNode={"expr0"};
% InitTreeTypes.Labels={"expr0"};
% InitTreeTypes.starterIndex=1;
% [~,InitTreeTypes.noInitTrees]=size(InitTreeTypes.typesArray);
% AuxiliaryTreeTypes.typesArray={"Beta1","Beta2","Beta3","Beta4","Beta5","Beta6","Beta7"};
% AuxiliaryTreeTypes.typeRootNode={"expr0","expr0","expr0","expr1","expr1","expr1","expr2"};
% AuxiliaryTreeTypes.Labels={"expr0","expr1","expr2"};
% [~,AuxiliaryTreeTypes.noAuxTrees]=size(AuxiliaryTreeTypes.typesArray);


% %MIMO NARX+Sin/Cos/Abs
% Define InitTreeTypes:
% InitTreeTypes.typesArray={"alfa1","alfa2","alfa3","alfa4"};
% InitTreeTypes.typeRootNode={"expr0","preop","preop","preop"};
% InitTreeTypes.Labels={"expr0","preop"};
% InitTreeTypes.starterIndex=1;
% [~,InitTreeTypes.noInitTrees]=size(InitTreeTypes.typesArray);
% 
% AuxiliaryTreeTypes.typesArray={"Beta1","Beta2","Beta4","Beta5","Beta7","Beta8"};
% AuxiliaryTreeTypes.typeRootNode={"expr0","expr0","expr1","expr1","expr2","expr3"};
% AuxiliaryTreeTypes.Labels={"expr0","expr1","expr2","expr3"};
% [~,AuxiliaryTreeTypes.noAuxTrees]=size(AuxiliaryTreeTypes.typesArray);


% %MIMO NARX + Inv/Exp
InitTreeTypes.typesArray={"alfa1","alfa5","alfa6"};
InitTreeTypes.typeRootNode={"expr0","preop","preop"};
InitTreeTypes.Labels={"expr0","preop"};
InitTreeTypes.starterIndex=1;
[~,InitTreeTypes.noInitTrees]=size(InitTreeTypes.typesArray);
% Define AuxiliaryTreeTypes:
AuxiliaryTreeTypes.typesArray={"Beta1","Beta2","Beta4","Beta5","Beta7","Beta8"};
AuxiliaryTreeTypes.typeRootNode={"expr0","expr0","expr1","expr1","expr2","expr3"};
AuxiliaryTreeTypes.Labels={"expr0","expr1","expr2","expr3"};
[~,AuxiliaryTreeTypes.noAuxTrees]=size(AuxiliaryTreeTypes.typesArray);

% %MIMO NARMAX+Sin/Cos/Abs/Inv/Exp
% Define InitTreeTypes:
% InitTreeTypes.typesArray={"alfa1","alfa2","alfa3","alfa4","alfa5","alfa6"};
% InitTreeTypes.typeRootNode={"expr0","preop","preop","preop","preop","preop"};
% InitTreeTypes.Labels={"expr0","preop"};
% InitTreeTypes.starterIndex=1;
% [~,InitTreeTypes.noInitTrees]=size(InitTreeTypes.typesArray);
% 
% AuxiliaryTreeTypes.typesArray={"Beta1","Beta2","Beta3","Beta4","Beta5","Beta6","Beta7","Beta8"};
% AuxiliaryTreeTypes.typeRootNode={"expr0","expr0","expr0","expr1","expr1","expr1","expr2","expr3"};
% AuxiliaryTreeTypes.Labels={"expr0","expr1","expr2","expr3"};
% [~,AuxiliaryTreeTypes.noAuxTrees]=size(AuxiliaryTreeTypes.typesArray);


Parameters.EquationSolution.MaskLink.Lu = zeros(1,Parameters.EquationSolution.nu);
Parameters.EquationSolution.MaskLink.Ly = zeros(1,Parameters.EquationSolution.ny);
Parameters.EquationSolution.MaskLink.LE = zeros(1,Parameters.EquationSolution.nE);
Parameters.EquationSolution.InputChannelsToBeUsed= 1:Parameters.EquationSolution.nu; % The channels to be used [1,5,7,13]
Parameters.EquationSolution.OutputChannelsToBeUsed=1:Parameters.EquationSolution.ny; % The channels to be used
Parameters.EquationSolution.NoiseChannelsToBeUsed=1:Parameters.EquationSolution.nE;  % The channels to be used
Parameters.EquationSolution.MaskLink.Lu(Parameters.EquationSolution.InputChannelsToBeUsed) = ones(1,length(Parameters.EquationSolution.InputChannelsToBeUsed));
Parameters.EquationSolution.MaskLink.Ly(Parameters.EquationSolution.OutputChannelsToBeUsed) = ones(1,length(Parameters.EquationSolution.OutputChannelsToBeUsed));
Parameters.EquationSolution.MaskLink.LE(Parameters.EquationSolution.NoiseChannelsToBeUsed) = ones(1,length(Parameters.EquationSolution.NoiseChannelsToBeUsed));


%% Auxiliary tree meaning:
% Beta1 = adding input signal to expression
% Beta2 = adding output(k-1) signal to expression
% Beta3 = adding noise(k-1) signal to expression
% Beta4 = adding multiplicative input term to expression
% Beta5 = adding multiplicative output(k-1) term to expression
% Beta6 = adding multiplicative noise(k-1) term to expression
% Beta7 = adding time-shift q^-1 term to expression
% To select ARX model set, keep only Beta1, Beta2 and Beta7 auxiliary trees
% To select NARX model set, keep only Beta1, Beta2, Beta4, Beta5 and Beta7
% auxiliary trees
% To select NARMAX model set, use all auxiliary trees.
% in order to alter the model set, Compose the
% AuxiliaryTreeTypes.typesArray and AuxiliaryTreeTypes.typeRootNode with
% the desired auxiliary trees and update the AuxiliaryTreeTypes.Label with
% the all possible non-leaf labels.
%% END OF MANDATORY DEFINITIONS!