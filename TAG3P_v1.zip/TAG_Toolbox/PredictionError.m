% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
function [PredError,y_hat] = PredictionError(individual,Data,DataSetIdentifier)
%PREDICTIONERROR Summary of this function goes here
%   individual  = only the .physical structure from each individual of an
%   generation
uCellIndex=DataSetIdentifier.uCellIndex; %Gather the data structure
yCellIndex=DataSetIdentifier.yCellIndex;
if  DataSetIdentifier.Train ==1
    uSelectedDataSet = Data.uTrain{1,uCellIndex};
    ySelectedDataSet = Data.yTrain{1,yCellIndex};
end

if  DataSetIdentifier.Test ==1
    uSelectedDataSet = Data.uTest{1,uCellIndex};
    ySelectedDataSet = Data.yTest{1,yCellIndex};
end

if  DataSetIdentifier.Valid ==1
    uSelectedDataSet = Data.uValid{1,uCellIndex};
    ySelectedDataSet = Data.yValid{1,yCellIndex};
end
u=[];
y=[];
[~,length_time]=size(uSelectedDataSet);
if Data.ZeroProcessNoiseFlag == 1
    E = zeros(Data.nE, length_time); % zeros
    u = [u uSelectedDataSet];
    y = [y ySelectedDataSet];
else
    E = Data.NoiseAmplitude*randn(Data.nE, length_time*Data.NETrain); % Normally distributed random variable
    for CounterDataSets = 1:Data.NETrain
        u = [u uSelectedDataSet];
        y = [y ySelectedDataSet];
    end
    
end

PredError=0;

Fcn=individual.fcn;
noDelays=individual.noDelays;
noParameters=individual.noParams;

% prepare data for simulation!
[nu,length_time]=size(u);
[ny,length_time]=size(y);
[nE,length_time]=size(E);
u_compare=[zeros(nu,noDelays) u];
y_compare=[ones(ny,noDelays).*y(:,1) y(:,1:end)];% If the input was 0 before the starting of the simulation,
% then the output of the system was unchanged from the past until the time
% sample of the simulation. 
E_compare=[zeros(nE,noDelays) E(:,1:end)];
% t=[zeros(1,noDelays) t'];
% E_compare=[zeros(nE,noDelays+length_time)]; % Here define your noise signal: create one on spot, bring it from outside this function or ignore the noise by setting it on 0

y_hat=zeros(ny,noDelays+length_time);
k=noDelays+1;
y_hat(:,1:k)=y_compare(:,1:k);
% y_hat_2=zeros(1,noDelays+length_time);
k=k+1;% set the initial condition
while k<=noDelays+length_time
    y_hat(:,k)=Fcn(individual.paramArray,y_compare,u_compare,E_compare,k);
    k=k+1;
end
 
% Idea: predict only half of the time... useless idea
for output_counter=1:ny
PredErrorOutput(output_counter) = sqrt(sum((y_hat(output_counter,:)-y_compare(output_counter,:)).^2)/length_time); %  RootMean square error
end
PredError=mean(PredErrorOutput);
if isnan(PredError) || ~isnumeric(noParameters) || noParameters==0
   PredError=inf;
end
y_hat=y_hat(:,noDelays+1:end);
y_compare=y_compare(:,noDelays+1:end);
end


