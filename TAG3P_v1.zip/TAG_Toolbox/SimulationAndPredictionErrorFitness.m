% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

function [Fobj] = SimulationAndPredictionErrorFitness(x,additional_parameters)

individual=additional_parameters.individual;
u=additional_parameters.u;
y=additional_parameters.y;
E=additional_parameters.E;
t=additional_parameters.t;
w_sim=additional_parameters.w_sim;
w_pred=additional_parameters.w_pred;
tau=additional_parameters.tau;

N=individual.noParams;
SimError=0;
Fcn=individual.fcn;
noDelays=individual.noDelays;
noParameters=individual.noParams;

% prepare data for simulation!
[nu,length_time]=size(u);
[ny,length_time]=size(y);
[nE,length_time]=size(E);
u_compare=[zeros(nu,noDelays) u(:,1:tau)];
y_compare=[ones(ny,noDelays).*y(:,1) y(:,1:tau)]; % If the input was 0 before the starting of the simulation,
% E=[zeros(ny,noDelays+tau)]; % Here define your noise signal: create one on spot, bring it from outside this function or ignore the noise by setting it on 0
E_compare=[zeros(nE,noDelays) E(:,1:tau)];
y_hat=zeros(ny,noDelays+tau);

% Set the initial condition (the constant to shift the results!)
k=noDelays+1;
y_hat(:,1:k)=y_compare(:,1:k);
k=k+1;% set the initial condition
while k<=tau+noDelays
    y_hat(:,k)=Fcn(x,y_hat,u_compare,E_compare,k);
    k=k+1;
end

for output_counter=1:ny
    SimErrorOutput(output_counter,:) = sqrt(sum((y_hat(output_counter,:)-y_compare(output_counter,:)).^2)/tau); % Root Mean square error
end
SimError=mean(SimErrorOutput);


PredError=0;

Fcn=individual.fcn;
noDelays=individual.noDelays;
noParameters=individual.noParams;
% prepare data for simulation!
[nu,length_time]=size(u);
[ny,length_time]=size(y);
[nE,length_time]=size(E);
u_compare=[zeros(nu,noDelays) u];
y_compare=[ones(ny,noDelays).*y(:,1) y(:,1:end)];% If the input was 0 before the starting of the simulation,
E_compare=[zeros(nE,noDelays) E];
% then the output of the system was unchanged from the past until the time
% sample of the simulation. 
y_hat=zeros(ny,noDelays+length_time);
% E=[zeros(ny,noDelays+length_time)];


% y_hat_2=zeros(1,noDelays+length_time);
 k=noDelays+1;
while k<=noDelays+length_time
    y_hat(:,k)=Fcn(x,y_compare,u_compare,E_compare,k);
    k=k+1;
end
% Idea: predict only half of the time... useless idea
for output_counter=1:ny
    PredErrorOutput(output_counter) = sqrt(sum((y_hat(output_counter,:)-y_compare(output_counter,:)).^2)/length_time); %  RootMean square error
end
PredError=mean(PredErrorOutput);



FitnessSimulation_Error=SimError;
FitnessPrediction_Error=PredError;

if (FitnessSimulation_Error==inf || isnan(FitnessSimulation_Error))
    Fobj = w_pred*FitnessPrediction_Error;
else
    if (FitnessPrediction_Error == inf || isnan(FitnessPrediction_Error))
        Fobj = w_sim*FitnessSimulation_Error;
    else
        Fobj = (w_sim*FitnessSimulation_Error + w_pred*FitnessPrediction_Error)/2;
    end
end

end

