% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
function TreeFunction=CreateTreeFunction(LabelOrderedRepresentation,EquationSolutionParam)
%% Creates a structure with two components:
% TreeFunction.fcn = a function handler that can be called
% TreeFunction.noParams = number of required parameters
ny = EquationSolutionParam.ny;
UseConstantTermInFunction= EquationSolutionParam.UseConstantTermInFunction;
TreeDerivationLabels=LabelOrderedRepresentation{1,1};
TreeOrderedNodes=LabelOrderedRepresentation{1,2};
counter_parameters=0;
counter_delays=0;
AddConstantTermToOutput=UseConstantTermInFunction;

index_parameter=1;
index_time_shift=0;
preop_discovered=0;
time_variable="(:,k)";
TreeFunctionString=["("];
i=1;
preop_counter=0;
while i<=length(TreeDerivationLabels)
    switch TreeDerivationLabels(i)
        case "parameter"
            TreeFunctionString=strcat(TreeFunctionString,"[");
            for counter_param=1:ny
                
                numberChar=num2str(index_parameter);
                index_parameter=index_parameter+1;
                if counter_param==ny
                    TreeFunctionString= strcat(TreeFunctionString,"paramArray(",numberChar,")]");
                else
                    TreeFunctionString= strcat(TreeFunctionString,"paramArray(",numberChar,");");
                end
            end
            i=i+1;
        case "link"
            L=TreeOrderedNodes(i).ownElementaryTree.LinkInfo; % extract the linking info from the elementary tree via the node
            TreeFunctionString=strcat(TreeFunctionString,"[");
            for counter_link=1:length(L)
                numberChar=num2str(L(counter_link));
                if counter_link==length(L)
                    TreeFunctionString=strcat(TreeFunctionString,numberChar,"]");
                else
                    TreeFunctionString= strcat(TreeFunctionString,numberChar,",");
                end
            end
            
            i=i+1;
        case "plus"
            TreeFunctionString= strcat(TreeFunctionString,")+(");
            i=i+1;
        case "multiplication"
            if ( TreeDerivationLabels(i-1)=="parameter" || TreeDerivationLabels(i-1)=="input" || TreeDerivationLabels(i-1)=="noise" || TreeDerivationLabels(i-1)=="output" || TreeDerivationLabels(i-1)=="link" || TreeDerivationLabels(i-1)=="expr1")
                TreeFunctionString= strcat(TreeFunctionString,"*");
            end
            i=i+1;
        case "time-shift"
            index_time_shift=index_time_shift+1;
            if index_time_shift>counter_delays % determining the maximum time delay, in order to prep the data accordingly! make the right shifts in the in/out data
                counter_delays=index_time_shift;
            end
            index_time_shiftChar=num2str(index_time_shift); % in case of multiple q^-1*q^-1*q^-1
            % the index of time_shift increases
            time_variable=strcat("(:,k-",index_time_shiftChar,")");% and transformed into a Char variable
            i=i+1;
        case "input"
            
            TreeFunctionString= strcat(TreeFunctionString,"u",time_variable);
            time_variable=("(:,k)"); % reset the Char variable that represents time
            index_time_shift=0; % reset the index of time shifting
            if preop_counter>0
                TreeFunctionString=strcat(TreeFunctionString,")");
                preop_counter=preop_counter-1;
            end
            i=i+1;
        case "output"
            
            TreeFunctionString= strcat(TreeFunctionString,"y",time_variable);
            time_variable=("(:,k)"); % reset the Char variable that represents time
            index_time_shift=0; % reset the index of time shifting
            if preop_counter>1
                TreeFunctionString=strcat(TreeFunctionString,")");
                preop_counter=preop_counter-1;
            end
            i=i+1;
        case "noise"
            
            TreeFunctionString= strcat(TreeFunctionString,"E",time_variable);
            time_variable=("(:,k)"); % reset the Char variable that represents time
            index_time_shift=0; % reset the index of time shifting
            
            if preop_counter>1
                TreeFunctionString=strcat(TreeFunctionString,")");
                preop_counter=preop_counter-1;
            end
            i=i+1;
        case "sin"
            TreeFunctionString= strcat(TreeFunctionString,"sin");
            if (TreeDerivationLabels(i+1)=="preop" && TreeDerivationLabels(i+2)=="multiplication")
                TreeFunctionString= strcat(TreeFunctionString,"(");
                i=i+2;
            end
            preop_counter=preop_counter+1;
            i=i+1;
        case "cos"
            TreeFunctionString= strcat(TreeFunctionString,"cos");
            if (TreeDerivationLabels(i+1)=="preop" && TreeDerivationLabels(i+2)=="multiplication")
                TreeFunctionString= strcat(TreeFunctionString,"(");
                i=i+2;
            end
            preop_counter=preop_counter+1;
            i=i+1;
        case "abs"
            TreeFunctionString= strcat(TreeFunctionString,"abs");
            if (TreeDerivationLabels(i+1)=="preop" && TreeDerivationLabels(i+2)=="multiplication")
                TreeFunctionString= strcat(TreeFunctionString,"(");
                i=i+2;
                preop_counter=preop_counter+1;
            end
            i=i+1;
        case "invers"
            TreeFunctionString= strcat(TreeFunctionString,"inv");
            if (TreeDerivationLabels(i+1)=="preop" && TreeDerivationLabels(i+2)=="multiplication")
                TreeFunctionString= strcat(TreeFunctionString,"(");
                i=i+2;
                preop_counter=preop_counter+1;
            end
            i=i+1;
        case "exponent"
            TreeFunctionString= strcat(TreeFunctionString,"exp");
            if (TreeDerivationLabels(i+1)=="preop" && TreeDerivationLabels(i+2)=="multiplication")
                TreeFunctionString= strcat(TreeFunctionString,"(");
                i=i+2;
                preop_counter=preop_counter+1;
            end
            i=i+1;
            
            
        case "expr3"
            if (TreeDerivationLabels(i-1)=="input" || TreeDerivationLabels(i-1)=="output" || TreeDerivationLabels(i-1)=="noise" )
                TreeFunctionString= strcat(TreeFunctionString,")");
            end
            if preop_counter>0
                TreeFunctionString=strcat(TreeFunctionString,")");
                preop_counter=preop_counter-1;
            end
            i=i+1;
        case "expr2"
            if (TreeDerivationLabels(i-1)=="input" || TreeDerivationLabels(i-1)=="output" || TreeDerivationLabels(i-1)=="noise" )
                %                 TreeFunctionString= strcat(TreeFunctionString,")");
            end
            if preop_counter>0
                TreeFunctionString=strcat(TreeFunctionString,")");
                preop_counter=preop_counter-1;
            end
            i=i+1;
        case "expr1"
            if (TreeDerivationLabels(i-1)=="input" || TreeDerivationLabels(i-1)=="output" || TreeDerivationLabels(i-1)=="noise" )
                %                 TreeFunctionString= strcat(TreeFunctionString,")");
            end
            if preop_counter>0
                TreeFunctionString=strcat(TreeFunctionString,")");
                preop_counter=preop_counter-1;
            end
            i=i+1;
        case "expr0"
            if (TreeDerivationLabels(i-1)=="input" || TreeDerivationLabels(i-1)=="output" || TreeDerivationLabels(i-1)=="noise" )
                TreeFunctionString= strcat(TreeFunctionString,")");
            end
            if preop_counter>0
                TreeFunctionString=strcat(TreeFunctionString,")");
                preop_counter=preop_counter-1;
            end
            i=i+1;
        case "aff"
            if (TreeDerivationLabels(i-1)=="input" || TreeDerivationLabels(i-1)=="output" || TreeDerivationLabels(i-1)=="noise" )
                TreeFunctionString= strcat(TreeFunctionString,")");
            end
            if preop_counter>0
                TreeFunctionString=strcat(TreeFunctionString,")");
                preop_counter=preop_counter-1;
            end
            i=i+1;
        otherwise
            i=i+1;
    end
    
end
if AddConstantTermToOutput==1;
    TreeFunctionString =strcat(TreeFunctionString,"+([");
    for counter_param=1:ny
        numberChar=num2str(index_parameter);
        index_parameter=index_parameter+1;
        if counter_param==ny
            TreeFunctionString= strcat(TreeFunctionString,"paramArray(",numberChar,")]*1)");
        else
            TreeFunctionString= strcat(TreeFunctionString,"paramArray(",numberChar,");");
        end
    end
end
TreeFunctionString = strcat("@(paramArray,y,u,E,k) ", TreeFunctionString);
TreeFunction.fcn = eval(TreeFunctionString); % the function itself
TreeFunction.noParams=index_parameter-1; % the number of parameters required
TreeFunction.noDelays=counter_delays; % the number of maximum delays in time this function has -> usefull for data preparation
TreeFunction.AddConstantTermToOutput=AddConstantTermToOutput;
end