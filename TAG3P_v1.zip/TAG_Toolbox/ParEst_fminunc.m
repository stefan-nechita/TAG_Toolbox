% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
function [FittedparamArray,FittingPerformance,Runtime] = ParEst_fminunc(individual,u,y,E,t,w_sim,w_pred,tau,FminuncParam)

Runtime.SimulationError = 0;
Runtime.PredictionError = 0;

N=individual.noParams;
tic_runtime=tic();

additional_parameters.individual=individual;
additional_parameters.u=u;
additional_parameters.y=y;
additional_parameters.E=E;
additional_parameters.t=t;
additional_parameters.w_sim=w_sim;
additional_parameters.w_pred=w_pred;
additional_parameters.tau=tau;
Step_Tolerance=FminuncParam.Step_Tolerance;
Function_Tolerance=FminuncParam.Function_Tolerance;
Max_iterations=FminuncParam.Max_iterations;
Max_function_evaluation=FminuncParam.Max_function_evaluation;
Display_option = FminuncParam.Display_option;
Algorithm=FminuncParam.Algorithm;
if N ~= 0
    
    [InitialParameters,FittingPerformanceLS,Runtime]  = ParameterEstimationLeastSquares(individual,u,y,E);
    [arxSimulation_Error,~,~]=SimulationError(individual,u,y,E,t,tau);
    if ( isempty(find(isnan(InitialParameters))) && arxSimulation_Error<100 && max(InitialParameters)<1000)
        Fobj = @(x) SimulationAndPredictionErrorFitness(x,additional_parameters);
        options = optimoptions('fminunc', 'Algorithm' , Algorithm ,'Display',Display_option, 'StepTolerance', Step_Tolerance, 'FunctionTolerance', Function_Tolerance, 'MaxIterations',Max_iterations, 'MaxFunctionEvaluations', Max_function_evaluation);
        problem =createOptimProblem('fminunc','objective', Fobj, 'x0', InitialParameters, 'options', options);
        [FittedparamArray,FittingPerformance] = fminunc(problem);
        
    else
        FittedparamArray=InitialParameters;
        FittingPerformance= FittingPerformanceLS;
    end
    
else
    FittedparamArray="No Parameters";
    individual.paramArray=0;
    [arxSimulation_Error,~,~]=SimulationError(individual,u,y,E,t,tau);
    [arxPrediction_Error,~,~]=PredictionError(individual,u,y,E,t);
    FittingPerformance=  w_sim*arxSimulation_Error + w_pred*arxPrediction_Error;
end

Runtime=toc(tic_runtime);
end

