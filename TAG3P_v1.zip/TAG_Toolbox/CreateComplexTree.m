% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
function [Error,FinalTree]=CreateComplexTree(CreationInformation,ny,nu,nE,InitTreeTypes,MaskLink)
%% This function Recreates the DerivationTree path of a Complex Tree that was already built.
% The information required are passed through CreationInformation structure
% CreationInformation.parent= an array of n elementary trees filled with
% the index of each own parent (Derivation Tree parent)
% CreationInformation.parentBranchIndex = an array that indicates where in
% the Branch array of own parent one has beed connected
% CreationInformation.TreeType = what kind of elementary tree was used
% Creation.ConnectionOperator = what TAG operator was used in connection
Error=0;
len_ElementaryArray=length(CreationInformation.parent);
RootIndex = find(CreationInformation.parent==0);
constructionCounter=1;
DerivedTreeDevelopment=cell(1,len_ElementaryArray);
DerivedTreeDevelopment{constructionCounter}=HandleTree("MainTree");

for i=1:len_ElementaryArray
    switch CreationInformation.TreeType{i,1}
        case "alfa1"
            workingTree{i,1}=CreateInitTree(CreationInformation.TreeType{i,1}); % create a new intial Tree
        case "alfa2"
            workingTree{i,1}=CreateInitTree(CreationInformation.TreeType{i,1});
        case "alfa3"
            workingTree{i,1}=CreateInitTree(CreationInformation.TreeType{i,1});
        case "alfa4"
            workingTree{i,1}=CreateInitTree(CreationInformation.TreeType{i,1});
        case "alfa5"
            workingTree{i,1}=CreateInitTree(CreationInformation.TreeType{i,1});
        case "alfa6"
            workingTree{i,1}=CreateInitTree(CreationInformation.TreeType{i,1});
        case "Beta1"
            workingTree{i,1}=CreateAuxTree(CreationInformation.TreeType{i,1},CreationInformation.LinkInfo{i,1},ny,nu,nE,MaskLink); % creating a new auxiliary Tree
        case "Beta2"
            workingTree{i,1}=CreateAuxTree(CreationInformation.TreeType{i,1},CreationInformation.LinkInfo{i,1},ny,ny,nE,MaskLink);
        case "Beta3"
            workingTree{i,1}=CreateAuxTree(CreationInformation.TreeType{i,1},CreationInformation.LinkInfo{i,1},ny,nu,nE,MaskLink);
        case "Beta4"
            workingTree{i,1}=CreateAuxTree(CreationInformation.TreeType{i,1},CreationInformation.LinkInfo{i,1},ny,nu,nE,MaskLink);
        case "Beta5"
            workingTree{i,1}=CreateAuxTree(CreationInformation.TreeType{i,1},CreationInformation.LinkInfo{i,1},ny,nu,nE,MaskLink);
        case "Beta6"
            workingTree{i,1}=CreateAuxTree(CreationInformation.TreeType{i,1},CreationInformation.LinkInfo{i,1},ny,nu,nE,MaskLink);
        case "Beta7"
            workingTree{i,1}=CreateAuxTree(CreationInformation.TreeType{i,1},CreationInformation.LinkInfo{i,1},ny,nu,nE,MaskLink); % creating a new auxiliary Tree
        case "Beta7"
            workingTree{i,1}=CreateAuxTree(CreationInformation.TreeType{i,1},CreationInformation.LinkInfo{i,1},ny,nu,nE,MaskLink); % creating a new auxiliary Tree
        case "Beta8"
            workingTree{i,1}=CreateAuxTree(CreationInformation.TreeType{i,1},CreationInformation.LinkInfo{i,1},ny,nu,nE,MaskLink); % creating a new auxiliary Tree    end
    end
    
end


initialElementaryTree=CreateInitTree(CreationInformation.TreeType{RootIndex,1});

DerivedTreeDevelopment{constructionCounter}.DerivationTree=initialElementaryTree.DerivationTree;
% DerivedTreeDevelopment.root=HandleNode("node");
DerivedTreeDevelopment{constructionCounter}.root=initialElementaryTree.root;
DerivedTreeDevelopment{constructionCounter}.DerivationTree=initialElementaryTree.DerivationTree;

constructionCounter=2;
while constructionCounter<=len_ElementaryArray
    parentIndex=CreationInformation.parent(constructionCounter,1);
    branchIndex=CreationInformation.parentBranchIndex(constructionCounter,1);
    elemTree=workingTree{constructionCounter,1};
    
    switch CreationInformation.ConnectionOperator{constructionCounter,1}
        case "Adjunction"
            [Error,ResultedTreeFromOperation]=Adjunction(DerivedTreeDevelopment{constructionCounter-1},elemTree,parentIndex,branchIndex,InitTreeTypes);
        case "Substitution"
            [Error,ResultedTreeFromOperation]=Substitution(DerivedTreeDevelopment{constructionCounter-1},elemTree,parentIndex,branchIndex);
    end
    
    if Error==0
        DerivedTreeDevelopment{constructionCounter}= ResultedTreeFromOperation;
        partiallyDerivationTree=DerivedTreeDevelopment{constructionCounter}.DerivationTree; % for debug only!
        Labels=GetTreeDerivation(DerivedTreeDevelopment{constructionCounter});
        constructionCounter=constructionCounter+1;
    else
        display("Error happened hehe")
        Error
        dbstop in CreateComplexTree.m at 65
        FinalTree=DerivedTreeDevelopment{constructionCounter-1}
        return
    end
    
end

FinalTree = DerivedTreeDevelopment{constructionCounter-1};

end

