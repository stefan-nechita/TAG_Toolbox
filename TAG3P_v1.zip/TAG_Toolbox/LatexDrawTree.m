% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

function [LatexForestString] = LatexDrawTree(Node,LatexForestString)
%% In order to draw the tree of a subtree, call the function with the subtree ROOT
% Copy the output of this funciton to any Latex document (width enough) and
% add the packages:
% \usepackage{graphicx} % Allows including images
% \usepackage{booktabs} % Allows the use of \toprule, \midrule and \bottomrule in tables
% \usepackage{tikz}
% \usepackage[linguistics]{forest}
% \usepackage{tkz-graph}
% Use example: 
% $\begin{tikzpicture}
% <output string>
% \end{tikzpicture}$

% Copy the output of this function into the Poster Latex overleaf
% document in order to test it
if ~isempty(Node)
    if ~isempty(Node.substitutionAvailable)
        Sa=num2str(Node.substitutionAvailable);
        Sa=strcat("\\Sa",Sa,"\_");
    else
        Sa="";
    end
    if ~isempty(Node.adjunctionAvailable)
        Aa=num2str(Node.adjunctionAvailable);
        Aa=strcat("Aa",Aa);
    else
        Aa="";
    end
    switch Node.type
        case "root"
            type="r";
        case "intermediate"
            type="i";
        case "leaf"
            type="lf";
        case "foot"
            type="foot";
    end
    switch Node.label
        case "plus"
            label="$+$";
        case "multiplication"
            label="$\times$";
        case "parameter"
            label="$C$";
        case "input"
            label="$u(k)$";
        case "output"
            label="$y(k)$";
        case "noise"
            label="$E(k)$";
        case "time-shift"
            label="$q^{-1}$";
        otherwise
            label=Node.label;
    end
    
    nodeTextroot=strcat(type," ",label,Sa,Aa);
    
    
    LatexForestString=strcat("[",LatexForestString,nodeTextroot,LatexDrawTree(Node.offspring{1,1},LatexForestString),LatexDrawTree(Node.offspring{1,2},LatexForestString),LatexDrawTree(Node.offspring{1,3},LatexForestString),"]");
else
    LatexForestString="";
end
end


