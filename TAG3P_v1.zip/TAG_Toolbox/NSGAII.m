% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.
% The NSGA-II algorithm is the creation of Deb et. al 2002 described in the
% paper: A Fast and Elitist Multiobjective Genetic Algorithm: NSGA-II
% Kalyanmoy Deb, Associate Member, IEEE, Amrit Pratap, Sameer Agarwal, and T. Meyarivan

function [Sorter_Fronts] = NSGAII(R_Generation)
%% Performin non-Dominated sorting for Genetic programming

%GP parameters
nPop=length(R_Generation); % number of population
maxFrontRank=nPop;


%describe population structure.
% Pop.id=[]; %identification number
% Pop.fitness=[]; % the value it is sorted.
% Pop.rank=[]; %
% Pop.Front=[]; % the non-dominated Tier (1,2,3...)
% Pop.np=0; % how many other solution it dominates (fitness-wise);
% Pop.Sq=[]; % what individual si dominated by p;


%  Move this outside of NSGAII so that the new crossover and mutation terms are first parameter fitted and than non-dominated ordered!!!

% init Pop sturcture
for i=1:nPop
    Pop(i)=HandleIndividual("Indiv",R_Generation(i).performance.SimulationError,R_Generation(i).performance.PredictionError,i);
end

for i=1:nPop
    if isnan(Pop(i).fitness(1))
        Pop(i).fitness(1)=inf;
    end
    if isnan(Pop(i).fitness(2))
        Pop(i).fitness(2)=inf;
    end
end



Front=arrayfun(@(x)struct('front_rank',x),(1:maxFrontRank));
for i=1:maxFrontRank
    Front(i).Set=[];
end


%% Sorting Algorithm
% the smallest fitness value the better! one has to adapt the fitness value
% in order to sort things correctly without changing the sorting code

for counter_p=1:1:nPop
    for counter_q=1:1:nPop
        if counter_p~=counter_q
            if IsDominating(Pop(counter_p),Pop(counter_q))% if p dominates q
                Pop(counter_p).Sq = [Pop(counter_p).Sq Pop(counter_q)]; %add q to Dominated Set of p
            else                                                     % else
                if IsDominating(Pop(counter_q),Pop(counter_p)) % if q dominates p
                    Pop(counter_p).np=Pop(counter_p).np+1;              % increase the dominated order np of p
                end
            end
        end
    end
    if (Pop(counter_p).np==0) % if p is not dominated by anybody, it is first rank
        Pop(counter_p).rank=1;
        Front(Pop(counter_p).rank).Set=[Front(Pop(counter_p).rank).Set Pop(counter_p)]; % populate the front structure with the new addition
    end
end

i=1;
while ~isempty(Front(i).Set)
    Q_set=[];
    for counter_p=1:length(Front(i).Set)
        for counter_q=1:length(Front(i).Set(counter_p).Sq)
            Front(i).Set(counter_p).Sq(counter_q).np=Front(i).Set(counter_p).Sq(counter_q).np-1;
            if Front(i).Set(counter_p).Sq(counter_q).np == 0
                Front(i).Set(counter_p).Sq(counter_q).rank = i+1;
                Q_set=[Q_set Front(i).Set(counter_p).Sq(counter_q)];
            end
        end
    end
    i=i+1;
    Front(i).Set=Q_set;
end
%% ADD the crowding distance assingment function
% The crowding distance function was changed with a simulation error
% sorting function
NoFronts=0;
i=1;
while ~isempty(Front(i).Set)
    NoFronts=NoFronts+1;
    i=i+1;
end
Sorter_Fronts=Front;
for CounterFronts=1:NoFronts
    
    for CounterModel1=1:length(Sorter_Fronts(CounterFronts).Set)
        Auxiliary=[];
        swapped=0;
        for CounterModel2=1:length(Sorter_Fronts(CounterFronts).Set)
            if Sorter_Fronts(CounterFronts).Set(1, CounterModel1).fitness(1,1) <Sorter_Fronts(CounterFronts).Set(1, CounterModel2).fitness(1,1)
                Auxiliary=Sorter_Fronts(CounterFronts).Set(1, CounterModel2);
                Sorter_Fronts(CounterFronts).Set(1, CounterModel2)=Sorter_Fronts(CounterFronts).Set(1, CounterModel1);
                Sorter_Fronts(CounterFronts).Set(1, CounterModel1)=Auxiliary;
                swapped=1;
            end
            
        end
    end
end
    
    
