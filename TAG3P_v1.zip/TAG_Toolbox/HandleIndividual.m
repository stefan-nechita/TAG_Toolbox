% This implementation of Tree Adjoining Grammar system identification method was
% written by Stefan-Cristian Nechita, Control Systems reseach group, Electrical engineering department at Technical University of Eindhoven.
% The code is a work in progress. you can contact the author at: s.c.nechita@tue.nl
% An introduction of the toolbox and parts of the implementation are described in
% the "On Data-driven modeling using Tree Adjoining Grammar Guided Genetic Programming" submitted to 
% SysId 2021 conference.

%% Used inside the NSGAII algorithm (it requires pointers)
classdef HandleIndividual < handle
    properties
        Object=[];
        fitness=[]; %fitness matrix, 1st row = SimulationError, 2nd row Prediction Error 
        rank=[];
        np=[];
        Sq=[];
        index=[];
        
    end
    
    methods
        function obj=HandleIndividual(receivedObject,SimulationError,PredictionError,index)
            obj.Object=receivedObject;
            obj.fitness=[SimulationError;PredictionError];
            obj.rank=[];
            obj.np=0;
            obj.Sq=[];
            obj.index=index;
            
        end
        
        
    end
    
end